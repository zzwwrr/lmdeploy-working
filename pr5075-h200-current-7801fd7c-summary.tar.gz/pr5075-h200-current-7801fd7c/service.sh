#!/usr/bin/env bash
set -euo pipefail
cd /home/zhuwenrui/decision-pr5075-openloop-20261109-7801fd7c-DA0Mvg
trap 'status=$?; printf "%s\n" "$status" > service.exit_code' EXIT
export CUDA_VISIBLE_DEVICES=GPU-32f80b8a-b48a-3cea-0baa-8ecb909fb3aa CUDA_HOME=/usr/local/cuda
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=2 TOKENIZERS_PARALLELISM=false
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY all_proxy
/home/zhuwenrui/decision-h200-gdr/envs/bench/bin/python -u serve.py serve api_server /home/zhuwenrui/decision-h200/models/Intern-Decision-4B \
  --task intern-decision --model-name Intern-Decision-4B --server-name 127.0.0.1 --server-port 18489 \
  --backend pytorch --dtype bfloat16 --max-batch-size 128 --cache-max-entry-count .1 \
  --max-prefill-token-num 8192 --piecewise-cudagraph-max-tokens 8192 --session-len 16384 \
  --logprobs-mode raw_logits --log-level INFO --enable-prefix-caching
