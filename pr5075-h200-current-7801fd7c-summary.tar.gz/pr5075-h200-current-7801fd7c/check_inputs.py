"""Verify frozen source, model weights and reused benchmark inputs."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'source-manifest.json').read_text())
for line in manifest['production_git_tree']:
    metadata, name = line.split('\t', 1)
    data = (ROOT / 'source' / name).read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == metadata.split()[2], name
for name, expected in json.loads((ROOT / 'data-expected.json').read_text()).items():
    assert hashlib.sha256((ROOT / 'data' / name).read_bytes()).hexdigest() == expected, name
model = Path('/home/zhuwenrui/decision-h200/models/Intern-Decision-4B')
weights = {}
for name, expected in json.loads((ROOT / 'model-weights-expected.json').read_text()).items():
    with (model / name).open('rb') as stream:
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert actual == (expected if isinstance(expected, str) else expected['sha256']), name
    if isinstance(expected, dict):
        assert (model / name).stat().st_size == expected['bytes'], name
    weights[name] = actual
record = dict(passed=True, source_commit=manifest['source_commit'], production_files=len(manifest['production_git_tree']),
              weights=weights, model=str(model), resolved_model=str(model.resolve()), python=sys.executable,
              versions={name: importlib.metadata.version(name) for name in ('torch', 'transformers', 'flash-linear-attention', 'fla-core', 'tilelang', 'triton')})
(ROOT / ('inputs-check-' + sys.argv[1] + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
