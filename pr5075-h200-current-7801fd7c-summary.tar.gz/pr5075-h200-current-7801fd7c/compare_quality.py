"""Compare saved HTTP answers with the previous H200 run by exact identity."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREVIOUS = Path('/home/zhuwenrui/decision-pr5075-openloop-20261106-KkKxbe/results/official-seven/responses.jsonl')


def key(row):
    return row['suite'], row['source_line'], row['id']


def probs(answer):
    return answer['probabilities'] if answer['type'] != 'noul' else {'yes': answer['noul'], 'no': 1-answer['noul']}


old = {key(row): row for row in map(json.loads, PREVIOUS.open())}
new = list(map(json.loads, (ROOT/'results/official-seven/responses.jsonl').open()))
assert len(old) == len(new) == 10751
fields = changed_top1 = changed_probs = 0
max_abs_difference = 0.
for row in new:
    prior = old[key(row)]
    assert row['status'] == prior['status'] == 200
    assert set(row['response']['answers']) == set(prior['response']['answers'])
    for field, answer in row['response']['answers'].items():
        current, previous = probs(answer), probs(prior['response']['answers'][field])
        assert set(current) == set(previous)
        fields += 1
        changed_top1 += min(current, key=lambda x: (-current[x], x)) != min(previous, key=lambda x: (-previous[x], x))
        changed_probs += current != previous
        max_abs_difference = max(max_abs_difference, max(abs(current[x]-previous[x]) for x in current))
assert fields == 12351
result = dict(previous_source='4446d416789988d0429443ff88e3faf038a9965b',current_source='7801fd7cdad7495633bf0c3d6be978eec32f0b1a',
              requests=len(new), fields=fields, changed_top1=changed_top1, changed_probability_fields=changed_probs,
              max_abs_candidate_probability_difference=max_abs_difference,
              scope='Saved-response comparison by suite/source-line/ID; no numerical equivalence or causal performance attribution claimed.')
(ROOT/'results/historical-answer-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
