#!/usr/bin/env bash
set -euo pipefail
cd /home/zhuwenrui/decision-pr5075-openloop-20261109-7801fd7c-DA0Mvg
trap 'status=$?; printf "%s\n" "$status" > finalize.exit_code' EXIT
while [ ! -f orchestrate.exit_code ]; do sleep 5; done
test "$(cat orchestrate.exit_code)" = 0
/home/zhuwenrui/decision-aiperf/env/bin/python -B compare_quality.py
/home/zhuwenrui/decision-aiperf/env/bin/python -B export_results.py
/home/zhuwenrui/decision-aiperf/env/bin/python -B review-bundle/audit.py > final-audit.json
