"""Offline standard-library audit: python3 audit.py; no model or GPU required."""
import collections,gzip,hashlib,json,math,statistics,sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
bundle = ROOT
manifest = json.loads((bundle / 'manifest.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((bundle / name).read_bytes()).hexdigest() == digest, name
summary = json.loads((bundle / 'summary.json').read_text())

source_manifest = json.loads((ROOT / 'source-manifest.json').read_text())
source_archive = ROOT / 'source-7801fd7c.tar.gz'
assert hashlib.sha256(source_archive.read_bytes()).hexdigest() == source_manifest['archive_sha256']
import tarfile
with tarfile.open(source_archive) as archive:
    for line in source_manifest['production_git_tree']:
        metadata, name = line.split('\t', 1)
        data = archive.extractfile(name).read()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == metadata.split()[2]
assert len(source_manifest['production_git_tree']) == 764
before = json.loads((ROOT / 'inputs-check-before.json').read_text())
after = json.loads((ROOT / 'inputs-check-after.json').read_text())
assert before['passed'] and after['passed']
assert before['source_commit'] == after['source_commit'] == source_manifest['source_commit'] == summary['source_commit']
assert before['weights'] == after['weights']
expected_weights = json.loads((ROOT / 'model-weights-expected.json').read_text())
assert before['weights'] == {name: value['sha256'] if isinstance(value, dict) else value for name, value in expected_weights.items()}
admission = json.loads((ROOT / 'idle-admission.json').read_text())
assert all(not admission[key]['pids'] and admission[key]['memory_mib'] < 1024 and admission[key]['utilization'] < 10 for key in ('first', 'second'))
with gzip.open(ROOT / 'gpu-monitor.jsonl.gz', 'rt') as stream:
    gpu_samples = [json.loads(line) for line in stream]
assert gpu_samples and not any(row['external_pids'] for row in gpu_samples)

for item in summary['compressed_originals']:
    with gzip.open(bundle / item['exported'], 'rb') as stream:
        assert hashlib.sha256(stream.read()).hexdigest() == item['decoded_sha256']
request_count = 0
for point in summary['points']:
    path = bundle / 'results' / point['name'] / 'verified-requests.jsonl.gz'
    with gzip.open(path, 'rt') as stream:
        rows = list(map(json.loads, stream))
    assert len(rows) == point['requests'] and all(r['valid'] and r['status'] == 200 for r in rows)
    values = sorted(r['latency_ms'] for r in rows)
    rank = (len(values) - 1) * .95
    lo, hi = math.floor(rank), math.ceil(rank)
    p95 = values[lo] + (values[hi] - values[lo]) * (rank - lo)
    assert abs(p95 - point['latency_ms']['p95']) < 1e-6
    phase = next(p for p in json.loads((path.parent / 'phase_manifest.json').read_text())['phases']
                 if p['phase_kind'] == 'profiling')
    completed = sum(r['end_ns'] <= phase['start_ns'] + point['seconds'] * 1e9 for r in rows)
    assert abs(completed / point['seconds'] - point['completed_in_window_rps']) < 1e-12

    bin_seconds = 1 if point['seconds'] < 30 else 5
    bins = collections.defaultdict(lambda: [0, 0])
    for row in rows:
        bins[int((row['start_ns'] - phase['start_ns']) // (bin_seconds * 1000000000))][0] += 1
        bins[int((row['end_ns'] - phase['start_ns']) // (bin_seconds * 1000000000))][1] += 1
    inflight = 0
    tail = []
    for index in range(max(bins) + 1):
        sent, ended = bins[index]
        inflight += sent - ended
        second = index * bin_seconds
        if point['seconds'] / 3 <= second < point['seconds']:
            tail.append((second, inflight))
    mean_x = statistics.mean(x for x, _ in tail)
    mean_y = statistics.mean(y for _, y in tail)
    slope = sum((x-mean_x)*(y-mean_y) for x, y in tail) / sum((x-mean_x)**2 for x, _ in tail)
    assert abs(slope - point['backlog_slope_per_second']) < 1e-10
    stable = (slope <= max(.1, point['rate'] * .002) and completed / len(rows) >= .97)
    assert stable == point['stable']

    request_count += len(rows)
sys.path.insert(0, str(ROOT / 'reference'))
from jevbench.metrics import brier_score, ece_top_label

with gzip.open(bundle / 'data/accuracy-records.jsonl.gz', 'rt') as stream:
    inputs = list(map(json.loads, stream))
with gzip.open(bundle / 'results/official-seven/responses.jsonl.gz', 'rt') as stream:
    outputs = list(map(json.loads, stream))
assert len(inputs) == len(outputs) == 10751
totals = collections.defaultdict(lambda: dict(correct=0, fields=0))
hard_brier, hard_ece = [], []
for record in outputs:
    row = inputs[record['index']]
    assert row['id'] == record['key'] and record['status'] == 200 and 'error' not in record
    for field, expected_label in row['targets'].items():
        answer = record['response']['answers'][field]
        probs = answer.get('probabilities') or {'yes': answer['noul'], 'no': 1 - answer['noul']}
        label = min(probs, key=lambda k: (-probs[k], k))
        correct = label == str(expected_label)
        totals[row['suite']]['correct'] += correct
        totals[row['suite']]['fields'] += 1
        if row['suite'] == 'jevbench-hard':
            hard_brier.append(brier_score(probs, expected_label, list(probs)))
            hard_ece.append((max(probs.values()), correct))
quality = summary['quality']
for name, counts in totals.items():
    assert counts['correct'] == quality['suites'][name]['correct']
    assert counts['fields'] == quality['suites'][name]['total']
    assert counts['correct'] / counts['fields'] == quality['suites'][name]['accuracy']
correct = sum(s['correct'] for s in totals.values())
fields = sum(s['fields'] for s in totals.values())
macro = statistics.mean(s['correct'] / s['fields'] for s in totals.values())
ece = ece_top_label(hard_ece, n_bins=10)['ece']
assert correct == quality['correct'] and fields == quality['fields'] == 12351
assert abs(macro - quality['macro7_accuracy']) < 1e-12
assert abs(statistics.mean(hard_brier) - quality['hard_brier']) < 1e-12
assert abs(ece - quality['hard_ece']) < 1e-12
result = dict(passed=True, verified_files=len(manifest), production_files=764, gpu_monitor_samples=len(gpu_samples), stress_requests=request_count,
              quality_requests=len(outputs), quality_fields=fields, quality_correct=correct,
              macro7_accuracy=macro, hard_brier=statistics.mean(hard_brier), hard_ece=ece,
              scope='Transferred bytes, decompressed originals, all timing/P95 summaries, gold accuracy and Hard calibration replay; no new inference.')
# Keep audit output outside the manifest to avoid a self-referential hash.
print(json.dumps(result, indent=2))
