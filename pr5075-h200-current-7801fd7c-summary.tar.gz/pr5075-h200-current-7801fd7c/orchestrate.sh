#!/usr/bin/env bash
set -euo pipefail
cd /home/zhuwenrui/decision-pr5075-openloop-20261109-7801fd7c-DA0Mvg
trap 'status=$?; printf "%s\n" "$status" > orchestrate.exit_code' EXIT
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
/home/zhuwenrui/decision-aiperf/env/bin/python -u orchestrate.py
