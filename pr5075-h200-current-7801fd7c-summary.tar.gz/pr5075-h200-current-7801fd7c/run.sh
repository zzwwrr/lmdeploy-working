#!/usr/bin/env bash
set -euo pipefail
cd /home/zhuwenrui/decision-pr5075-openloop-20261109-7801fd7c-DA0Mvg
trap 'status=$?; printf "%s\n" "$status" > run.exit_code' EXIT
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY all_proxy
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 TOKENIZERS_PARALLELISM=false
/home/zhuwenrui/decision-aiperf/env/bin/python -u run.py
