#!/usr/bin/env bash
set -euo pipefail
cd /home/zhuwenrui/decision-pr5075-openloop-20261109-7801fd7c-DA0Mvg
trap 'status=$?; printf "%s\n" "$status" > refine.exit_code' EXIT
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY all_proxy
/home/zhuwenrui/decision-aiperf/env/bin/python -u refine.py
