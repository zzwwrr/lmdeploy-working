"""Run the isolated H200 experiment and stop if an external GPU job appears."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback
import psutil
import httpx

ROOT = Path(__file__).resolve().parent
UUID = 'GPU-32f80b8a-b48a-3cea-0baa-8ecb909fb3aa'


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def gpu():
    values = subprocess.check_output(['nvidia-smi', '-i', UUID, '--query-gpu=memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True)
    memory, utilization = map(int, values.strip().split(','))
    apps = subprocess.check_output(['nvidia-smi', '-i', UUID, '--query-compute-apps=pid', '--format=csv,noheader,nounits'], text=True)
    return dict(memory_mib=memory, utilization=utilization, pids=[int(p) for p in apps.splitlines() if p.strip()])


def owned():
    roots = set()
    for process in psutil.process_iter(['pid', 'cwd']):
        try:
            if process.info['cwd'] == str(ROOT):
                roots.add(process.pid)
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            pass
    result = set(roots)
    for pid in roots:
        try:
            result.update(p.pid for p in psutil.Process(pid).children(recursive=True))
        except psutil.NoSuchProcess:
            pass
    return result


def stop_service():
    path = ROOT / 'service.pid'
    if not path.exists():
        return
    try:
        process = psutil.Process(int(path.read_text()))
        assert process.cwd() == str(ROOT) and 'service.sh' in ' '.join(process.cmdline())
        children = process.children(recursive=True)
        for child in reversed(children):
            try:
                child.terminate()
            except psutil.NoSuchProcess:
                pass
        process.terminate()
        _, alive = psutil.wait_procs([process, *children], timeout=20)
        for child in alive:
            child.kill()
    except psutil.NoSuchProcess:
        pass


def phase(name, monitor):
    with (ROOT / f'{name}.log').open('x') as log:
        child = subprocess.Popen(['bash', name + '.sh'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (ROOT / f'{name}.pid').write_text(str(child.pid) + '\n')
        service_key = None
        known_host_gpu_pids = None
        while child.poll() is None:
            key = (ROOT / 'service.pid').read_text() if (ROOT / 'service.pid').exists() else None
            if key != service_key:
                service_key, known_host_gpu_pids = key, None
            device = gpu()
            if known_host_gpu_pids is None:
                try:
                    response = httpx.get('http://127.0.0.1:18489/v1/models', timeout=2, trust_env=False)
                    if response.status_code == 200:
                        known_host_gpu_pids = set(device['pids'])
                except httpx.HTTPError:
                    pass
            external = [] if known_host_gpu_pids is None else sorted(set(device['pids']) - known_host_gpu_pids)
            monitor.write(json.dumps(dict(time=time.time(), phase=name, gpu=device, external_pids=external,
                known_host_gpu_pids=None if known_host_gpu_pids is None else sorted(known_host_gpu_pids),
                ownership_method='GPU host-PID baseline after verified idle admission and HTTP readiness; refresh on owned service restart',
                visible_task_pids=sorted(owned()))) + '\n')
            monitor.flush()
            if external:
                for pid in owned():
                    try:
                        process = psutil.Process(pid)
                        args = process.cmdline()
                        if any(arg in ('run.py', 'refine.py') for arg in args) and 'python' in args[0]:
                            process.send_signal(signal.SIGINT)
                    except psutil.NoSuchProcess:
                        pass
                child.wait(timeout=60)
                raise RuntimeError(f'External GPU processes appeared: {external}')
            time.sleep(5)
        assert child.returncode == 0, f'{name} failed: {child.returncode}'


def main():
    first = gpu()
    assert not first['pids'] and first['memory_mib'] < 1024 and first['utilization'] < 10, first
    time.sleep(10)
    second = gpu()
    assert not second['pids'] and second['memory_mib'] < 1024 and second['utilization'] < 10, second
    write('idle-admission.json', dict(first=first, second=second, gpu_uuid=UUID))
    subprocess.run(['/home/zhuwenrui/decision-h200-gdr/envs/bench/bin/python', str(ROOT/'check_inputs.py'), 'before'], check=True)
    with (ROOT/'logs/service.log').open('x') as log:
        service = subprocess.Popen(['bash','service.sh'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        (ROOT/'service.pid').write_text(str(service.pid)+'\n')
    try:
        with (ROOT/'gpu-monitor.jsonl').open('x') as monitor:
            phase('run', monitor)
            phase('refine', monitor)
        subprocess.run(['/home/zhuwenrui/decision-h200-gdr/envs/bench/bin/python', str(ROOT/'check_inputs.py'), 'after'], check=True)
        write('orchestrator-status.json', dict(complete=True, source_commit='7801fd7cdad7495633bf0c3d6be978eec32f0b1a', service_stopped=True))
    finally:
        stop_service()


if __name__ == '__main__':
    try:
        main()
    except BaseException:
        write('orchestrator-status.json',dict(complete=False,error=traceback.format_exc()))
        stop_service()
        raise
