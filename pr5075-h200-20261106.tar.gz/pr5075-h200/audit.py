"""Verify historical artifacts and recompute quality metrics without inference."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import lzma
import math
import subprocess
import tarfile
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
SCORER = '7ce310c7262ed49cc85853339a8a42459298e3f3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    return json.loads((ROOT / name).read_text())


def rows(name):
    with lzma.open(ROOT / name, 'rt') as stream:
        return [json.loads(line) for line in stream]


def same(actual, expected, label):
    assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), (label, actual, expected)


def argmax(probs):
    return min(probs, key=lambda label: (-probs[label], label))


def probabilities(answer):
    result = answer.get('probabilities')
    if isinstance(result, list):
        return {str(item['value']): item['probability'] for item in result}
    if isinstance(result, dict):
        return result
    yes = answer['probability'] if 'probability' in answer else answer['noul']
    return {'no': 1 - yes, 'yes': yes}


def valid(probs, labels):
    assert set(probs) == set(labels)
    assert all(isinstance(p, (int, float)) and not isinstance(p, bool)
               and math.isfinite(p) and 0 <= p <= 1 for p in probs.values())
    assert abs(sum(probs.values()) - 1) <= 1e-3


def ece(pairs):
    bins = [[] for _ in range(10)]
    for confidence, correct in pairs:
        bins[min(int(confidence * 10), 9)].append((confidence, correct))
    return sum(len(items) / len(pairs)
               * abs(sum(p for p, _ in items) / len(items) - sum(c for _, c in items) / len(items))
               for items in bins if items)


def load_official(path):
    revision = subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()
    assert revision == SCORER, (revision, SCORER)
    modules = []
    for name in ['scoring', 'metrics']:
        source = path / 'jevbench' / f'{name}.py'
        committed = subprocess.check_output(['git', '-C', str(path), 'show', f'{SCORER}:jevbench/{name}.py'])
        assert source.read_bytes() == committed, source
        spec = importlib.util.spec_from_file_location(f'official_{name}', source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        modules.append(module)
    return modules


def audit_text(expected, official):
    targets = rows('datasets/text-targets.jsonl.xz')
    by_id = {row['id']: row for row in targets}
    assert len(by_id) == len(targets) == 10751
    output = {}
    for backend in ['pytorch', 'vllm']:
        raw = rows(f'text/{backend}/responses.jsonl.xz')
        assert len(raw) == len(by_id) and {row['id'] for row in raw} == set(by_id)
        suites = defaultdict(lambda: {'rows': 0, 'fields': 0, 'correct': 0, 'brier': [], 'pairs': []})
        for row in raw:
            assert 'error' not in row, row['id']
            target = by_id[row['id']]
            assert row['payload_sha256'] == target['payload_sha256']
            assert row['suite'] == target['suite'] and row['source_line'] == target['source_line']
            assert row['field_count'] == len(target['fields'])
            answers = row['response']['answers']
            assert set(answers) == set(target['fields'])
            if row['response'].get('input_ids_sha256'):
                assert row['response']['input_ids_sha256'] == target['input_ids_sha256']
            aggregate = suites[row['suite']]
            aggregate['rows'] += 1
            for field, task in target['fields'].items():
                probs = probabilities(answers[field])
                valid(probs, task['labels'])
                predicted = argmax(probs)
                correct = predicted == task['expected']
                brier = sum((probs[label] - int(label == task['expected'])) ** 2 for label in task['labels'])
                recorded = row['scores'][field]
                assert recorded['correct'] == correct and recorded['predicted'] == predicted
                assert recorded['probs'] == probs
                same(brier, recorded['brier'], row['id'])
                if official:
                    scoring, metrics = official
                    spec = SimpleNamespace(question={'type': task['type']}, labels=task['labels'],
                                           expected=task['expected'])
                    result = scoring.score_task(probs, spec)
                    assert result['strict_valid'] and result['correct'] == correct and result['predicted'] == predicted
                    same(brier, metrics.brier_score(probs, task['expected'], task['labels']), row['id'])
                aggregate['fields'] += 1
                aggregate['correct'] += correct
                aggregate['brier'].append(brier)
                aggregate['pairs'].append((max(probs.values()), correct))
        report = expected['text'][backend]
        assert sum(s['fields'] for s in suites.values()) == report['fields'] == 12351
        assert report['complete'] and report['failed_fields'] == 0
        actual = {}
        for name, value in suites.items():
            recorded = report['suites'][name]
            for key in ['rows', 'fields', 'correct']:
                assert value[key] == recorded[key], (backend, name, key)
            accuracy = value['correct'] / value['fields']
            brier = sum(value['brier']) / value['fields']
            calibration = ece(value['pairs'])
            same(accuracy, recorded['accuracy'], name)
            same(brier, recorded['brier'], name)
            same(calibration, recorded['ece']['ece'], name)
            if official:
                same(calibration, official[1].ece_top_label(value['pairs'])['ece'], name)
            actual[name] = {'correct': value['correct'], 'fields': value['fields'],
                            'accuracy': accuracy, 'brier': brier, 'ece': calibration}
        macro = sum(value['accuracy'] for value in actual.values()) / 7
        same(macro, report['macro_accuracy'], backend)
        output[backend] = {'requests': len(raw), 'fields': 12351, 'macro_accuracy': macro, 'suites': actual}
        print(f'TEXT {backend}: 10751 requests / 12351 fields, seven-suite mean {macro:.10%} PASS')
    return output


def audit_vision(expected):
    targets = rows('datasets/vision-targets.jsonl.xz')
    by_id = {row['id']: row for row in targets}
    assert len(by_id) == len(targets) == 12088
    output = {}
    for key, groups in expected['vision'].items():
        raw = rows(f'vision/{key}/responses.jsonl.xz')
        assert len(raw) == len(by_id) and {row['id'] for row in raw} == set(by_id)
        aggregate = defaultdict(lambda: {'count': 0, 'correct': 0})
        for row in raw:
            assert 'error' not in row, row['id']
            target = by_id[row['id']]
            assert row['image_sha256'] == target['image']['sha256'] and row['target'] == target['target']
            answers = row['response']['answers']
            answer = answers[0] if isinstance(answers, list) else answers['q1']
            probs = probabilities(answer)
            labels = ['no', 'yes'] if row['suite'] == 'pope' else list('ABCD')
            valid(probs, labels)
            assert probs == row['probabilities']
            predicted = ('yes' if probs['yes'] > 0.5 else 'no') if row['suite'] == 'pope' else argmax(probs)
            correct = predicted == target['target']
            assert row['predicted'] == predicted and row['correct'] == correct
            assert row['suite'] == target['suite'] and row['category'] == target['category']
            group = aggregate[f'{row["suite"]}-{row["category"]}']
            group['count'] += 1
            group['correct'] += correct
        for name, value in aggregate.items():
            assert value['count'] == groups[name]['count'] and value['correct'] == groups[name]['correct']
            same(value['correct'] / value['count'], groups[name]['accuracy'], name)
        output[key] = dict(aggregate)
        print(f'VISION {key}: 12088 predictions, four suite counts/accuracies PASS')
    for api in ['systemone', 'openai']:
        statuses = [load(f'historical/vision/results/{backend}-{api}-formal.status.json')
                    for backend in ['pytorch', 'vllm']]
        assert all(s['complete'] and s['rows'] == 12088 and s['errors'] == 0 for s in statuses)
        left = rows(f'vision/traces/pt-token-trace-{statuses[0]["service_pid"]}.jsonl.xz')
        right = rows(f'vision/traces/vllm-input-trace-{statuses[1]["service_pid"]}.jsonl.xz')
        assert len(left) == len(right) == 12088
        assert all(a['scoring_prefix_sha256'] == b['scoring_prefix_sha256'] for a, b in zip(left, right))
        assert all(row['image_tokens'] > 0 for row in left)
        print(f'PREFIX {api}: 12088 matching causal-prefix hashes PASS')
    images = load('datasets/vision-image-byte-audit.json')
    assert len(images) == 1314 and sum(image['resized'] for image in images) == 183
    assert all(image['verified_sha256'] == image['sha256'] for image in images)
    replacements = load('historical/vision/results/pope-text-replacements.json')
    assert len(replacements) == 57
    print('IMAGE PREPARATION: 1314 original image-byte hashes, 183 resizes, 57 text corrections PASS')
    return output


def audit_sources():
    selection = load('source-selection.json')
    with tarfile.open(ROOT / selection['archive'], 'r:xz') as archive:
        members = archive.getmembers()
        assert all(member.isfile() for member in members)
        assert {member.name for member in members} == set(selection['files'])
        assert len(members) == len(selection['files'])
        for member in members:
            assert 'turbomind' not in member.name.lower()
            data = archive.extractfile(member).read()
            entry = selection['files'][member.name]
            assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
            blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            assert blob == entry['git_blob_sha1']
    print(f'SOURCE SNAPSHOTS: {len(members)} selected source files PASS')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jevbench', type=Path, help='Optional original scorer checkout at the pinned revision.')
    parser.add_argument('--output', type=Path, help='Write verification outside the immutable evidence directory.')
    args = parser.parse_args()
    manifest = load('manifest.json')
    actual_files = {str(path.relative_to(ROOT)) for path in ROOT.rglob('*')
                    if path.is_file() and path != ROOT / 'manifest.json'}
    assert set(manifest) == actual_files, 'Every package file must be indexed, except the root manifest itself.'
    for name, entry in manifest.items():
        data = (ROOT / name).read_bytes()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], name
    for name, entry in load('origin-index.json').items():
        data = (ROOT / name).read_bytes()
        if entry['encoding'] == 'gzip':
            data = gzip.decompress(data)
        elif entry['encoding'] == 'xz':
            data = lzma.decompress(data)
        assert sha(data) == entry['original_sha256'] and len(data) == entry['original_bytes'], name
    metadata = load('historical/text/results/service-pytorch-metadata.json')
    assert sha((ROOT / 'historical/text/config/lm_http.py').read_bytes()) == metadata['adapter_sha256']
    provenance = load('provenance.json')
    assert metadata['commit'] == provenance['sources']['lmdeploy-text']['commit']
    print(f'INTEGRITY: {len(manifest)} artifact hashes and all lossless original-byte mappings PASS')
    audit_sources()
    expected = load('expected-summary.json')
    official = load_official(args.jevbench) if args.jevbench else None
    result = {'text': audit_text(expected, official), 'vision': audit_vision(expected),
              'official_scorer_replayed': bool(official), 'new_inference': False}
    if args.output:
        assert not args.output.resolve().is_relative_to(ROOT), 'Keep audit output outside the immutable package.'
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print('PASS: saved raw probabilities reproduce all published text/image accuracy and calibration values.')


if __name__ == '__main__':
    main()
