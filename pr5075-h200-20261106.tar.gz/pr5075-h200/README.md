# PR 5075: historical H200 4B quality reference

Historical reference bundle assembled on 2026-11-06 from the existing H200 artifacts.
It covers the two historical quality tables in the Intern-Decision guide: seven
text suites, and POPE/AI2D image comparisons. The evaluated revisions below identify
those archived runs. This bundle contains no new inference run or performance
measurement and does not establish current-PR-head quality or capacity.

## Evaluated versions

| Run | Evaluated source | Workload |
| --- | --- | --- |
| Text, 2026-10-30 | LMDeploy `7d2ef19115c9306e2d57437ec30a994d5b942fd1` plus the preserved `lm_http.py` HTTP facade | PyTorch and vLLM; 10,751 requests / 12,351 fields per backend |
| Images, 2026-11-03 | LMDeploy `3df76b5bda652d4f8ba5fc056e1acf773bc2ab36` plus preserved launchers | PyTorch/vLLM, Systemone/OpenAI; 12,088 predictions per combination |
| vLLM adapter | `a8fe089c73472acc728102ac3f271f96f2398352` | Same model and temperature, original tokenizer alignment and runtime overrides |

All runs use Intern-Decision-4B revision
`38c9dafbbef52dd04bae943c0c6ac918419adfd5`, BF16, TP1, temperature
`1.99241824`, and one H200. Text uses cache OFF, concurrency 8, max batch 64,
session/prefill 16384, and PyTorch piecewise graphs up to 8192 tokens. Images
use cache ON, concurrency 1, max batch 128, session 16384 and prefill 8192;
the vLLM image run uses eager execution after its visual compilation failed.
Original effective configurations, package snapshots, model-file hashes and
launch arguments are retained under `historical/`.

The text metadata records its actual LMDeploy commit and facade SHA256. The image
launch metadata records the frozen source directory. That directory's repository
and saved revision resolve to `3df76b5b`; its archived launchers and outputs match
the original vision manifest. A separate production-file hash manifest was not
saved for every historical image run. Collection-time repository cleanliness is
recorded separately and does not establish additional historical observations.

`source-archives/evaluated-sources.tar.xz` contains unmodified selected production
package files from the evaluated text LMDeploy, image LMDeploy and serving revisions.
`source-selection.json` records each retained file hash/Git blob ID and the source
commit. These are partial repository snapshots, not the current PR head. TurboMind
implementation, the C++ tree, documentation and tests are omitted. These runs predate
the indexed GDN gate fix and the proposed RMSNorm changes.

## Contents and integrity

This smaller candidate excludes mixed-backend load-test summaries, TurboMind
execution records, obsolete attempts and unrelated diagnostic helpers. All six
raw response files, four prefix traces and target indexes retain identical
decompressed bytes; only their compression changes from gzip to XZ.
`selection.json` documents every removal and encoding change. The original
PyTorch HTTP facade retains its inactive TurboMind code branch so its
historical service-recorded SHA256 remains verifiable.

- `text/`: the two complete original JSONL response files, losslessly XZ-compressed,
  and unchanged original per-suite metrics.
- `vision/`: all four complete original JSONL response files and the four causal
  prefix traces, losslessly XZ-compressed.
- `datasets/`: derived target/label indexes without the full input corpus, pinned
  dataset revisions, original prepared-record hashes, and the 1,314-image byte audit.
- `historical/`: original launchers, preparers, evaluators, effective configuration,
  metadata and historical manifests. These are selected artifacts; files referenced
  by an original broad manifest are not necessarily all included here.
- `source-selection.json`: per-file hashes for the selected source snapshots.
- `historical/text/selected-artifact-manifest.json`: the retained subset of the
  original text manifest, identified as a derived selection.
- `origin-index.json`: maps every copied/compressed artifact to its original
  uncompressed SHA256 and byte count.
- `manifest.json`: SHA256 and byte count for every file in this candidate, except
  the manifest itself.

All 69,854 raw response rows retain their original fields, including probabilities,
cached scoring results, response usage and elapsed times. They represent 73,054
decision fields across the six runs. The embedded elapsed times are historical
observations, not a validated latency or capacity comparison in this package.

Model weights, full benchmark input corpora, image bytes and dataset Parquet
files are not included. The original 57 POPE text replacements and diagnostic
question examples remain in historical metadata. Incomplete HF image outputs
are not presented as full-set HF results. Extra SuperGLUE, RACE/MultiRC,
open-loop performance and newer gate-only experiments are outside this package.

## Audit without a GPU

Python 3.12 and the standard library are sufficient:

```bash
python3 audit.py --output ../h200-verification.json
```

The audit checks every file hash and original-byte mapping, coverage and label
identity, raw response distributions, text accuracy/Brier/ECE for all seven
suites, all 16 image accuracy cells, causal-prefix equality within each image
protocol, 57 corrected POPE texts, and 183 resized images. The remote collector
also read and hashed all 1,314 prepared images; those bytes remain on H200.

For an additional replay through the original official Jevbench scorer, use a
checkout at `7ce310c7262ed49cc85853339a8a42459298e3f3`:

```bash
python3 audit.py --jevbench /path/to/jevbench --output ../h200-official-replay.json
```

The optional replay verifies that the imported scoring and metrics files match
the pinned Git objects. It compares every text field and all suite Brier/ECE
values with the saved results, using the original label sets and targets.

## Recreate the input preparation

Text inputs come from Intern-Decision revision
`3572c8a68b5df5dafe02d0e093989ba8ec0183bc`, `benchmarks/accuracy-v1/`.
The original `historical/text/config/prepare.py` and dataset audit describe the
10,751 requests and 12,351 fields. The derived target index preserves source
line, payload hash, input-token hash, expected labels and exact candidate sets.
Recover the original input texts from the pinned reference repository.

Images use POPE revision `4db1276663dfa5eb8ad16a52d24c31a09e470896` and AI2D
revision `c83a9b9692933aff8349157c88a413df9d02c4e5`. POPE's 9,000 rows are
cross-checked against RUCAIBox/POPE revision
`08d957b917e5a378a2f99d35b6293c536a66298b`; 57 question texts were corrected.
RGB PNG conversion preserves aspect ratio, constrains edges to 280--1568 pixels,
and resizes 183 of 1,314 source images. Zero images were padded.

The historical preparer queried the then-current POPE commit and used a local
proxy. `reproduce/prepare_vision.py` pins that recorded commit, uses normal HTTP
proxy environment settings, and writes into a caller-selected new directory.
Its complete patch against the original script is included. Install the original
preparation dependencies (`httpx`, `pyarrow`, `Pillow`) separately, then run:

```bash
mkdir /path/to/new-vision-inputs
H200_VISION_REPLAY_ROOT=/path/to/new-vision-inputs python3 reproduce/prepare_vision.py
```

Compare the generated `results/dataset-manifest.json` and `data/records.jsonl`
SHA256 with `datasets/manifest.json`, and the generated image hashes with
`datasets/vision-image-byte-audit.json`. PNG bytes can depend on Pillow/image
codec versions; do not substitute different bytes and call the result an exact
reproduction. Historical scripts and image hashes remain unchanged in this package.

## Repeat inference

The preserved launchers retain their original paths and environment assumptions.
The source archive contains `lmdeploy-text/`, `lmdeploy-vision/` and `serving/`.
For text, check out the full pinned repositories and overlay the selected source
files; restore the text LMDeploy tree under
`~/decision-h200-gdr/repos/lmdeploy-pt`, serving under
`~/decision-h200/repos/intern-decision-inference`, and the text configuration/data
under `~/decision-aiperf`. `historical/text/config/run-v4.py` records the original
launch arguments; its complete workflow also runs load tests that
are outside this evidence candidate. Select the intended PyTorch/vLLM quality
commands from that controller instead of blindly rerunning the full workflow.

For images, restore full checkouts at the image LMDeploy and serving revisions,
overlay their selected source files, and place them under
`~/decision-dual-api-2k-20261102/sources/{lmdeploy,serving}`. Restore the vision
configuration and freshly prepared data under
`~/decision-vision-accuracy-20261103`. The original `service.py`, `serve_pt.py`,
`serve_vllm.py` and `evaluate.py` preserve exact startup and scoring behavior.
Use a new experiment directory for any rerun; keep historical results intact.
Adapted reruns must record their own paths, patches, source and package versions.

## Interpretation

This package makes historical quality observations auditable. It does not claim
current-head model accuracy, complete API equivalence, generation/scoring mixed
batches, disconnect cancellation, new performance measurements, or numerical
identity across backends. Compare image backends within the same protocol:
Systemone and OpenAI use different prompt structures and image placement.
