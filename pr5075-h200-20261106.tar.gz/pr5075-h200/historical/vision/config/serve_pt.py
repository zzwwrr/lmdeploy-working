"""Run the pinned native LMDeploy CLI with read-only input tracing."""
import hashlib
import json
import os
import resource
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.meta_path = [finder for finder in sys.meta_path if 'editable' not in repr(finder).lower()]
sys.path.insert(0, str(Path.home() / 'decision-dual-api-2k-20261102/sources/lmdeploy'))
soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
resource.setrlimit(resource.RLIMIT_NOFILE, (min(65535, hard), hard))
from lmdeploy.serve.parsers import decision_parser

original_context = decision_parser.create_decision_context
original_finalize = decision_parser.DecisionParser.finalize_input
traced = 0


def context(engine, model_path):
    result = original_context(engine, model_path)
    record = dict(config=asdict(engine.backend_config), temperature=result.temperature,
                  source=str(Path.home() / 'decision-dual-api-2k-20261102/sources/lmdeploy'), argv=sys.argv)
    (ROOT / 'results' / f'pt-effective-{os.getpid()}.json').write_text(json.dumps(record, indent=2, default=str))
    return result


def finalize(self, prepared):
    global traced
    original_finalize(self, prepared)
    if traced < 30000:
        ids = prepared.inputs['input_ids']
        record = dict(systemone=self.systemone, tokens=len(ids),
                      input_ids_sha256=hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest(),
                      scoring_prefix_sha256=hashlib.sha256(json.dumps(ids[:ids.index(self.context.marker_id)], separators=(',', ':')).encode()).hexdigest(),
                      image_tokens=ids.count(self.context.image_token_id))
        with (ROOT / 'results' / f'pt-token-trace-{os.getpid()}.jsonl').open('a') as stream:
            stream.write(json.dumps(record) + '\n')
        traced += 1


decision_parser.create_decision_context = context
decision_parser.DecisionParser.finalize_input = finalize
from lmdeploy.cli import run

if __name__ == '__main__':
    run()
