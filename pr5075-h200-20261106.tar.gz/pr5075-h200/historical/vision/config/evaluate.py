"""Single-request image accuracy evaluation through the two native HTTP protocols."""
import argparse
import base64
import functools
import hashlib
import json
import math
import time
from pathlib import Path

import httpx

from service import ROOT, Service, write_json


@functools.lru_cache(maxsize=32)
def image_base64(path):
    return base64.b64encode((ROOT / path).read_bytes()).decode('ascii')


def payload(row, api):
    encoded = image_base64(row['image']['path'])
    question = row['question']
    if api == 'systemone':
        return dict(model='Intern-Decision-4B', state={'image': 'evaluation-image'}, questions={'q1': question},
                    assets={'evaluation-image': dict(format='png', data_base64=encoded)})
    item = dict(name='q1', type='predicate' if question['type'] == 'noul' else 'choice',
                instructions=question['instructions'])
    if question['type'] == 'choice':
        item['choices'] = [dict(value=k, description=v) for k, v in question['criteria'].items()]
    return dict(model='Intern-Decision-4B', input=[dict(role='user', content=[
        dict(type='input_image', image_url='data:image/png;base64,' + encoded)])], questions=[item])


def score(row, body, api):
    answers = body['answers']
    if api == 'openai':
        assert len(answers) == 1 and answers[0]['name'] == 'q1'
        answer = answers[0]
    else:
        assert set(answers) == {'q1'}
        answer = answers['q1']
    if row['question']['type'] == 'noul':
        probability = answer['probability'] if api == 'openai' else answer['noul']
        probabilities = dict(no=1-probability, yes=probability)
    else:
        probabilities = ({entry['value']: entry['probability'] for entry in answer['probabilities']}
                         if api == 'openai' else answer['probabilities'])
        assert set(probabilities) == set(row['question']['criteria'])
    assert all(math.isfinite(value) and 0 <= value <= 1 for value in probabilities.values())
    assert abs(sum(probabilities.values())-1) < .001
    predicted = min(probabilities, key=lambda key: (-probabilities[key], key))
    if row['question']['type'] == 'choice':
        assert answer['choice'] == predicted
    assert body['usage']['input_tokens'] > 64
    return dict(probabilities=probabilities, predicted=predicted, target=row['target'], correct=predicted == row['target'])


def records(smoke=False):
    rows = [json.loads(line) for line in (ROOT/'data/records.jsonl').open()]
    if not smoke:
        return rows
    selected = []
    for category in ['adversarial', 'popular', 'random']:
        for target in ['yes', 'no']:
            selected.append(next(r for r in rows if r['suite']=='pope' and r['category']==category and r['target']==target))
    selected.extend([r for r in rows if r['suite']=='ai2d'][:6])
    return selected


def run_http(backend, api, smoke=False):
    phase = 'smoke' if smoke else 'formal'
    key = f'{backend}-{api}-{phase}'
    rows = records(smoke)
    output = ROOT/'results'/f'{key}.jsonl'
    assert not output.exists(), output
    service = Service(backend)
    state = dict(stage='starting', backend=backend, api=api, phase=phase, complete=False, rows=0, errors=0)
    try:
        write_json(ROOT/'results'/f'{key}.status.json', state)
        service.start()
        state['service_pid'] = service.process.pid
        write_json(ROOT/'results'/f'{key}.status.json', state)
        endpoint = service.base_url + ('/v1/systemone' if api=='systemone' else '/v1/decisions')
        with httpx.Client(timeout=120, trust_env=False) as client, output.open('w') as stream:
            for index, row in enumerate(rows):
                start = time.perf_counter()
                result = dict(id=row['id'], suite=row['suite'], category=row['category'],
                              image_sha256=row['image']['sha256'], target=row['target'])
                try:
                    request = payload(row, api)
                    result['payload_sha256'] = hashlib.sha256(json.dumps(request, separators=(',', ':')).encode()).hexdigest()
                    response = client.post(endpoint, json=request)
                    response.raise_for_status()
                    body = response.json()
                    result.update(response=body, **score(row, body, api))
                except Exception as exc:
                    result['error'] = repr(exc)
                    if 'response' in locals():
                        result['error_body'] = response.text[:2000]
                    state['errors'] += 1
                result['elapsed_ms'] = (time.perf_counter()-start)*1000
                stream.write(json.dumps(result, ensure_ascii=False)+'\n')
                stream.flush()
                state.update(stage='evaluating', rows=index+1, last_id=row['id'])
                if index % 100 == 0 or 'error' in result:
                    write_json(ROOT/'results'/f'{key}.status.json', state)
                    print(key, index+1, '/', len(rows), flush=True)
                if 'error' in result:
                    raise RuntimeError(result)
        state.update(complete=True, stage='complete')
    finally:
        service.stop()
        write_json(ROOT/'results'/f'{key}.status.json', state)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--backend', choices=['pytorch','vllm'], required=True)
    parser.add_argument('--api', choices=['systemone','openai'], required=True)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    run_http(args.backend, args.api, args.smoke)
