"""Check that all three backends score matching image/text prefixes per API."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
hf=[json.loads(line) for line in (ROOT/'results/hf-input-trace-smoke.jsonl').open()]
checks=[]
for api in ['systemone','openai']:
    reference=[row for row in hf if row['api']==api]
    for backend in ['pytorch','vllm']:
        status=json.loads((ROOT/'results'/f'{backend}-{api}-smoke.status.json').read_text())
        assert status['complete'] and status['rows']==12
        pid=status['service_pid']
        name=f'pt-token-trace-{pid}.jsonl' if backend=='pytorch' else f'vllm-input-trace-{pid}.jsonl'
        rows=[json.loads(line) for line in (ROOT/'results'/name).open()]
        assert len(rows)==len(reference)==12,(name,len(rows))
        for i,(row,ref) in enumerate(zip(rows,reference)):
            assert row['scoring_prefix_sha256']==ref['scoring_prefix_sha256'],(api,backend,i,'token prefix mismatch')
            if backend=='pytorch':
                assert row['image_tokens']>0,(api,i,'missing image tokens')
            else:
                assert row['pixel_values_sha256']==ref['pixel_values_sha256'],(api,i,'image tensor mismatch')
            checks.append(dict(api=api,backend=backend,index=i,prefix_equal=True))
(ROOT/'results/smoke-input-audit.json').write_text(json.dumps(dict(passed=True,checks=checks),indent=2))
print('IMAGE_PREFIX_AUDIT_PASSED',len(checks),flush=True)
