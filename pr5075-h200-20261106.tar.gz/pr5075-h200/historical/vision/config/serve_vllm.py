import resource
_fdsoft,_fdhard=resource.getrlimit(resource.RLIMIT_NOFILE)
resource.setrlimit(resource.RLIMIT_NOFILE,(max(_fdsoft,min(65535,_fdhard)),_fdhard))
import os,sys,json,time
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path.home()/'decision-dual-api-2k-20261102/sources/serving/src'))
if __name__=='__main__':
 import vllm
 from transformers import Qwen2Tokenizer
 import intern_decision.inference as inference
 inference.AutoTokenizer=Qwen2Tokenizer
 import hashlib
 original_encode=inference.HFBackend.encode
 def traced_encode(self,row):
  result=original_encode(self,row)
  compiled,batch,positions=result
  ids=batch['input_ids'][0].tolist()
  prefix=ids[:int(positions[0])+1]
  record=dict(api='systemone' if row.get('assets') else 'openai',input_tokens=len(ids),
   scoring_prefix_sha256=hashlib.sha256(json.dumps(prefix,separators=(',',':')).encode()).hexdigest(),
   image_grid_thw=batch['image_grid_thw'].tolist(),
   pixel_values_sha256=hashlib.sha256(batch['pixel_values'].numpy().tobytes()).hexdigest())
  with (R/'results'/f'vllm-input-trace-{os.getpid()}.jsonl').open('a') as stream:stream.write(json.dumps(record)+'\n')
  return result
 inference.HFBackend.encode=traced_encode
 original=vllm.LLM
 cache=os.environ['BENCH_CACHE']=='on';profile=os.environ.get('BENCH_PROFILE','multi');mem=float(os.environ.get('BENCH_MEMORY','.5'))
 buckets=[1,2,4,8,16,32,64,128,256]+list(range(512,8193,512))
 def configured(*a,**kw):
  kw.update(disable_log_stats=False,enforce_eager=True,enable_prefix_caching=cache,gpu_memory_utilization=mem,max_num_batched_tokens=8192,max_num_seqs=128,limit_mm_per_prompt={'image':1,'video':0},compilation_config={'cudagraph_mode':'PIECEWISE','cudagraph_capture_sizes':buckets,'max_cudagraph_capture_size':8192})
  kw.pop('compilation_config',None)
  (R/'results'/f'service-vllm-{profile}-{os.environ["BENCH_CACHE"]}-kwargs.json').write_text(json.dumps(kw,indent=2,default=str)+'\n')
  kw.pop('compilation_config',None)
  model=original(*a,**kw);generate=model.generate
  cfg=model.llm_engine.vllm_config
  resolved=dict(cache={k:getattr(cfg.cache_config,k,None) for k in ['gpu_memory_utilization','enable_prefix_caching','block_size','num_gpu_blocks','mamba_cache_mode','mamba_block_size','mamba_ssm_cache_dtype','prefix_caching_hash_algo']},compilation={k:getattr(cfg.compilation_config,k,None) for k in ['mode','cudagraph_mode','cudagraph_capture_sizes','max_cudagraph_capture_size']},scheduler={k:getattr(cfg.scheduler_config,k,None) for k in ['max_num_batched_tokens','max_num_seqs','enable_chunked_prefill']},dtype=str(cfg.model_config.dtype),max_model_len=cfg.model_config.max_model_len)
  (R/'results'/f'resolved-vllm-{os.environ["BENCH_CACHE"]}-mem{mem}.json').write_text(json.dumps(resolved,indent=2,default=str)+'\n')
  counts=dict(calls=0,decision_prompts=0,submitted_prefix_tokens=0,model_seconds=0.);last_snapshot=[0.]
  def measured(prompts,*args,**kwargs):
   start=time.perf_counter();result=generate(prompts,*args,**kwargs)
   counts['calls']+=1;counts['decision_prompts']+=len(prompts);counts['submitted_prefix_tokens']+=sum(len(p.get('prompt_token_ids',[])) for p in prompts);counts['model_seconds']+=time.perf_counter()-start
   if time.perf_counter()-last_snapshot[0]>=1:
    last_snapshot[0]=time.perf_counter()
    snapshot=dict(counts,sample_time_ns=time.time_ns(),pid=os.getpid(),cache=cache,memory=mem,profile=profile)
    try:snapshot['engine_metrics']=[dict(name=m.name,value=getattr(m,'value',None),labels=getattr(m,'labels',None)) for m in model.get_metrics()]
    except Exception as e:snapshot['metrics_error']=repr(e)
    (R/'results'/f'vllm-{profile}-{os.environ["BENCH_CACHE"]}-counters.json').write_text(json.dumps(snapshot,default=str)+'\n')
   return result
  model.generate=measured
  return model
 vllm.LLM=configured
 # Count the actual prompt list passed by the native adapter; no extra encoding or model invocation.
 # installed on the instance in configured(), below through a factory wrapper
 from intern_decision.serve import main
 main()