"""Package accuracy evidence and scripts; retain source images/parquet remotely."""
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
paths=[ROOT/'README.zh-CN.md',ROOT/'manifest.json',ROOT/'data/records.jsonl']
for folder in ['config','results']:
    paths += [p for p in (ROOT/folder).iterdir() if p.is_file()]
with zipfile.ZipFile(ROOT/'delivery.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
    for path in sorted(set(paths)):
        archive.write(path,str(path.relative_to(ROOT)))
print('PACKAGED',len(paths),(ROOT/'delivery.zip').stat().st_size,flush=True)
