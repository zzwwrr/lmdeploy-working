"""Native Transformers BF16 reference, using each protocol's own input compiler."""
import hashlib
import argparse
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path.home()/'decision-dual-api-2k-20261102/sources/serving/src'
sys.path.insert(0, str(SOURCE))
from evaluate import payload, records, score
from service import MODEL, write_json
from intern_decision.inference import DecisionEngine
import torch
import transformers


def main(smoke=False, api_only=None):
    if not smoke and (ROOT/'results/hf-cancelled.json').exists():
        print('HF_REFERENCE_CANCELLED_BY_USER',flush=True)
        return
    parallel_path=ROOT/'results/parallel-hf.json'
    if not smoke and api_only is None and parallel_path.exists():
        while True:
            state=json.loads(parallel_path.read_text())
            if state.get('error'):
                raise RuntimeError(state['error'])
            if state.get('complete'):
                break
            time.sleep(5)
        with (ROOT/'results/hf-input-trace-formal.jsonl').open('w') as merged:
            for api in ['systemone','openai']:
                with (ROOT/'results'/f'hf-input-trace-formal-{api}.jsonl').open() as source:
                    for line in source:
                        merged.write(line)
        write_json(ROOT/'results/hf-environment.json', {
            api:json.loads((ROOT/'results'/f'hf-environment-{api}.json').read_text())
            for api in ['systemone','openai']})
        return
    engine = DecisionEngine(checkpoint=MODEL, backend='hf', dtype='bfloat16', max_length=16384,
                            temperature=1.99241824, attn_implementation='sdpa')
    gpu_uuid='GPU-'+str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-')
    if os.environ.get('EXPECTED_GPU_UUID'):
        assert gpu_uuid==os.environ['EXPECTED_GPU_UUID'],gpu_uuid
    environment_name=f'hf-environment-{api_only}.json' if api_only else 'hf-environment.json'
    write_json(ROOT/'results'/environment_name, dict(torch=torch.__version__, transformers=transformers.__version__,
        cuda=torch.version.cuda, dtype='bfloat16', attention='sdpa', use_cache=False, temperature=engine.temperature,
        gpu_uuid=gpu_uuid, source=str(SOURCE)))
    original_encode = engine.backend.encode
    active_api = [None]
    phase='smoke' if smoke else 'formal'
    trace_suffix=f'-{api_only}' if api_only else ''
    trace = (ROOT/'results'/f'hf-input-trace-{phase}{trace_suffix}.jsonl').open('w')
    def encode(row):
        compiled, batch, positions = original_encode(row)
        ids = batch['input_ids'][0].tolist()
        prefix = ids[:int(positions[0])+1]
        trace.write(json.dumps(dict(api=active_api[0], input_tokens=len(ids),
            scoring_prefix_sha256=hashlib.sha256(json.dumps(prefix,separators=(',',':')).encode()).hexdigest(),
            image_grid_thw=batch['image_grid_thw'].tolist(),
            pixel_values_sha256=hashlib.sha256(batch['pixel_values'].numpy().tobytes()).hexdigest()))+'\n')
        trace.flush()
        return compiled, batch, positions
    engine.backend.encode = encode
    for api in ([api_only] if api_only else ['systemone','openai']):
        key=f'hf-{api}-{phase}'
        output=ROOT/'results'/f'{key}.jsonl'
        assert not output.exists(),output
        active_api[0]=api
        state=dict(stage='evaluating',rows=0,complete=False)
        with output.open('w') as stream:
            for index,row in enumerate(records(smoke)):
                start=time.perf_counter()
                request=payload(row,api)
                body=engine.predict(request) if api=='systemone' else engine.predict_decisions(request)
                result=dict(id=row['id'],suite=row['suite'],category=row['category'],image_sha256=row['image']['sha256'],
                    response=body,elapsed_ms=(time.perf_counter()-start)*1000,**score(row,body,api))
                stream.write(json.dumps(result,ensure_ascii=False)+'\n')
                stream.flush()
                state['rows']=index+1
                if index%100==0:
                    write_json(ROOT/'results'/f'{key}.status.json',state)
                    print(key,index+1,'/ 12088',flush=True)
        state.update(stage='complete',complete=True)
        write_json(ROOT/'results'/f'{key}.status.json',state)
    trace.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--smoke',action='store_true')
    parser.add_argument('--api',choices=['systemone','openai'])
    args=parser.parse_args()
    main(args.smoke,args.api)
