"""Wait for accuracy inference, then build the audited report."""
import json
import subprocess
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
while True:
    state=json.loads((ROOT/'results/controller.json').read_text())
    if state['stage']=='failed':
        raise RuntimeError(state.get('error'))
    if state['complete']:
        break
    time.sleep(30)
subprocess.run([str(Path.home()/'decision-aiperf/env/bin/python'),str(ROOT/'config/report.py')],check=True)
