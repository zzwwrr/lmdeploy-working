import json,os,subprocess,time
from pathlib import Path
import httpx,psutil
ROOT=Path(__file__).resolve().parents[1]
HOME=Path.home()
MODEL=HOME/'decision-h200/models/Intern-Decision-4B'
GPU_UUID='GPU-32f80b8a-b48a-3cea-0baa-8ecb909fb3aa'

def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def clean_environment():
    env = os.environ.copy()
    for key in ['http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'all_proxy']:
        env.pop(key, None)
    env.update(no_proxy='127.0.0.1,localhost', OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='2',
               MKL_NUM_THREADS='4', TOKENIZERS_PARALLELISM='false')
    return env



def stop_owned(process):
    if process is None:
        return
    try:
        parent = psutil.Process(process.pid)
        assert str(ROOT / 'config') in ' '.join(parent.cmdline())
        children = parent.children(recursive=True)
        parent.terminate()
        _, alive = psutil.wait_procs([parent] + children, timeout=30)
        for child in alive:
            child.kill()
        psutil.wait_procs(alive, timeout=10)
        process.wait(timeout=5)
    except psutil.NoSuchProcess:
        pass


class Service:
    def __init__(self, backend):
        self.backend = backend
        self.process = None
        self.port = 18483 if backend == 'pytorch' else 18482
        self.base_url = f'http://127.0.0.1:{self.port}'

    def start(self):
        self.stop()
        gpu = subprocess.check_output(['nvidia-smi', '-i', '2', '--query-gpu=uuid,memory.used',
                                       '--format=csv,noheader,nounits'], text=True).strip().split(',')
        assert gpu[0] == GPU_UUID and int(gpu[1]) < 100, gpu
        env = clean_environment()
        env.update(CUDA_VISIBLE_DEVICES='2', BENCH_CACHE='on', BENCH_MEMORY='.5', BENCH_PROFILE='multi',
                   CUDA_HOME='/usr/local/cuda', LD_LIBRARY_PATH='/usr/local/cuda/lib64',
                   HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', VLLM_WORKER_MULTIPROC_METHOD='spawn',
                   TORCHINDUCTOR_COMPILE_THREADS='4', MAX_JOBS='4')
        if self.backend == 'pytorch':
            args = [HOME / 'decision-h200-gdr/envs/bench/bin/python', ROOT / 'config/serve_pt.py',
                    'serve', 'api_server', MODEL, '--task', 'intern-decision', '--model-name', 'Intern-Decision-4B',
                    '--server-name', '127.0.0.1', '--server-port', self.port, '--backend', 'pytorch',
                    '--dtype', 'bfloat16', '--max-batch-size', '128', '--cache-max-entry-count', '.1',
                    '--max-prefill-token-num', '8192', '--piecewise-cudagraph-max-tokens', '8192',
                    '--session-len', '16384', '--logprobs-mode', 'raw_logits', '--log-level', 'INFO',
                    '--enable-prefix-caching']
        else:
            args = [HOME / 'decision-h200/envs/vllm/bin/python', ROOT / 'config/serve_vllm.py',
                    '--checkpoint', MODEL, '--backend', 'vllm', '--device', 'cuda', '--host', '127.0.0.1',
                    '--port', self.port, '--dtype', 'bfloat16', '--max-length', '16384',
                    '--temperature', '1.99241824', '--batch-size', '64', '--batch-wait-ms', '5',
                    '--queue-size', '640', '--max-inflight', '640', '--limit-concurrency', '1024',
                    '--torch-num-threads', '4', '--validation-workers', '4',
                    '--vllm-max-num-batched-tokens', '8192', '--vllm-max-num-seqs', '128', '--request-timeout', '30']
        name = f'service-{self.backend}-{time.time_ns()}'
        write_json(ROOT / 'results' / (name + '.json'), dict(args=list(map(str, args)), environment={
            k: env[k] for k in ['CUDA_VISIBLE_DEVICES', 'OMP_NUM_THREADS', 'BENCH_CACHE', 'BENCH_MEMORY']}))
        with (ROOT / 'logs' / (name + '.log')).open('w') as log:
            self.process = subprocess.Popen(list(map(str, args)), env=env, cwd=ROOT, stdout=log,
                                            stderr=subprocess.STDOUT, start_new_session=True)
        deadline = time.monotonic() + 1200
        with httpx.Client(timeout=3, trust_env=False) as client:
            while time.monotonic() < deadline:
                if self.process.poll() is not None:
                    raise RuntimeError(f'{name} exited {self.process.returncode}')
                try:
                    response = client.get(self.base_url + '/v1/models')
                    response.raise_for_status()
                    return
                except httpx.HTTPError:
                    time.sleep(2)
        raise TimeoutError('service startup')

    def stop(self):
        stop_owned(self.process)
        self.process = None
        time.sleep(2)

    def snapshot(self):
        try:
            with httpx.Client(timeout=3, trust_env=False) as client:
                response = client.get(self.base_url + ('/metrics' if self.backend == 'pytorch' else '/health'))
                return dict(time_ns=time.time_ns(), status=response.status_code, text=response.text)
        except Exception as exc:
            return dict(time_ns=time.time_ns(), error=repr(exc))

    def drain(self):
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            snapshot = self.snapshot()
            try:
                if self.backend == 'vllm':
                    health = json.loads(snapshot['text'])
                    idle = health['queue_depth'] == 0 and health['active_requests'] == 0
                else:
                    values = [float(line.split()[-1]) for line in snapshot['text'].splitlines()
                              if line.startswith(('lmdeploy:num_requests_running{', 'lmdeploy:num_requests_waiting{',
                                                  'lmdeploy:num_api_requests_waiting{'))]
                    idle = len(values) >= 2 and not any(values)
                if idle:
                    time.sleep(2)
                    return True
            except (KeyError, ValueError):
                pass
            time.sleep(2)
        return False


