"""Run the two remaining HF reference protocols on separately checked GPUs."""
import subprocess
import time
from pathlib import Path

from service import ROOT, clean_environment, write_json

assignments={
    'systemone': 'GPU-2129bd87-12cd-88c5-8ff3-39de1174a7eb',
    'openai': 'GPU-50ff00e5-cd26-bec0-fef8-b76793382041',
}
inventory=subprocess.check_output(['nvidia-smi','--query-gpu=uuid,memory.used','--format=csv,noheader,nounits'],text=True)
memory={line.split(',')[0]:int(line.split(',')[1]) for line in inventory.strip().splitlines()}
assert all(memory[uuid]<100 for uuid in assignments.values()),memory
assert not any((ROOT/'results'/f'hf-{api}-formal.jsonl').exists() for api in assignments)
state=dict(complete=False,assignments=assignments,jobs={},started_at_ns=time.time_ns())
path=ROOT/'results/parallel-hf.json'
write_json(path,state)
processes={}
try:
    for api,uuid in assignments.items():
        env=clean_environment()
        env.update(CUDA_VISIBLE_DEVICES=uuid,EXPECTED_GPU_UUID=uuid,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
        with (ROOT/'logs'/f'hf-parallel-{api}.log').open('w') as log:
            process=subprocess.Popen([str(Path.home()/'decision-h200-gdr/envs/bench/bin/python'),
                str(ROOT/'config/evaluate_hf.py'),'--api',api],env=env,stdout=log,stderr=subprocess.STDOUT)
        processes[api]=process
        state['jobs'][api]=dict(pid=process.pid,gpu_uuid=uuid,returncode=None)
    write_json(path,state)
    while any(p.poll() is None for p in processes.values()):
        for api,process in processes.items():
            state['jobs'][api]['returncode']=process.poll()
            if process.poll() not in (None,0):
                raise RuntimeError(f'{api} exited {process.returncode}')
        write_json(path,state)
        time.sleep(5)
    for api,process in processes.items():
        assert process.returncode==0,(api,process.returncode)
        state['jobs'][api]['returncode']=process.returncode
    state['complete']=True
except BaseException as exc:
    state['error']=repr(exc)
    raise
finally:
    for process in processes.values():
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=30)
    state['finished_at_ns']=time.time_ns()
    write_json(path,state)
