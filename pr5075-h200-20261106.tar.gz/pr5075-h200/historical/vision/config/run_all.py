"""Smoke-test four native APIs, then run the image accuracy suites sequentially."""
import json
import os
import subprocess
import time
from pathlib import Path

from service import ROOT, GPU_UUID, clean_environment, write_json

PYTHON=Path.home()/'decision-aiperf/env/bin/python'
HF_PYTHON=Path.home()/'decision-h200-gdr/envs/bench/bin/python'
state=dict(complete=False,stage='waiting-for-data',jobs=[],gpu_uuid=GPU_UUID)
if (ROOT/'results/controller.json').exists():
    state=json.loads((ROOT/'results/controller.json').read_text())
    state.update(complete=False,stage='waiting-for-data')
    state.pop('finished_at_ns',None)
    state.pop('error',None)
write_json(ROOT/'results/controller.json',state)
while not (ROOT/'results/dataset-manifest.json').exists():
    time.sleep(10)


def execute(key,args,env=None):
    if any(job['name']==key and job['returncode']==0 for job in state['jobs']):
        return
    state.update(stage=key)
    write_json(ROOT/'results/controller.json',state)
    with (ROOT/'logs'/f'{key}.log').open('w') as log:
        result=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT,env=env)
    state['jobs'].append(dict(name=key,returncode=result.returncode))
    write_json(ROOT/'results/controller.json',state)
    if result.returncode:
        raise RuntimeError(key+' failed')


try:
    env=clean_environment()
    env.update(CUDA_VISIBLE_DEVICES='2',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    for phase in ['smoke','formal']:
        for backend in ['pytorch','vllm']:
            for api in ['systemone','openai']:
                args=[PYTHON,ROOT/'config/evaluate.py','--backend',backend,'--api',api]
                if phase=='smoke':
                    args.append('--smoke')
                execute(f'{backend}-{api}-{phase}',args)
        if phase=='smoke':
            execute('hf-reference-smoke',[HF_PYTHON,ROOT/'config/evaluate_hf.py','--smoke'],env)
            execute('validate-smoke',[PYTHON,ROOT/'config/validate_smoke.py'])
    execute('hf-reference',[HF_PYTHON,ROOT/'config/evaluate_hf.py'],env)
    state.update(stage='complete',complete=True)
except Exception as exc:
    state.update(stage='failed',error=repr(exc))
finally:
    state['finished_at_ns']=time.time_ns()
    write_json(ROOT/'results/controller.json',state)
