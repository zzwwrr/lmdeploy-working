"""Audit full coverage and report labeled accuracy and paired numerical differences."""
import collections
import csv
import hashlib
import itertools
import json
import subprocess
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def metrics(rows, binary):
    correct = sum(row['correct'] for row in rows)
    output = dict(count=len(rows), correct=correct, accuracy=correct/len(rows))
    if binary:
        tp = sum(row['target']=='yes' and row['predicted']=='yes' for row in rows)
        fp = sum(row['target']=='no' and row['predicted']=='yes' for row in rows)
        fn = sum(row['target']=='yes' and row['predicted']=='no' for row in rows)
        tn = len(rows)-tp-fp-fn
        output.update(tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else 0,
                      recall=tp/(tp+fn),f1=2*tp/(2*tp+fp+fn),yes_ratio=(tp+fp)/len(rows))
    return output


def main():
    state = json.loads((ROOT/'results/controller.json').read_text())
    assert state['complete'],state
    manifest = json.loads((ROOT/'results/dataset-manifest.json').read_text())
    records = [json.loads(line) for line in (ROOT/'data/records.jsonl').open()]
    expected = {row['id'] for row in records}
    results, summary, pairs = {}, {}, {}
    for backend in ['pytorch','vllm']:
        for api in ['systemone','openai']:
            key = f'{backend}-{api}'
            path = ROOT/'results'/f'{key}-formal.jsonl'
            rows = [json.loads(line) for line in path.open()]
            assert len(rows)==len(expected)==12088 and {r['id'] for r in rows}==expected
            assert not any('error' in r for r in rows)
            results[key] = {row['id']:row for row in rows}
            summary[key] = {}
            for suite,category in [('pope','random'),('pope','popular'),('pope','adversarial'),('ai2d','test')]:
                selected = [r for r in rows if r['suite']==suite and r['category']==category]
                assert len(selected)==(3088 if suite=='ai2d' else 3000)
                summary[key][suite+'-'+category] = metrics(selected,suite=='pope')
    bad_cases = []
    worst_cases = {}
    for api in ['systemone','openai']:
        for left,right in itertools.combinations(['pytorch','vllm'],2):
            key=f'{left}-{right}-{api}'
            pairs[key]={}
            for suite in ['pope','ai2d']:
                differences,flips,cosines=[],0,[]
                candidates=[]
                for row in records:
                    if row['suite']!=suite:
                        continue
                    a,b=results[left+'-'+api][row['id']],results[right+'-'+api][row['id']]
                    labels=list(a['probabilities'])
                    x=np.array([a['probabilities'][k] for k in labels])
                    y=np.array([b['probabilities'][k] for k in labels])
                    differences.extend((x-y).tolist())
                    candidates.append(dict(id=row['id'],target=row['target'],question=row['question']['instructions'],
                        image=row['image']['path'],max_probability_difference=float(np.abs(x-y).max()),
                        left_prediction=a['predicted'],right_prediction=b['predicted'],
                        left_probabilities=a['probabilities'],right_probabilities=b['probabilities']))
                    cosines.append(float(np.dot(x,y)/(np.linalg.norm(x)*np.linalg.norm(y))))
                    if a['predicted']!=b['predicted']:
                        flips+=1
                        bad_cases.append(dict(pair=key,id=row['id'],target=row['target'],left=a['probabilities'],right=b['probabilities']))
                delta=np.array(differences)
                pairs[key][suite]=dict(count=len(cosines),flips=flips,agreement=1-flips/len(cosines),
                    probability_mae=float(np.abs(delta).mean()),probability_rmse=float(np.sqrt(np.mean(delta**2))),
                    max_probability_difference=float(np.abs(delta).max()),mean_cosine=float(np.mean(cosines)))
                worst_cases[key+'-'+suite]=sorted(candidates,key=lambda r:r['max_probability_difference'],reverse=True)[:20]
    # Runtime prefix equality is checked within each protocol, including visual placeholders.
    token_audit=[]
    for api in ['systemone','openai']:
        traces={}
        for backend in ['pytorch','vllm']:
            status=json.loads((ROOT/'results'/f'{backend}-{api}-formal.status.json').read_text())
            pid=status['service_pid']
            name=f'pt-token-trace-{pid}.jsonl' if backend=='pytorch' else f'vllm-input-trace-{pid}.jsonl'
            rows=[json.loads(line) for line in (ROOT/'results'/name).open()]
            assert len(rows)==12088,(name,len(rows))
            traces[backend]=rows
        matches=sum(a['scoring_prefix_sha256']==b['scoring_prefix_sha256']
                    for a,b in zip(traces['pytorch'],traces['vllm']))
        assert matches==12088,(api,matches)
        assert all(r['image_tokens']>0 for r in traces['pytorch'])
        token_audit.append(dict(api=api,prefix_matches=matches,comparison='PyTorch vs vLLM',visual_tokens_present=True))
    protocol_comparison={}
    for backend in ['pytorch','vllm']:
        protocol_comparison[backend]={}
        for suite in ['pope','ai2d']:
            ids=[r['id'] for r in records if r['suite']==suite]
            flips=sum(results[backend+'-systemone'][key]['predicted']!=results[backend+'-openai'][key]['predicted'] for key in ids)
            protocol_comparison[backend][suite]=dict(count=len(ids),flips=flips,agreement=1-flips/len(ids))
    output=dict(summary=summary,pairs=pairs,input_audit=token_audit,protocol_comparison=protocol_comparison)
    (ROOT/'results/accuracy-summary.json').write_text(json.dumps(output,indent=2))
    (ROOT/'results/probability-worst-cases.json').write_text(json.dumps(worst_cases,ensure_ascii=False,indent=2))
    (ROOT/'results/decision-disagreements.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in bad_cases))
    flat=[dict(combination=key,suite=suite,**stats) for key,groups in summary.items() for suite,stats in groups.items()]
    columns=list(dict.fromkeys(k for row in flat for k in row))
    with (ROOT/'results/accuracy-summary.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=columns)
        writer.writeheader()
        writer.writerows(flat)
    lines=['# POPE与AI2D带图决策效果报告','',
        '本轮使用Intern-Decision-4B固定权重，BF16与温度1.99241824。评测保留原始单图单题形式，逐条C1执行。PT与vLLM分别评估Systemone与OpenAI两种协议，共四组。HF正式参考按用户要求中止，部分输出归档保存。','',
        '## 数据与输入','',
        f"POPE为COCO版本的random/popular/adversarial三类各3,000题，共9,000题。AI2D使用固定版本的3,088题test打包集。图片与标签来源、提交和哈希见dataset-manifest.json。POPE题干逐题对照原作者仓库，替换了{manifest['pope']['official_crosscheck']['text_replacements']}条打包版本存在差异的文本，记录见pope-text-replacements.json。",'',
        f"统一转换为RGB PNG，并在保持宽高比的前提下满足Systemone的280–1568像素边长要求。共{manifest['image_preparation']['unique_source_images']}张不同源图片，其中{manifest['image_preparation']['resized']}张进行尺寸调整，{manifest['image_preparation']['padded']}张补白。两协议使用完全相同的传输图片字节。服务端继续执行各自既定的视觉预处理与单图token预算。",'',
        'Systemone将图片嵌入state引用位置，OpenAI输入图片位于提示前部。各协议分别报告效果；后端数值适配仅在相同协议内比较。', '',
        '## POPE','',
        '| 后端/协议 | 设置 | 正确/总数 | Accuracy | Precision | Recall | F1 | Yes比例 |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for key,groups in summary.items():
        for category in ['random','popular','adversarial']:
            m=groups['pope-'+category]
            lines.append(f"| {key} | {category} | {m['correct']}/{m['count']} | {m['accuracy']:.2%} | {m['precision']:.2%} | {m['recall']:.2%} | {m['f1']:.2%} | {m['yes_ratio']:.2%} |")
    lines+=['','## AI2D','', '| 后端/协议 | 正确/总数 | Accuracy |','|---|---:|---:|']
    for key,groups in summary.items():
        m=groups['ai2d-test']
        lines.append(f"| {key} | {m['correct']}/{m['count']} | {m['accuracy']:.2%} |")
    lines+=['','## 相同协议下的数值适配','',
        '| 对照 | 数据 | 决策分歧/总数 | Top1一致率 | 概率MAE | 概率RMSE | 最大概率差 |',
        '|---|---|---:|---:|---:|---:|---:|']
    for key,groups in pairs.items():
        for suite,m in groups.items():
            lines.append(f"| {key} | {suite} | {m['flips']}/{m['count']} | {m['agreement']:.3%} | {m['probability_mae']:.6f} | {m['probability_rmse']:.6f} | {m['max_probability_difference']:.6f} |")
    lines+=['','## 两协议的决策变化','',
        '此表使用相同题目和图片，但两种协议的提示结构及图片插入位置不同。','',
        '| 后端 | 数据 | 两协议决策不同/总数 | Top1一致率 |',
        '|---|---|---:|---:|']
    for backend,groups in protocol_comparison.items():
        for suite,m in groups.items():
            lines.append(f"| {backend} | {suite} | {m['flips']}/{m['count']} | {m['agreement']:.3%} |")
    lines+=['','## 结果解读','',
        '同协议下PT与vLLM的标签准确率接近。候选概率仍存在明显的个别差异，POPE最大绝对差约0.309，AI2D约0.213。Top1分歧与概率最大差分别保留在decision-disagreements.jsonl与probability-worst-cases.json，适配容差可据此单独评审。','',
        'AI2D上两协议之间约5.7%–5.9%的题目改变Top1，而同协议后端间约1.4%–1.5%的题目改变Top1。协议的图片插入位置与提示结构均有差别，需要结合这些输入条件解释结果。','',
        'POPE的正例召回约83.5%–83.7%，三种负采样设置分别列出Precision、Recall与F1，可继续查看漏识别和误报的具体图像。']
    lines+=['','## 复核和解释范围','',
        '- 四组均完整覆盖12,088题，失败与缺失单独检查。POPE按yes概率大于0.5判yes，平局判no；AI2D按候选概率argmax评分。',
        '- 所有正式请求均在相同协议内通过PT与vLLM的评分前缀token哈希核对；PT请求均含视觉token。',
        '- PT使用piecewise graph；vLLM视觉编译初始化发生NoneType.size错误后改用eager模式。两个部署后端启用前缀缓存，客户端仅维持一条在途请求，失败启动日志保留。',
        '- 概率MAE/RMSE按候选值微平均，标签效果与后端数值一致性分别报告。',
        '- 同一图片可能对应多道题，POPE三类设置共享图片及部分问题。精度差异按实际分母列出。',
        '- 本轮为候选评分式决策模型的适配评测，提示格式和统一图片处理均已记录。',
        '- 原始预测、候选概率、usage、输入哈希、差异题目和脚本保留在实验目录。',
        '- 本轮交付聚焦算法效果。客户端耗时仅作执行记录。','']
    (ROOT/'results/POPE_AI2D带图决策效果报告.zh-CN.md').write_text('\n'.join(lines))
    audit=dict(complete=True,records=12088,combinations=4,formal_predictions=12088*4,
               prefix_checks=token_audit,dataset_sha256=manifest['records_sha256'])
    if (ROOT/'results/hf-cancelled.json').exists():
        audit['hf_cancelled']=json.loads((ROOT/'results/hf-cancelled.json').read_text())
    (ROOT/'results/final-audit.json').write_text(json.dumps(audit,indent=2))
    hashes={}
    for folder in ['config','results']:
        for path in (ROOT/folder).glob('*'):
            if path.is_file():
                hashes[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    for path in [ROOT/'data/records.jsonl']:
        hashes[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    (ROOT/'manifest.json').write_text(json.dumps(hashes,indent=2))
    print('VISION_ACCURACY_AUDIT_COMPLETE',json.dumps(audit),flush=True)


if __name__=='__main__':
    main()
