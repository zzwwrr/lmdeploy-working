"""Fetch pinned POPE/AI2D test data and prepare common image bytes for both APIs."""
import collections
import hashlib
import io
import json
import math
import time
from pathlib import Path

import httpx
import pyarrow as pa
import pyarrow.parquet as pq
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
DATASETS = {
    'pope': ('lmms-lab-encoder/POPE', '4db1276663dfa5eb8ad16a52d24c31a09e470896'),
    'ai2d': ('lmms-lab-encoder/ai2d', 'c83a9b9692933aff8349157c88a413df9d02c4e5'),
}


def fetch(client, url, path, expected=None):
    if path.exists() and (expected is None or hashlib.sha256(path.read_bytes()).hexdigest() == expected):
        return
    for attempt in range(4):
        try:
            temporary = path.with_suffix(path.suffix + '.part')
            digest = hashlib.sha256()
            with client.stream('GET', url) as response:
                response.raise_for_status()
                with temporary.open('wb') as output:
                    for chunk in response.iter_bytes(1024 * 1024):
                        digest.update(chunk)
                        output.write(chunk)
            assert expected is None or digest.hexdigest() == expected, (path, digest.hexdigest(), expected)
            temporary.replace(path)
            return
        except Exception:
            if attempt == 3:
                raise
            time.sleep(3 * (attempt + 1))


def canonical_image(raw, cache):
    source_hash = hashlib.sha256(raw).hexdigest()
    if source_hash in cache:
        return cache[source_hash]
    with Image.open(io.BytesIO(raw)) as original:
        original.load()
        image = original.convert('RGB')
    width, height = image.size
    scale = max(1., 280 / min(width, height))
    scale = min(scale, 1568 / max(width, height))
    target = (max(1, round(width * scale)), max(1, round(height * scale)))
    if target != image.size:
        image = image.resize(target, Image.Resampling.LANCZOS)
    padded = min(image.size) < 280
    if padded:
        canvas = Image.new('RGB', (max(280, image.width), max(280, image.height)), 'white')
        canvas.paste(image, ((canvas.width - image.width) // 2, (canvas.height - image.height) // 2))
        image = canvas
    output = io.BytesIO()
    image.save(output, format='PNG')
    content = output.getvalue()
    digest = hashlib.sha256(content).hexdigest()
    path = ROOT / 'data/images' / (digest + '.png')
    if not path.exists():
        path.write_bytes(content)
    assert min(image.size) >= 280 and max(image.size) <= 1568 and len(content) < 10 * 1024**2
    result = dict(path=str(path.relative_to(ROOT)), source_sha256=source_hash, sha256=digest,
                  original_size=[width, height], submitted_size=list(image.size),
                  resized=target != (width, height), padded=padded)
    cache[source_hash] = result
    return result


def main():
    pa.set_cpu_count(2)
    pa.set_io_thread_count(2)
    for folder in ['data/images', 'data/raw', 'results']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    manifest, records, images = {}, [], {}
    with httpx.Client(proxy='http://127.0.0.1:13301', timeout=180, follow_redirects=True) as client:
        for suite, (repo, revision) in DATASETS.items():
            response = client.get(f'https://huggingface.co/api/datasets/{repo}/tree/{revision}?recursive=true&limit=1000')
            response.raise_for_status()
            files = [f for f in response.json() if f['type'] == 'file' and f['path'].startswith('data/test-')]
            info = dict(repo=repo, revision=revision, split='test', files=[])
            index = 0
            for entry in sorted(files, key=lambda f: f['path']):
                path = ROOT / 'data/raw' / (suite + '-' + Path(entry['path']).name)
                fetch(client, f'https://huggingface.co/datasets/{repo}/resolve/{revision}/{entry["path"]}',
                      path, entry['lfs']['oid'])
                file_rows = 0
                for batch in pq.ParquetFile(path).iter_batches(batch_size=32, use_threads=False):
                    for row in batch.to_pylist():
                        media = canonical_image(row['image']['bytes'], images)
                        if suite == 'pope':
                            category = row['category']
                            question = dict(type='noul', instructions=row['question'])
                            target = row['answer'].lower()
                            assert target in ['yes', 'no']
                            source = dict(question_id=row['question_id'], image_source=row['image_source'], category=category)
                            identity = f'pope-{category}-{row["question_id"]}'
                        else:
                            category = 'test'
                            assert len(row['options']) == 4 and int(row['answer']) in range(4)
                            question = dict(type='choice', instructions=row['question'], criteria=dict(zip('ABCD', row['options'])))
                            target = 'ABCD'[int(row['answer'])]
                            source = dict(row_index=index, image_path=row['image'].get('path'))
                            identity = f'ai2d-{index:05}'
                        records.append(dict(id=identity, suite=suite, category=category, question=question,
                                            target=target, image=media, source=source))
                        index += 1
                        file_rows += 1
                info['files'].append(dict(path=entry['path'], sha256=entry['lfs']['oid'], bytes=path.stat().st_size, rows=file_rows))
                print('PREPARED', suite, path.name, file_rows, flush=True)
            info['rows'] = index
            manifest[suite] = info
        # Check each packaged POPE label/question/image against the original release.
        response = client.get('https://api.github.com/repos/RUCAIBox/POPE/commits/main')
        response.raise_for_status()
        revision = response.json()['sha']
        matched = 0
        text_replacements = []
        for category in ['adversarial', 'popular', 'random']:
            path = ROOT / 'data/raw' / f'official-coco-pope-{category}.json'
            fetch(client, f'https://raw.githubusercontent.com/RUCAIBox/POPE/{revision}/output/coco/coco_pope_{category}.json', path)
            original = {str(r['question_id']): r for r in map(json.loads, path.open()) if r}
            selected = [r for r in records if r['suite'] == 'pope' and r['category'] == category]
            assert len(original) == len(selected) == 3000
            for row in selected:
                reference = original[str(row['source']['question_id'])]
                assert reference['label'] == row['target']
                assert Path(reference['image']).stem == row['source']['image_source']
                if reference['text'] != row['question']['instructions']:
                    text_replacements.append(dict(id=row['id'], packaged=row['question']['instructions'], official=reference['text']))
                    row['question']['instructions'] = reference['text']
                matched += 1
        manifest['pope']['official_crosscheck'] = dict(repo='RUCAIBox/POPE', revision=revision, matched=matched,
                                                     text_replacements=len(text_replacements))
        (ROOT/'results/pope-text-replacements.json').write_text(json.dumps(text_replacements,indent=2))
    assert len(records) == 12088 and len({r['id'] for r in records}) == len(records)
    assert manifest['pope']['rows'] == 9000 and manifest['ai2d']['rows'] == 3088
    path = ROOT / 'data/records.jsonl'
    path.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records))
    manifest['records_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest['image_preparation'] = dict(unique_source_images=len(images), resized=sum(x['resized'] for x in images.values()),
        padded=sum(x['padded'] for x in images.values()), common_transport='RGB PNG; both APIs use identical bytes',
        rationale='Meet the common Systemone/OpenAI image dimension contract without cropping or distorting aspect ratio')
    manifest['protocol_note'] = 'Systemone embeds its asset within state; OpenAI places its input image before state/schema. Compare backend numerics within each protocol.'
    (ROOT / 'results/dataset-manifest.json').write_text(json.dumps(manifest, indent=2))
    print('DATASET_READY', json.dumps(manifest), flush=True)


if __name__ == '__main__':
    main()
