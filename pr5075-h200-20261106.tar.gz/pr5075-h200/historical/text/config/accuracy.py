import asyncio,argparse,json,sys,time,hashlib,math,collections
from pathlib import Path
from types import SimpleNamespace
import httpx
from jevbench.scoring import score_task
from jevbench.metrics import brier_score,ece_top_label
S=Path.home()/'decision-h200/repos/Intern-Decision';sys.path.insert(0,str(S))
from src.inputs.schema import _options
R=Path.home()/'decision-aiperf'
def score_record(row,response):
 answers=response['answers'];assert set(answers)==set(row['payload']['questions'])
 scores={}
 for field,q in row['payload']['questions'].items():
  labels=[str(v) for v,_ in _options(q)]
  task=SimpleNamespace(question=q,labels=labels,expected=row['targets'][field])
  answer=answers[field]
  probs=answer.get('probabilities')
  if probs is None and q['type']=='noul' and 'noul' in answer:
   py=float(answer['noul']);probs={'no':1-py,'yes':py}
  result=score_task(probs,task)
  if not result['valid'] or not result['strict_valid']:raise ValueError('Invalid probability distribution '+str(result))
  result['brier']=brier_score(result['probs'],task.expected,labels);scores[field]=result
 if response.get('input_ids_sha256'):assert response['input_ids_sha256']==row['input_ids_sha256'],'Tokenization mismatch'
 return scores

def aggregate(predictions):
 suites=collections.defaultdict(lambda:dict(rows=0,valid_rows=0,fields=0,correct=0,failed_fields=0,pairs=[],brier=[]))
 for r in predictions:
  s=suites[r['suite']];s['rows']+=1;s['fields']+=r['field_count']
  if r.get('error'):s['failed_fields']+=r['field_count'];continue
  s['valid_rows']+=1
  for x in r['scores'].values():s['correct']+=int(x['correct']);s['pairs'].append((max(x['probs'].values()),x['correct']));s['brier'].append(x['brier'])
 for s in suites.values():
  s['accuracy']=s['correct']/s['fields'];s['ece']=ece_top_label(s.pop('pairs'),n_bins=10);bs=s.pop('brier');s['brier']=sum(bs)/len(bs) if bs else None
 return dict(suites=suites,macro_accuracy=sum(s['accuracy'] for s in suites.values())/len(suites),micro_accuracy=sum(s['correct'] for s in suites.values())/sum(s['fields'] for s in suites.values()),rows=sum(s['rows'] for s in suites.values()),fields=sum(s['fields'] for s in suites.values()),failed_fields=sum(s['failed_fields'] for s in suites.values()))

async def run(a):
 rows=[json.loads(x) for x in (R/'data'/a.dataset).read_text().splitlines()]
 output=R/'results'/f'accuracy-{a.backend}-c{a.concurrency}.jsonl'
 if output.exists():raise FileExistsError(output)
 queue=iter(rows);predictions=[];started=time.perf_counter();sem=asyncio.Semaphore(a.concurrency)
 async with httpx.AsyncClient(timeout=180,trust_env=False,limits=httpx.Limits(max_connections=a.concurrency,max_keepalive_connections=a.concurrency)) as client:
  with output.open('w') as f:
   async def worker():
    for row in queue:
     t=time.perf_counter();r=dict(id=row['id'],suite=row['suite'],source_line=row['source_line'],field_count=len(row['targets']),payload_sha256=row['payload_sha256'])
     try:
      response=await client.post(a.url,json=row['payload']);response.raise_for_status();body=response.json();r['scores']=score_record(row,body);r['response']=body
     except Exception as e:r['error']=repr(e)
     r['elapsed_ms']=(time.perf_counter()-t)*1000;predictions.append(r);f.write(json.dumps(r,ensure_ascii=False)+'\n');f.flush()
     if len(predictions)%250==0:print(json.dumps(dict(completed=len(predictions),total=len(rows),errors=sum('error' in p for p in predictions))),flush=True)
   await asyncio.gather(*(worker() for _ in range(a.concurrency)))
 report=aggregate(predictions);report.update(backend=a.backend,concurrency=a.concurrency,wall_seconds=time.perf_counter()-started,dataset=a.dataset,dataset_sha256=hashlib.sha256((R/'data'/a.dataset).read_bytes()).hexdigest(),complete=len(predictions)==len(rows),scorer='jevbench@7ce310c7262ed49cc85853339a8a42459298e3f3; exact labels; lexicographic tie-breaking; all failed fields count incorrect')
 output.with_suffix('.summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
 if report['failed_fields']:sys.exit(2)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--backend',required=True);p.add_argument('--url',required=True);p.add_argument('--concurrency',type=int,default=8);p.add_argument('--dataset',default='accuracy-records.jsonl');asyncio.run(run(p.parse_args()))