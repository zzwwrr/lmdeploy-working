import os,sys,json,time,signal,subprocess,urllib.request,traceback
from pathlib import Path
R=Path.home()/'decision-aiperf';H=Path.home()/'decision-h200';G=Path.home()/'decision-h200-gdr'
state=json.loads((R/'results/run-status.json').read_text());state.pop('error',None);state['stage']='resuming';own=None;clientproc=None

def save():(R/'results/run-status.json').write_text(json.dumps(state,indent=2)+'\n')
def call(args,log,timeout=1200):
 global clientproc
 state['stage']=log;save()
 with (R/'logs'/(log+'.log')).open('w') as f:
  clientproc=subprocess.Popen([str(x) for x in args],stdout=f,stderr=subprocess.STDOUT,env=clientenv,start_new_session=True)
  try:rc=clientproc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(clientproc.pid,signal.SIGTERM);raise
  finally:clientproc=None
 if rc:raise RuntimeError(f'{log} exit={rc}')
def stop():
 global own
 if own and own.poll() is None:
  os.killpg(own.pid,signal.SIGTERM)
  try:own.wait(timeout=75)
  except subprocess.TimeoutExpired:os.killpg(own.pid,signal.SIGKILL);own.wait()
 own=None;time.sleep(3)

def start(backend):
 global own
 state['stage']='start-'+backend;save()
 env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='2',TM_GDR_FORCE_LEGACY='0',TM_GDR_CP_LEVEL='2',CUDA_HOME='/usr/local/cuda',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_WORKER_MULTIPROC_METHOD='spawn',no_proxy='localhost,127.0.0.1')
 env['LD_LIBRARY_PATH']='/usr/local/cuda/lib64:'+env.get('LD_LIBRARY_PATH','')
 if backend=='vllm':
  args=[H/'envs/vllm/bin/python',R/'config/vllm_http.py','--checkpoint',H/'models/Intern-Decision-4B','--backend','vllm','--device','cuda','--host','127.0.0.1','--port','18182','--dtype','bfloat16','--max-length','16384','--temperature','1.99241824','--batch-size','64','--batch-wait-ms','5','--queue-size','640','--max-inflight','640','--limit-concurrency','1024','--torch-num-threads','4','--validation-workers','4','--vllm-max-num-batched-tokens','16384','--vllm-max-num-seqs','64','--request-timeout','180'];cwd=H/'repos/intern-decision-inference';port=18182
 else:
  args=[G/'envs/bench/bin/python',R/'config/lm_http.py','--backend',backend,'--port','18183'];cwd=R;port=18183
 logfile=(R/'logs'/('service-'+backend+'.log')).open('w')
 own=subprocess.Popen([str(x) for x in args],cwd=cwd,env=env,stdout=logfile,stderr=subprocess.STDOUT,start_new_session=True)
 state['service_pid']=own.pid;save();deadline=time.monotonic()+900
 while time.monotonic()<deadline:
  if own.poll() is not None:raise RuntimeError(f'{backend} startup exited {own.returncode}')
  try:
   with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(f'http://127.0.0.1:{port}/health',timeout=2) as x:
    health=json.load(x)
   if backend=='vllm' and not health.get('model_loaded',True):raise RuntimeError('not ready')
   (R/'results'/f'health-{backend}.json').write_text(json.dumps(health,indent=2)+'\n');return f'http://127.0.0.1:{port}'+('/v1/systemone' if backend=='vllm' else '/v1/jev')
  except Exception:time.sleep(2)
 raise TimeoutError('startup '+backend)

clientenv=os.environ.copy()
for key in ['CUDA_VISIBLE_DEVICES','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','http_proxy','https_proxy','HTTP_PROXY','HTTPS_PROXY']:clientenv.pop(key,None)
clientenv.update(OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',TOKENIZERS_PARALLELISM='false',no_proxy='localhost,127.0.0.1')
try:
 for backend in ['vllm']:
  url=start(backend)
  call([R/'env/bin/python',R/'config/accuracy.py','--backend',backend,'--url',url,'--concurrency','8'],'accuracy-'+backend,1200)
  for concurrency in [1,8,32,64]:
   for rate in [10,50,200]:
    name=f'{backend}-c{concurrency}-r{rate}'
    args=[R/'env/bin/aiperf','profile','--model','Intern-Decision-4B','--url',url,'--endpoint-type','raw','--custom-dataset-type','inputs_json','--input-file',R/'data/stress-inputs.json','--tokenizer',H/'models/Intern-Decision-4B','--extra-inputs','response_field:to_string(answers)','--request-rate',str(rate),'--arrival-pattern','poisson','--concurrency',str(concurrency),'--benchmark-duration','30','--benchmark-grace-period','60','--warmup-request-count','32','--warmup-request-rate','50','--warmup-concurrency',str(concurrency),'--dataset-sampling-strategy','shuffle','--random-seed','20261030','--export-level','raw','--no-gpu-telemetry','--no-server-metrics','--ui','none','--workers-max','4','--output-artifact-dir',R/'results'/name]
    call(args,name,360)
    d=json.loads((R/'results'/name/'profile_export_aiperf.json').read_text())
    state['runs'].append(dict(name=name,backend=backend,concurrency=concurrency,target_rps=rate,rps=d.get('request_throughput',{}).get('avg'),error_rate=d.get('request_error_rate',{}).get('avg')));save()
    print('RUN_PASS',json.dumps(state['runs'][-1]),flush=True)
  stop()
 state['stage']='complete';state['complete']=True;save()
except BaseException:
 state['error']=traceback.format_exc();save();raise
finally:
 if clientproc and clientproc.poll() is None:os.killpg(clientproc.pid,signal.SIGTERM)
 stop();save()