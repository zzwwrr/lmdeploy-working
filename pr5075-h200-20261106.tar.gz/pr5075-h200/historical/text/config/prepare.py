import sys,json,hashlib,collections,statistics,random,copy
from pathlib import Path
R=Path.home()/'decision-aiperf';S=Path.home()/'decision-h200/repos/Intern-Decision'
sys.path.insert(0,str(S))
from src.eval.verify_bundle import verify
from src.inputs.schema import compile_row,_answer_value,_options
from transformers import AutoTokenizer
M=Path.home()/'decision-h200/models/Intern-Decision-4B'
tok=AutoTokenizer.from_pretrained(M,local_files_only=True)
manifest=json.loads((S/'benchmarks/accuracy-v1/manifest.json').read_text())
print(verify(S/'benchmarks/accuracy-v1'),flush=True)
allrows=[];stats={};stress=[]
for suite,entry in manifest['datasets'].items():
 rows=[]
 for line_no,line in enumerate((S/'benchmarks/accuracy-v1'/entry['path']).open(),1):
  raw=json.loads(line)
  payload={'state':raw['state'],'questions':raw.get('questions') or {'decision':raw['question']}}
  assert not raw.get('images'), 'Multimodal record needs explicit handling'
  assert all('answer' not in q for q in payload['questions'].values()),'Inline answer leakage'
  compiled=compile_row(payload,include_targets=False)
  ids=tok.apply_chat_template(compiled.messages,tokenize=True,add_generation_prompt=False,enable_thinking=False,add_vision_id=True)
  targets={f:str(raw['expected']) if 'question' in raw else _answer_value(q,raw.get('targets',{}).get(f)) for f,q in payload['questions'].items()}
  assert all(v is not None for v in targets.values())
  item=dict(id=suite+':'+str(line_no),original_id=raw['id'],suite=suite,source_line=line_no,payload=payload,targets=targets,tokens=len(ids),input_ids_sha256=hashlib.sha256(json.dumps(ids).encode()).hexdigest(),payload_sha256=hashlib.sha256(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()).hexdigest(),gold_probs=raw.get('gold_probs'))
  rows.append(item)
 stats[suite]=dict(rows=len(rows),decisions=sum(len(r['targets']) for r in rows),min_tokens=min(r['tokens'] for r in rows),max_tokens=max(r['tokens'] for r in rows),mean_tokens=statistics.mean(r['tokens'] for r in rows))
 allrows+=rows;stress+=random.Random(20261030).sample(rows,min(32,len(rows)))
 print(suite,stats[suite],flush=True)
(R/'data/accuracy-records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in allrows))
(R/'data/stress-inputs.json').write_text(json.dumps(dict(data=[dict(session_id=r['id'],payloads=[r['payload']]) for r in stress]),ensure_ascii=False))
(R/'data/stress-records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in stress))
(R/'results/dataset-audit.json').write_text(json.dumps(dict(verification=verify(S/'benchmarks/accuracy-v1'),suites=stats,stress_rows=len(stress),stress_tokens=[r['tokens'] for r in stress],stress_source_ids=[r['id'] for r in stress],max_tokens=max(r['tokens'] for r in allrows),model=str(M)),indent=2)+'\n')
assert len(allrows)==10751 and sum(len(r['targets']) for r in allrows)==12351
print('PREP_COMPLETE',max(r['tokens'] for r in allrows),flush=True)