import json,sys,hashlib
from pathlib import Path
R=Path.home()/'decision-aiperf'
from intern_decision.inference import compile_row
from transformers import AutoTokenizer
M=Path.home()/'decision-h200/models/Intern-Decision-4B';tok=AutoTokenizer.from_pretrained(M,local_files_only=True)
errors=[];n=0
for line in (R/'data/accuracy-records.jsonl').open():
 r=json.loads(line);c=compile_row(r['payload']);text=tok.apply_chat_template(c.messages,tokenize=False,add_generation_prompt=False,enable_thinking=False,add_vision_id=True);ids=tok(text,add_special_tokens=False)['input_ids'];n+=1
 if hashlib.sha256(json.dumps(ids).encode()).hexdigest()!=r['input_ids_sha256']:errors.append(r['id'])
(R/'results/vllm-tokenization-preflight.json').write_text(json.dumps(dict(records=n,mismatches=errors,passed=n==10751 and not errors),indent=2)+'\n')
print(n,'records',len(errors),'mismatches',flush=True)
if errors:sys.exit(1)