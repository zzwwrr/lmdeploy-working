"""Test-only HTTP facade around LMDeploy engines; no repository code changes."""
import argparse,asyncio,inspect,json,os,sys,time,hashlib,subprocess
from pathlib import Path
from contextlib import asynccontextmanager
from dataclasses import asdict

def main():
 p=argparse.ArgumentParser();p.add_argument('--backend',choices=['pytorch','turbomind'],required=True);p.add_argument('--port',type=int,default=18183)
 a=p.parse_args();root=Path.home()/'decision-aiperf';gdr=Path.home()/'decision-h200-gdr';model=Path.home()/'decision-h200/models/Intern-Decision-4B'
 tree=gdr/'repos'/('lmdeploy-tm' if a.backend=='turbomind' else 'lmdeploy-pt')
 sys.meta_path=[f for f in sys.meta_path if 'editable' not in repr(f).lower()];sys.path.insert(0,str(tree))
 import torch,lmdeploy,uvicorn
 from fastapi import FastAPI,Request,HTTPException
 from transformers import AutoTokenizer
 from lmdeploy.intern_decision_encoding import compile_row,decode_answers,ANSWER_SYMBOLS,DECISION_TOKEN
 from lmdeploy.messages import GenerationConfig,PytorchEngineConfig,TurbomindEngineConfig,ResponseType
 assert Path(lmdeploy.__file__).resolve().is_relative_to(tree.resolve())
 torch.set_num_threads(4)
 common=dict(tp=1,max_batch_size=64,dtype='bfloat16',session_len=16384,max_prefill_token_num=16384,cache_max_entry_count=.1,enable_prefix_caching=False)
 config=PytorchEngineConfig(**common,eager_mode=False,piecewise_cudagraph_max_tokens=8192,enable_mp_engine=True,distributed_executor_backend='uni',logprobs_mode='raw_logits') if a.backend=='pytorch' else TurbomindEngineConfig(**common)
 state={};counter=0
 @asynccontextmanager
 async def lifespan(app):
  tok=AutoTokenizer.from_pretrained(model,local_files_only=True);state['tok']=tok;state['marker']=tok.convert_tokens_to_ids(DECISION_TOKEN)
  state['extra']=sorted({tok.convert_tokens_to_ids(c) for c in ANSWER_SYMBOLS})
  if a.backend=='pytorch':
   from lmdeploy.pytorch.engine import Engine
   engine=Engine.from_pretrained(str(model),engine_config=config,trust_remote_code=True);ready=engine.start_loop()
   if inspect.isawaitable(ready):await ready
  else:
   from lmdeploy.turbomind import TurboMind
   engine=TurboMind(str(model),engine_config=config)
  state['engine']=engine;state['pool']=asyncio.Queue()
  for _ in range(64):state['pool'].put_nowait(engine.create_instance())
  state['meta']=dict(backend=a.backend,source=lmdeploy.__file__,commit=subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True).strip(),config=json.loads(json.dumps(asdict(config),default=str)),gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),torch=torch.__version__,cuda=torch.version.cuda,temperature=1.99241824,adapter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
  (root/'results'/f'service-{a.backend}-metadata.json').write_text(json.dumps(state['meta'],indent=2)+'\n')
  try:yield
  finally:
   closed=engine.close()
   if inspect.isawaitable(closed):await closed
 app=FastAPI(lifespan=lifespan)
 @app.get('/health')
 async def health():return dict(ready=True,**state['meta'])
 def prepare(body):
  if set(body)-{'state','questions','images'}:raise ValueError('Only state/questions/images accepted')
  if body.get('images'):raise ValueError('This benchmark is text-only')
  questions=body['questions'];compiled=compile_row(body)
  text=state['tok'].apply_chat_template(compiled.messages,tokenize=False,add_generation_prompt=False,enable_thinking=False,add_vision_id=True)
  ids=state['tok'](text,add_special_tokens=False)['input_ids']
  if len(ids)>16383:raise ValueError(f'Overlength input {len(ids)}, no truncation allowed')
  markers=[i for i,v in enumerate(ids) if v==state['marker']]
  if len(markers)!=len(compiled.fields) or markers[0]<1:raise ValueError('Marker mismatch')
  candidates=[[state['tok'].convert_tokens_to_ids(s) for s in compiled.symbols[f]] for f in compiled.fields]
  return questions,compiled,ids,markers,candidates
 @app.post('/v1/jev')
 async def predict(req:Request):
  nonlocal counter
  started=time.perf_counter()
  try:prepared=await asyncio.to_thread(prepare,await req.json())
  except (KeyError,ValueError,TypeError) as e:raise HTTPException(400,str(e))
  questions,compiled,ids,markers,candidates=prepared
  instance=await state['pool'].get();counter+=1;sid=counter
  try:
   start=markers[0]-1;count=len(ids)-start-1
   gen=GenerationConfig(max_new_tokens=0,logprobs=0,logprob_start_len=start,logprob_extra_token_ids=state['extra']) if a.backend=='pytorch' else GenerationConfig(max_new_tokens=1,logprobs=0,logprob_start_len=start,output_logits='all',top_k=1,ignore_eos=True)
   last=None
   async for chunk in instance.async_stream_infer(session_id=sid,input_ids=ids,gen_config=gen,stream_output=False):last=chunk
   if last is None or last.status!=ResponseType.FINISH:raise RuntimeError('Engine did not finish')
   offsets=[m-1-start for m in markers]
   if a.backend=='pytorch':
    assert last.logprobs is not None and len(last.logprobs)==count
    scores=[[float(last.logprobs[i][token]) for token in cs] for i,cs in zip(offsets,candidates)]
   else:
    assert last.logits is not None and last.logits.shape[0]==count
    scores=[[float(last.logits[i,token]) for token in cs] for i,cs in zip(offsets,candidates)]
   answers=decode_answers(questions,compiled.fields,scores,temperature=1.99241824)
   return dict(answers=answers,usage=dict(input_tokens=len(ids),decision_count=len(answers),generated_tokens=0),candidate_scores=scores,input_ids_sha256=hashlib.sha256(json.dumps(ids).encode()).hexdigest(),timing=dict(server_ms=(time.perf_counter()-started)*1000))
  finally:state['pool'].put_nowait(instance)
 uvicorn.run(app,host='127.0.0.1',port=a.port,workers=1,access_log=False,timeout_graceful_shutdown=60)
if __name__=='__main__':main()