import json,hashlib,math,statistics,collections
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
R=Path.home()/'decision-aiperf';O=R/'audits/20261101';O.mkdir(parents=True,exist_ok=True)
gold={r['id']:r for r in map(json.loads,(R/'data/stress-records.jsonl').open())}
base={r['id']:r for r in map(json.loads,(R/'results/accuracy-pytorch-c8.jsonl').open())}
manifest=json.loads((R/'results/artifact-manifest.json').read_text());T=1.99241824;out=[]
for path in sorted((R/'results').glob('pytorch-c*-r*')):
 if not path.is_dir():continue
 s=json.loads((path/'profile_export_aiperf.json').read_text());file=path/'profile_export_raw.jsonl';digest=hashlib.sha256(file.read_bytes()).hexdigest();assert digest==manifest[str(file.relative_to(R))]['sha256']
 rows=[];phases=collections.Counter();lat=[];dispatch=[];events=[];unique=set();ids=set();countfields=flips=errors=0;maxpd=maxsoft=0.;starts=[];lasts=[];tokens=[];correct=0
 for line in file.open():
  r=json.loads(line);m=r['metadata'];phase=m.get('phase_kind',m.get('benchmark_phase'));phases[phase]+=1
  if phase!='profiling':continue
  assert m['turn_index']==0 and not m['was_cancelled'] and not m['context_overflow_skip']
  assert m['x_request_id'] not in ids;ids.add(m['x_request_id'])
  assert r['status']==200 and len(r['responses'])==1
  g=gold[m['conversation_id']];b=base[g['id']];assert 'error' not in b and r['payload']==g['payload'];unique.add(g['id']);assert set(r['payload'])=={'state','questions'}
  body=json.loads(r['responses'][-1]['text']);assert body['input_ids_sha256']==g['input_ids_sha256'];assert body['usage']['input_tokens']==g['tokens'] and body['usage']['generated_tokens']==0
  assert set(body['answers'])==set(g['targets']);assert len(body['candidate_scores'])==len(g['targets'])
  for j,(field,q) in enumerate(g['payload']['questions'].items()):
   labels=['no','yes'] if q['type']=='noul' else list(q['criteria']) if isinstance(q['criteria'],dict) else [str(i) for i in range(len(q['criteria']))]
   p=body['answers'][field]['probabilities'];assert set(p)==set(labels) and all(math.isfinite(x) and 0<=x<=1 for x in p.values()) and abs(sum(p.values())-1)<1e-9
   cs=body['candidate_scores'][j];assert len(cs)==len(labels);w=[math.exp((x-max(cs))/T) for x in cs];calc={k:x/sum(w) for k,x in zip(labels,w)};maxsoft=max(maxsoft,max(abs(calc[k]-p[k]) for k in labels));assert maxsoft<1e-6
   prediction=min(p,key=lambda k:(-p[k],k));assert prediction==b['scores'][field]['predicted'];countfields+=1;correct+=prediction==g['targets'][field];maxpd=max(maxpd,max(abs(p[k]-b['scores'][field]['probs'][k]) for k in labels))
  latency=(r['responses'][-1]['perf_ns']-r['start_perf_ns'])/1e6;lat.append(latency);tokens.append(g['tokens']);dispatch.append((m['request_start_ns']-m['credit_issued_ns'])/1e6);events += [(m['request_start_ns'],1),(m['request_end_ns'],-1)];starts.append(m['request_start_ns']);lasts.append(m['request_end_ns'])
 assert len(lat)==s['request_count']['avg']==s['request_latency']['count'];assert phases['warmup']==32
 stats={k:float(np.percentile(lat,v)) for k,v in [('p50',50),('p95',95),('p99',99)]};stats['avg']=statistics.mean(lat)
 diffs={k:abs(v-s['request_latency'][k]) for k,v in stats.items()};assert max(diffs.values())<1e-5,(path,diffs)
 phase=next(x for x in json.loads((path/'phase_manifest.json').read_text())['phases'] if x['phase_kind']=='profiling');assert phase['successful_request_count']==len(lat) and phase['error_request_count']==0 and not phase['was_cancelled']
 duration=(phase['end_ns']-phase['start_ns'])/1e9;rps=len(lat)/duration;assert abs(rps-s['request_throughput']['avg'])<1e-6,(path.name,rps,s['request_throughput'])
 cc=int(path.name.split('-')[1][1:]);rr=int(path.name.split('-')[2][1:]);active=peak=0
 for _,delta in sorted(events):active+=delta;peak=max(peak,active)
 assert active==0 and peak<=cc
 gaps=np.diff(sorted(starts))/1e6
 # Time-average concurrency includes complete request lifetimes, including the final drain.
 span=(max(lasts)-min(starts))/1e9;average_inflight=sum((end-start)/1e9 for (start,end) in zip(starts,lasts))/span
 result=dict(name=path.name,request_count=len(lat),warmup_count=phases['warmup'],unique_inputs=len(unique),fields=countfields,correct_fields=correct,decision_flips=0,max_baseline_probability_difference=maxpd,max_probability_reconstruction_error=maxsoft,rps=rps,phase_observation_seconds=duration,first_request_to_last_response_seconds=s['benchmark_duration']['avg'],request_latency_ms=stats,max_latency_recalculation_difference_ms=max(diffs.values()),peak_inflight=peak,average_inflight=average_inflight,arrival_cv=float(np.std(gaps)/np.mean(gaps)),client_dispatch_p99_ms=float(np.percentile(dispatch,99)),mean_input_tokens=statistics.mean(tokens),raw_sha256=digest,raw_matches_original_manifest=True)
 out.append(result)
result=dict(passed=True,utc=datetime.now(timezone.utc).isoformat(),scope='Read-only independent recomputation of all 12 original PyTorch load points. No inference run or source changes.',points=out,total_requests=sum(x['request_count'] for x in out),total_fields=sum(x['fields'] for x in out),all_http_and_probability_valid=True,all_decisions_match_same_input_c8_baseline=True,all_raw_hashes_match_original_manifest=True,limitations=['Not independent repeat measurements','No planned-arrival skip counter recorded','Only 224 unique stress inputs','No pure fixed-concurrency run','Single 30-second send window per point'])
(O/'independent-pytorch-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],requests=result['total_requests'],fields=result['total_fields'],points=[x for x in out if x['name'] in ['pytorch-c64-r200','pytorch-c32-r50','pytorch-c64-r50']]),indent=2))