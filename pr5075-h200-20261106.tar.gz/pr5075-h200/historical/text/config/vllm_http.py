"""Launch unchanged vLLM serving package with explicit non-caching settings."""
if __name__=='__main__':
 import sys,json,hashlib
 from pathlib import Path
 import vllm
 original=vllm.LLM
 def configured(*args,**kwargs):
  kwargs['enable_prefix_caching']=False;kwargs['gpu_memory_utilization']=.2;kwargs['limit_mm_per_prompt']={'image':0,'video':0}
  Path.home().joinpath('decision-aiperf/results/service-vllm-llm-kwargs.json').write_text(json.dumps(kwargs,indent=2,default=str)+'\n')
  return original(*args,**kwargs)
 vllm.LLM=configured
 from intern_decision.serve import main
 main()