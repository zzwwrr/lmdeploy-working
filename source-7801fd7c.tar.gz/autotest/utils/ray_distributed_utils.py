import os
import random
import re
import socket
import subprocess
import time
from time import time as time_time
from typing import Any

import requests
from utils.ascend_multinode_utils import build_ascend_multinode_env, ensure_ascend_multinode_env, resolve_hccl_if_ip
from utils.config_utils import (
    get_case_str_by_config,
    get_cli_common_param,
    get_model_path_from_config,
    resolve_extra_params,
)

# Default constants
LM_DEPLOY_API_PORT = 8000
RAY_PORT = 6379
HEALTH_CHECK_TIMEOUT = 30
CONNECTION_CHECK_TIMEOUT = 5
WORKER_WAIT_INTERVAL = 30


def ascend_multinode_enabled() -> bool:
    if int(os.getenv('NODE_COUNT', '1')) <= 1:
        return False
    return os.getenv('DEVICE', '') == 'ascend'


def wait_for_model_service_ready(
    host: str,
    api_port: int,
    model_name: str,
    timeout_seconds: int = 1000,
) -> bool:
    """Wait for LMDeploy API Server to be ready and verify basic functionality.

    No longer checks multi-node registration (API Server is a single-point service).
    """
    print(f'⏳ Waiting for LMDeploy API Server to be ready (Model: {model_name}), Timeout: {timeout_seconds}s')

    start_time = time_time()
    check_count = 0
    last_progress_print = 0
    progress_print_interval = 30

    # Random initial delay to avoid multiple clients requesting simultaneously
    time.sleep(random.uniform(1, 5))

    while time_time() - start_time < timeout_seconds:
        check_count += 1
        current_time = time_time()

        try:
            # Check if port is open
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(5)
                if sock.connect_ex((host, api_port)) != 0:
                    if current_time - last_progress_print >= progress_print_interval:
                        print(f'🔌 Check {check_count}: API port {api_port} not ready')
                        last_progress_print = current_time
                    time.sleep(10)
                    continue

            # Verify service functionality
            if verify_service_functionality(host, api_port, model_name, check_count):
                print('✅ LMDeploy API Server is fully ready!')
                return True

        except Exception as e:
            if current_time - last_progress_print >= progress_print_interval:
                print(f'🔧 Check {check_count}: Exception - {e}')
                last_progress_print = current_time

        sleep_time = 10 + random.uniform(-2, 2)
        time.sleep(sleep_time)

    print(f'❌ LMDeploy API Server startup timed out ({timeout_seconds} seconds)')
    return False


def verify_service_functionality(host: str, api_port: int, model_name: str, check_count: int) -> bool:
    """Verify that the API Server can respond to basic requests."""
    try:
        test_data = {
            'model': model_name,
            'messages': [{
                'role': 'user',
                'content': 'hi'
            }],
            'max_tokens': 5,
            'stream': False
        }

        resp = requests.post(f'http://{host}:{api_port}/v1/chat/completions', json=test_data, timeout=15)

        if resp.status_code == 200:
            print(f'✅ Check {check_count}: Service functionality normal (received valid response)')
            return True
        elif resp.status_code == 400:
            print(f'✅ Check {check_count}: Service framework activated (received 400)')
            return True
        else:
            print(f'🔧 Check {check_count}: Service test failed, status code: {resp.status_code}')
            return False

    except requests.exceptions.RequestException as e:
        print(f'🔧 Check {check_count}: Service test exception - {e}')
        return False


def _ray_alive_node_count() -> int:
    proc = subprocess.run(['ray', 'status'], capture_output=True, text=True, check=False)
    out = f'{proc.stdout}\n{proc.stderr}'
    node_ids = set(re.findall(r'node_[a-f0-9]+', out, flags=re.IGNORECASE))
    if node_ids:
        return len(node_ids)
    match = re.search(r'(\d+)\s+node', out, flags=re.IGNORECASE)
    if match:
        return int(match.group(1))
    return 0


class RayLMDeployManager:

    def __init__(
        self,
        master_addr: str,
        ray_port: int = RAY_PORT,
        api_port: int = LM_DEPLOY_API_PORT,
        log_dir: str = '.',
        health_check: bool = True,
    ):
        self.master_addr = master_addr
        self.ray_port = ray_port
        self.api_port = api_port
        self.log_dir = log_dir
        self.health_check = health_check
        self._cleaned = False

        # Determine if this is the master node (via environment variable NODE_RANK)
        self.node_rank = int(os.getenv('NODE_RANK', '0'))
        self.is_master = (self.node_rank == 0)

        os.makedirs(self.log_dir, exist_ok=True)
        print(f'📝 Node {self.node_rank} log directory: {self.log_dir}')

        # Print cluster information
        self.node_count = int(os.getenv('NODE_COUNT', '1'))
        self.job_id = os.getenv('JOB_ID', 'unknown')
        print(f'🎯 Node {self.node_rank} cluster information:')
        print(f'- Total nodes: {self.node_count}')
        print(f"- Role: {'Master node' if self.is_master else 'Worker node'}")
        print(f'- Master address: {self.master_addr}')
        print(f'- Ray port: {self.ray_port}')
        print(f'- API port: {self.api_port}')
        print(f'- Job ID: {self.job_id}')

    def start_ray_cluster(self):
        """Start or join Ray cluster."""
        local_ip = resolve_hccl_if_ip() if ascend_multinode_enabled() else None

        if self.is_master:
            cmd = ['ray', 'start', '--head', '--port', str(self.ray_port)]
            print(f'🚀 Master node starting Ray cluster (port: {self.ray_port})')
        else:
            cmd = ['ray', 'start', '--address', f'{self.master_addr}:{self.ray_port}']
            print(f'🔌 Worker node {self.node_rank} joining Ray cluster: {self.master_addr}:{self.ray_port}')

        if local_ip:
            cmd += ['--node-ip-address', local_ip]

        ray_env = os.environ.copy()
        try:
            subprocess.run(cmd, capture_output=True, text=True, check=True, env=ray_env)
            print('✅ Ray started successfully')
        except subprocess.CalledProcessError as e:
            print(f'💥 Ray startup failed: {e.stderr}')
            raise

        if self.is_master and ascend_multinode_enabled():
            self._wait_ray_cluster_nodes(self.node_count)

    def _wait_ray_cluster_nodes(self, expected_nodes: int, timeout_seconds: int = 600) -> None:
        print(f'⏳ Waiting for Ray cluster to reach {expected_nodes} node(s)...')
        deadline = time_time() + timeout_seconds
        while time_time() < deadline:
            alive = _ray_alive_node_count()
            if alive >= expected_nodes:
                print(f'✅ Ray cluster ready ({alive} node(s))')
                return
            time.sleep(10)

        raise RuntimeError(f'Ray cluster did not reach {expected_nodes} node(s) within {timeout_seconds}s')

    def start_lmdeploy_api_server(self, config: dict[str, Any], run_config: dict[str, Any]) -> None:
        """
        Master node: Start LMDeploy API Server and wait for it to be ready.
        Worker nodes: Do not start the service, only verify that the master node's API Server is ready.
        """
        # Derive model_path from config and run_config
        model_path = get_model_path_from_config(config, run_config['model'])

        extra_params = run_config.get('extra_params', {})
        resolve_extra_params(extra_params, config)
        ensure_ascend_multinode_env(config, run_config)

        # Get model-name: use extra_params['model-name'] if specified, otherwise use case_name
        case_name = get_case_str_by_config(run_config)
        extra_params = run_config.get('extra_params', {})
        model_name = case_name if extra_params.get('model-name', None) is None else extra_params.get('model-name')

        if self.is_master:
            # === Master node logic: Start service ===
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            log_path = os.path.join(self.log_dir, f'log_{model_name}_{timestamp}.log')

            cmd = [
                'lmdeploy',
                'serve',
                'api_server',
                model_path,
                '--server-port',
                str(self.api_port),
                '--model-name',
                model_name,
            ] + get_cli_common_param(run_config).split()

            print(f"🚀 Master node starting LMDeploy API Server: {' '.join(cmd)}")
            self._log_file = open(log_path, 'w')
            env = build_ascend_multinode_env(config, run_config)
            self._api_process = subprocess.Popen(cmd, stdout=self._log_file, stderr=self._log_file, env=env)
            print(f'📝 API Server log: {log_path}')

            # Wait for service to be ready
            if self.health_check:
                ready = wait_for_model_service_ready(host=self.master_addr,
                                                     api_port=self.api_port,
                                                     model_name=model_name,
                                                     timeout_seconds=1000)
                if not ready:
                    print('❌ API Server failed to be ready, terminating process')
                    self._api_process.terminate()
                    try:
                        self._api_process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        self._api_process.kill()
                    raise RuntimeError('LMDeploy API Server failed to start')
        else:
            # === Worker node logic: Only verify that the master node service is ready ===
            print(f'🔍 Worker node {self.node_rank} is verifying that the master node '
                  f'({self.master_addr}:{self.api_port}) API Server is ready...')
            if self.health_check:
                ready = wait_for_model_service_ready(host=self.master_addr,
                                                     api_port=self.api_port,
                                                     model_name=model_name,
                                                     timeout_seconds=1000)
                if not ready:
                    raise RuntimeError(f'Worker node {self.node_rank}: Master node API Server not ready '
                                       f'within 1000 seconds, cannot continue')
            else:
                print('⚠️ health_check=False, skipping API Server readiness check (not recommended)')

    def cleanup(self, force: bool = True):
        """Clean up resources.

        Args:
            force (bool):
                - False: Only stop LMDeploy API Server (used after individual test completion)
                - True: Stop API Server + Ray cluster (used for final cleanup at session end)
        """
        if self._cleaned and force:
            # Note: If this is just an intermediate cleanup with force=False, we shouldn't skip due to _cleaned
            # So only skip when force=True and already cleaned
            return

        print(f'🧹 Node {self.node_rank} cleaning resources... (force={force})')

        # Stop API Server (master node only)
        if hasattr(self, '_api_process') and self._api_process.poll() is None:
            self._api_process.terminate()
            try:
                self._api_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._api_process.kill()
            print('✅ LMDeploy API Server stopped')
            # Note: We don't clear the _api_process attribute here so it can be checked later
        if hasattr(self, '_log_file') and self._log_file and not self._log_file.closed:
            self._log_file.close()

        # Stop Ray (only when force=True)
        if force:
            try:
                subprocess.run(['ray', 'stop', '--force'], check=False, capture_output=True)
                print('✅ Ray cluster stopped')
            except Exception as e:
                print(f'⚠️ Ray stop exception: {e}')
            self._cleaned = True  # Only mark as "fully cleaned" when force=True

    def get_cluster_info(self) -> dict[str, Any]:
        return {
            'node_rank': self.node_rank,
            'node_count': self.node_count,
            'master_addr': self.master_addr,
            'ray_port': self.ray_port,
            'api_port': self.api_port,
            'is_master': self.is_master,
            'job_id': self.job_id,
        }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()


def ray_worker_node_wait(manager: RayLMDeployManager, timeout_minutes: int = 60):
    """Worker node waits for Ray master node (Head Node) to be alive (by
    detecting GCS service port)"""
    if manager.is_master:
        return

    print(f'⏸️ Worker node {manager.node_rank} entering wait mode...')
    max_checks = (timeout_minutes * 60) // WORKER_WAIT_INTERVAL
    consecutive_failures = 0
    max_consecutive_failures = 3

    for i in range(max_checks):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(CONNECTION_CHECK_TIMEOUT)
                if sock.connect_ex((manager.master_addr, RAY_PORT)) == 0:
                    consecutive_failures = 0
                else:
                    consecutive_failures += 1
        except Exception:
            consecutive_failures += 1

        if consecutive_failures >= max_consecutive_failures:
            print('📡 Ray master node GCS service unreachable, worker node exiting')
            break

        if i % 4 == 0:
            elapsed = (i * WORKER_WAIT_INTERVAL) // 60
            print(f'⏳ Worker node {manager.node_rank} waiting... Running for {elapsed} minutes')

        time.sleep(WORKER_WAIT_INTERVAL)
    else:
        print(f'⏰ Worker node {manager.node_rank} wait timeout ({timeout_minutes} minutes)')

    manager.cleanup()
