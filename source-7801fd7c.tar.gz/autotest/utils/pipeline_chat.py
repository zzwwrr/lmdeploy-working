import json
import os
import shutil
import time

import allure
from pytest_assume.plugin import assume
from utils.common_utils import execute_command_with_logging
from utils.config_utils import (
    get_case_str_by_config,
    get_cuda_prefix_by_workerid,
    get_model_path_from_config,
    get_workerid,
    resolve_extra_params,
)
from utils.rule_condition_assert import assert_result
from utils.run_restful_chat import _mm_demo_tomb_run_assert


def run_pipeline_llm_test(config, run_config, common_case_config, worker_id: str = '', is_smoke: bool = False):
    model = run_config.get('model')
    if run_config.get('env', {}).get('LMDEPLOY_USE_MODELSCOPE', 'False') == 'True':
        model_path = model
    else:
        model_path = get_model_path_from_config(config, model)

    log_path = config.get('log_path')
    case_name = get_case_str_by_config(run_config)
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    pipeline_log = os.path.join(log_path, f'pipeline_llm_{case_name}_{timestamp}.log')

    env = os.environ.copy()
    env['MASTER_PORT'] = str(get_workerid(worker_id) + 29500)
    env.update(run_config.get('env', {}))

    run_config_bk = run_config.copy()
    run_config_bk.pop('env', None)
    run_config_bk.pop('model', None)
    run_config_bk.setdefault('extra_params', {})

    resolve_extra_params(run_config_bk['extra_params'], config)

    run_config_string = json.dumps(run_config_bk, ensure_ascii=False, indent=None)
    run_config_string = run_config_string.replace(' ', '').replace('"', '\\"').replace(',', '\\,')

    cuda_prefix = get_cuda_prefix_by_workerid(worker_id, run_config.get('parallel_config'))
    cmd = f'{cuda_prefix} python3 autotest/tools/pipeline/llm_case.py run_pipeline_chat_test {model_path} {run_config_string} autotest/prompt_case.yml {is_smoke}'  # noqa E501

    result, stderr = execute_command_with_logging(cmd, pipeline_log, timeout=1800, env=env)

    with assume:
        assert result, stderr

    # Subprocess already failed: skip caseresult parse (would raise IndexError).
    if not result:
        allure.attach.file(pipeline_log, name=pipeline_log, attachment_type=allure.attachment_type.TEXT)
        return

    with open(pipeline_log, encoding='utf-8') as file:
        output_text = file.read()

    with open(pipeline_log, 'a') as file:
        for case in common_case_config.keys():
            if is_smoke and case != 'memory_test':
                continue
            if case != 'code_testcase' and 'code' in model_path.lower():
                continue

            with allure.step(case):
                case_info = common_case_config.get(case)
                case_result = True
                reason = ''

                for prompt_detail in case_info:
                    prompt = list(prompt_detail.keys())[0]
                    response = get_response_from_output_by_prompt(output_text, case, prompt)
                    if response is None:
                        case_result, reason = False, f'missing caseresult for {case}/{prompt}'
                    else:
                        case_result, reason = assert_result(response, prompt_detail.values(), model_path)
                    if not case_result:
                        print(f'{case} result: {case_result}, reason: {reason} \n')
                    file.writelines(f'{case} result: {case_result}, reason: {reason} \n')
                with assume:
                    assert case_result, reason
    allure.attach.file(pipeline_log, name=pipeline_log, attachment_type=allure.attachment_type.TEXT)


def run_pipeline_mllm_test(config, run_config, worker_id: str = '', is_smoke: bool = False):
    model = run_config.get('model')
    if run_config.get('env', {}).get('LMDEPLOY_USE_MODELSCOPE', 'False') == 'True':
        model_path = model
    else:
        model_path = get_model_path_from_config(config, model)

    log_path = config.get('log_path')
    case_name = get_case_str_by_config(run_config)
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    pipeline_log = os.path.join(log_path, f'pipeline_mllm_{case_name}_{timestamp}.log')

    env = os.environ.copy()
    env['MASTER_PORT'] = str(get_workerid(worker_id) + 29500)
    env.update(run_config.get('env', {}))

    run_config_bk = run_config.copy()
    run_config_bk.pop('env', None)
    run_config_bk.pop('model', None)
    run_config_bk.setdefault('extra_params', {})

    run_config_string = json.dumps(run_config_bk, ensure_ascii=False, indent=None)
    run_config_string = run_config_string.replace(' ', '').replace('"', '\\"').replace(',', '\\,')

    cuda_prefix = get_cuda_prefix_by_workerid(worker_id, run_config.get('parallel_config'))
    resource_path = config.get('resource_path')
    cmd = f'{cuda_prefix} python3 autotest/tools/pipeline/mllm_case.py run_pipeline_mllm_test {model_path} {run_config_string} {resource_path} {is_smoke}'  # noqa E501

    result, stderr = execute_command_with_logging(cmd, pipeline_log, timeout=1800, env=env, should_print=False)

    with assume:
        assert result, stderr

    # Subprocess already failed: skip caseresult parse (would raise IndexError).
    if not result:
        allure.attach.file(pipeline_log, name=pipeline_log, attachment_type=allure.attachment_type.TEXT)
        return

    with open(pipeline_log, encoding='utf-8') as file:
        output_text = file.read()

    with open(pipeline_log, 'a') as file:
        with allure.step('single1 pic'):
            response = get_response_from_output(output_text, 'single1')
            case_result = bool(response) and any(word in response.lower() for word in ['tiger', '虎'])
            file.writelines(f'single1 pic result: {case_result} reason: simple example tiger should in {response} \n')
            with assume:
                assert case_result, f'reason: simple example tiger should in {response}'
        with allure.step('single2 pic'):
            response = get_response_from_output(output_text, 'single2')
            case_result = bool(response) and any(word in response.lower() for word in ['tiger', '虎'])
            file.writelines(f'single2 pic result: {case_result} reason: simple example tiger should in {response} \n')
            with assume:
                assert case_result, f'reason: simple example tiger should in {response}'
        with allure.step('multi-imagese'):
            response = get_response_from_output(output_text, 'multi-imagese')
            case_result = bool(response) and any(word in response.lower() for word in ['tiger', '虎', '滑雪', 'ski'])
            file.writelines(f'multi-imagese pic result: {case_result} reason: tiger or ski should in {response} \n')
            with assume:
                assert case_result, f'reason: Multi-images example: tiger or ski should in {response}'
        with allure.step('batch-example1'):
            response = get_response_from_output(output_text, 'batch-example1')
            case_result = bool(response) and any(word in response.lower() for word in ['滑雪', 'ski'])
            file.writelines(f'batch-example1 pic result: {case_result} reason: ski should in {response} \n')
            with assume:
                assert case_result, f'reason: batch-example1: ski should in {response}'
        with allure.step('batch-example2'):
            response = get_response_from_output(output_text, 'batch-example2')
            case_result = bool(response) and any(word in response.lower() for word in ['tiger', '虎'])
            file.writelines(f'batch-example2 pic result: {case_result} reason: tiger should in {response} \n')
            with assume:
                assert case_result, f'reason: batch-example1: tiger should in {response}'
        with allure.step('multi-turn1'):
            response = get_response_from_output(output_text, 'multi-turn1')
            case_result = bool(response) and any(word in response.lower() for word in ['滑雪', 'ski'])
            file.writelines(f'multi-turn1 pic result: {case_result} reason:  ski should in {response} \n')
            with assume:
                assert case_result, f'reason: batch-example1: ski should in {response}'
        with allure.step('multi-turn2'):
            response = get_response_from_output(output_text, 'multi-turn2')
            case_result = bool(response) and any(word in response.lower() for word in ['滑雪', 'ski'])
            file.writelines(f'multi-turn2 pic result: {case_result} reason: ski should in {response} \n')
            with assume:
                assert case_result, f'reason: batch-example1: ski should in {response}'
        if not is_smoke:
            if 'internvl' in model.lower() and 'internvl2-4b' not in model.lower():
                internvl_vl_testcase(output_text, file)
                internvl_vl_testcase(output_text, file, 'cn')
            if 'minicpm' in model.lower():
                MiniCPM_vl_testcase(output_text, file)
            if 'qwen' in model.lower():
                Qwen_vl_testcase(output_text, file)

    with open(pipeline_log, encoding='utf-8') as file:
        output_text = file.read()
    print(output_text)
    allure.attach.file(pipeline_log, name=pipeline_log, attachment_type=allure.attachment_type.TEXT)


def get_response_from_output(output_text, case):
    """Extract ``[caseresult ...]`` block; return empty string if missing."""
    start = f'[caseresult {case} start]'
    end = f'[caseresult {case} end]'
    if start not in output_text or end not in output_text:
        return ''
    return output_text.split(start)[1].split(end)[0]


def get_response_from_output_by_prompt(output_text, case, prompt):
    """Extract response for prompt; return None if caseresult block is
    missing."""
    start = f'[caseresult {case} start]'
    end = f'[caseresult {case} end]'
    if start not in output_text or end not in output_text:
        return None
    output_list = output_text.split(start)[1].split(end)[0]
    try:
        output_dict = json.loads(output_list.rstrip())
    except json.JSONDecodeError:
        return None
    for output in output_dict:
        if output.get('prompt') == prompt:
            return output.get('response')
    return None


def _is_skipped_case_response(response: str) -> bool:
    return 'skipped_' in response.lower()


def _parse_pipeline_mm_demo_payload(raw: str) -> tuple[str | None, str | None]:
    """Parse ``qwen3-demo-video`` log payload (plain text or JSON with
    finish_reason)."""
    s = raw.strip()
    if s.startswith('{'):
        try:
            obj = json.loads(s)
        except json.JSONDecodeError:
            return s, None
        if isinstance(obj, dict) and 'text' in obj:
            text_val = obj.get('text')
            return (str(text_val) if text_val is not None else None), obj.get('finish_reason')
    return s, None


def _is_engine_error_response(text: str) -> bool:
    rl = text.lower()
    return 'input_length_error' in rl or 'internal error happened' in rl


def assert_pipeline_single_return(output, logprobs_num: int = 0):
    result = assert_pipeline_single_element(output, is_last=True, logprobs_num=logprobs_num)
    if not result:
        return result, f'single_stream_element is wrong {output}'
    return result & (len(output.token_ids) == output.generate_token_len
                     or len(output.token_ids) == output.generate_token_len - 1), 'token_is len is not correct'


def assert_pipeline_batch_return(output, size: int = 1):
    if len(output) != size:
        return False, 'length is not correct'
    for single_output in output:
        result, msg = assert_pipeline_single_return(single_output)
        if not result:
            return result, msg
    return True, ''


def assert_pipeline_single_stream_return(output, logprobs_num: int = 0):
    for i in range(0, len(output) - 2):
        if not assert_pipeline_single_element(output[i], is_stream=True, logprobs_num=logprobs_num):
            return False, f'single_stream_element is false, index is {i}'
    if assert_pipeline_single_element(output[-1], is_stream=True, is_last=True, logprobs_num=logprobs_num) is False:
        return False, 'last single_stream_element is false'
    return True, ''


def assert_pipeline_batch_stream_return(output, size: int = 1):
    for i in range(size):
        output_list = [item for item in output if item.index == i]
        result, msg = assert_pipeline_single_stream_return(output_list)
        if not result:
            return result, msg
    return True, ''


def assert_pipeline_single_element(output, is_stream: bool = False, is_last: bool = False, logprobs_num: int = 0):
    result = True
    result &= output.generate_token_len > 0
    result &= output.input_token_len > 0
    result &= output.index >= 0
    if is_last:
        result &= output.text is not None
        result &= output.finish_reason in ['stop', 'length']
        if is_stream:
            result &= output.token_ids is None or output.token_ids == []
        else:
            result &= len(output.token_ids) > 0
    else:
        result &= len(output.text) > 0
        result &= output.finish_reason is None
        result &= len(output.token_ids) > 0
    if logprobs_num == 0 or (is_last and is_stream):
        result &= output.logprobs is None
    else:
        if is_stream:
            result &= len(output.logprobs) >= 1
        else:
            result &= len(output.logprobs) == output.generate_token_len or len(
                output.logprobs) == output.generate_token_len + 1
        if result:
            for content in output.logprobs:
                result &= len(content.keys()) <= logprobs_num
                for key in content.keys():
                    result &= isinstance(content.get(key), float)
    return result


def internvl_vl_testcase(output_text, file, lang: str = 'en'):
    with allure.step(f'internvl-combined-images-{lang}'):
        response = get_response_from_output(output_text, f'internvl-combined-images-{lang}')
        case_result = any(word in response.lower() for word in ['panda', '熊猫'])
        file.writelines(f'internvl-combined-images-{lang} result: {case_result}, reason: panda should in {response} \n')
        with assume:
            assert case_result, f'reason: combined images: panda should in {response}'
    with allure.step(f'internvl-combined-images2-{lang}'):
        response = get_response_from_output(output_text, f'internvl-combined-images2-{lang}')
        case_result = any(word in response.lower() for word in ['panda', '熊猫'])
        file.writelines(
            f'internvl-combined-images2-{lang} result: {case_result}, reason: panda should in {response} \n')
        with assume:
            assert case_result, f'reason: combined images2: panda should in {response}'
    with allure.step(f'internvl-separate-images-{lang}'):
        response = get_response_from_output(output_text, f'internvl-separate-images-{lang}')
        case_result = any(word in response.lower() for word in ['panda', '熊猫', 'same', 'different', 'eat', 'cute'])
        file.writelines(f'internvl-separate-images-{lang} result: {case_result}, reason: panda should in {response} \n')
        with assume:
            assert case_result, f'reason: separate images: panda should in {response}'
    with allure.step(f'internvl-separate-images2-{lang}'):
        response = get_response_from_output(output_text, f'internvl-separate-images2-{lang}')
        case_result = any(word in response.lower()
                          for word in ['panda', '熊猫', 'same', 'different', 'difference', 'identical'])
        file.writelines(
            f'internvl-separate-images2-{lang} result: {case_result}, reason: panda should in {response} \n')
        with assume:
            assert case_result, f'reason: separate images2: panda should in {response}'
    with allure.step(f'internvl-video-{lang}'):
        response = get_response_from_output(output_text, f'internvl-video-{lang}')
        if _is_skipped_case_response(response):
            file.writelines(f'internvl-video-{lang} result: skipped, reason: {response}\n')
        else:
            case_result = any(word in response.lower() for word in ['red panda', 'eat', '熊猫', '竹子', 'food', 'hold'])
            file.writelines(f'internvl-video-{lang} result: {case_result}, reason: panda should in {response} \n')
            with assume:
                assert case_result, f'reason: video: panda should in {response}'
    with allure.step(f'internvl-video2-{lang}'):
        response = get_response_from_output(output_text, f'internvl-video2-{lang}')
        if _is_skipped_case_response(response):
            file.writelines(f'internvl-video2-{lang} result: skipped, reason: {response}\n')
        else:
            case_result = any(word in response.lower() for word in ['red panda', 'eat', '熊猫', '竹子'])
            file.writelines(f'internvl-video2-{lang} result: {case_result}, reason: panda should in {response} \n')
            with assume:
                assert case_result, f'reason: video2: panda should in {response}'


def MiniCPM_vl_testcase(output_text, file):
    with allure.step('minicpm-combined-images'):
        response = get_response_from_output(output_text, 'minicpm-combined-images')
        case_result = any(word in response.lower() for word in ['panda', '熊猫'])
        file.writelines(f'minicpm-combined-images result: {case_result}, reason:  panda should in {response} \n')
        with assume:
            assert case_result, f'reason: combined images: panda should in {response}'
    with allure.step('minicpm-combined-images2'):
        response = get_response_from_output(output_text, 'minicpm-combined-images2')
        case_result = any(word in response.lower() for word in ['panda', '熊猫'])
        file.writelines(f'minicpm-combined-images2 result: {case_result}, reason: panda should in {response} \n')
        with assume:
            assert case_result, f'reason: combined images2: panda should in {response}'
    with allure.step('minicpm-fewshot'):
        response = get_response_from_output(output_text, 'minicpm-fewshot')
        case_result = any(word in response.lower() for word in ['2021', '14'])
        file.writelines(f'minicpm-fewshot result: {case_result} reason: 2021 or 14 should in {response} \n')
        with assume:
            assert case_result, f'reason: fewshot: 2021 or 14 should in {response}'
    with allure.step('minicpm-video'):
        response = get_response_from_output(output_text, 'minicpm-video')
        if _is_skipped_case_response(response):
            file.writelines(f'minicpm-video result: skipped, reason: {response}\n')
        else:
            case_result = any(word in response.lower() for word in ['red panda', '熊猫'])
            file.writelines(f'minicpm-video result: {case_result} reason: video: panda should in {response} \n')
            with assume:
                assert case_result, f'reason: video: panda should in {response}'


def Qwen_vl_testcase(output_text, file):
    with allure.step('qwen-combined-images'):
        response = get_response_from_output(output_text, 'qwen-combined-images')
        case_result = any(word in response.lower() for word in ['buildings', '楼', 'skyline', 'city'])
        file.writelines(f'qwen-combined-images result: {case_result}, reason: buildings should in {response} \n')
        with assume:
            assert case_result, f'reason: combined images: buildings should in {response}'
    with allure.step('qwen-combined-images2'):
        response = get_response_from_output(output_text, 'qwen-combined-images2')
        case_result = any(word in response.lower() for word in ['buildings', '楼', 'skyline', 'city'])
        file.writelines(f'qwen-combined-images2 result: {case_result}, reason: buildings should in {response} \n')
        with assume:
            assert case_result, f'reason: combined images2: buildings should in {response}'
    with allure.step('qwen-performance-images'):
        response = get_response_from_output(output_text, 'qwen-performance-images')
        case_result = any(word in response.lower() for word in ['buildings', '楼', 'skyline', 'city'])
        file.writelines(f'qwen-performance-images result: {case_result}, reason: buildings should in {response} \n')
        with assume:
            assert case_result, f'reason: performance images: buildings should in {response}'
    with allure.step('qwen-performance-images2'):
        response = get_response_from_output(output_text, 'qwen-performance-images2')
        case_result = any(word in response.lower() for word in ['buildings', '楼', 'skyline', 'city'])
        file.writelines(f'qwen-performance-images2 result: {case_result}, reason: buildings should in {response} \n')
        with assume:
            assert case_result, f'reason: performance images2: buildings should in {response}'
    if '[caseresult qwen3-demo-video start]' in output_text:
        with allure.step('qwen3-demo-video'):
            response = get_response_from_output(output_text, 'qwen3-demo-video')
            text, finish = _parse_pipeline_mm_demo_payload(response)
            rl = response.lower()
            if _is_skipped_case_response(response):
                file.writelines(f'qwen3-demo-video result: skipped, reason: {response}\n')
            elif text is None:
                file.writelines(f'qwen3-demo-video result: false, missing text in payload: {response}\n')
                with assume:
                    assert False, f'qwen3-demo-video missing text: {response}'
            elif _is_skipped_case_response(text):
                file.writelines(f'qwen3-demo-video result: skipped, reason: {response}\n')
            else:
                text_l = text.lower()
                if 'skipped_no_demo_mp4' in rl or 'skipped_no_demo_mp4' in text_l:
                    file.writelines('qwen3-demo-video result: skipped (N1cdUjctpG8.mp4 not in resource_path)\n')
                elif 'skipped_input_length_error' in rl or 'skipped_input_length_error' in text_l:
                    file.writelines(
                        'qwen3-demo-video result: skipped (input exceeds session_len, same as restful server log)\n')
                elif 'pipeline_video_error:' in rl or 'pipeline_video_error:' in text_l:
                    file.writelines(f'qwen3-demo-video result: false, pipeline video error in {response} \n')
                    with assume:
                        assert False, f'qwen3-demo-video pipeline error: {response}'
                elif _is_engine_error_response(text):
                    file.writelines(f'qwen3-demo-video result: skipped, engine error: {text} \n')
                else:
                    case_result = _mm_demo_tomb_run_assert(finish, text)
                    reason = 'tomb/jar + bounded public tail (restful mm_processor assert)'
                    file.writelines(f'qwen3-demo-video result: {case_result}, reason: {reason}: {text} \n')
                    with assume:
                        msg = 'reason: qwen3 demo video: expected tomb/jar-related bounded answer'
                        assert case_result, f'{msg}: finish={finish}, text={text[:2000]}'
    if '[caseresult qwen-mixed-image-text-video start]' in output_text:
        with allure.step('qwen-mixed-image-text-video'):
            response = get_response_from_output(output_text, 'qwen-mixed-image-text-video')
            rl = response.lower()
            if _is_skipped_case_response(response):
                file.writelines(f'qwen-mixed-image-text-video result: skipped, reason: {response}\n')
            elif 'skipped_no_red_panda_mp4' in rl:
                file.writelines(
                    'qwen-mixed-image-text-video result: skipped (red-panda.mp4 not in resource_path)\n')
            elif 'pipeline_mixed_mm_error:' in rl:
                file.writelines(f'qwen-mixed-image-text-video result: false, mixed mm error in {response} \n')
                with assume:
                    assert False, f'qwen-mixed-image-text-video pipeline error: {response}'
            else:
                img = (
                    any(w in rl for w in ('tiger', 'ski'))
                    or '虎' in response
                    or '滑雪' in response
                )
                vid = (
                    any(w in rl for w in ('panda', 'red panda', 'lesser panda', 'ailurus'))
                    or any(w in response for w in ('小熊猫', '红熊猫'))
                )
                case_result = bool(response.strip()) and img and vid
                file.writelines(
                    f'qwen-mixed-image-text-video result: {case_result}, reason: image+tiger + video+panda cues\n')
                with assume:
                    msg = 'reason: mixed image+video reply should mention tiger/ski and panda'
                    assert case_result, f'{msg}: {response}'


def save_pipeline_common_log(config, log_name, result, content, msg: str = '', write_type: str = 'w'):
    log_path = config.get('log_path')

    config_log = os.path.join(log_path, log_name)
    file = open(config_log, write_type)
    file.writelines(f'result:{result}, reason: {msg}, content: {content}')  # noqa E231
    file.close()


def assert_pipeline_common_log(config, log_name):
    log_path = config.get('log_path')

    config_log = os.path.join(log_path, log_name)
    allure.attach.file(config_log, name=config_log, attachment_type=allure.attachment_type.TEXT)

    msg = 'result is empty, please check again'
    result = False
    with open(config_log) as f:
        lines = f.readlines()

        for line in lines:
            if 'result:False, reason:' in line:
                result = False
                msg = line
                break
            if 'result:True, reason:' in line and not result:
                result = True
                msg = ''
    try:
        if os.path.isfile(config_log):
            os.remove(config_log)
        elif os.path.isdir(config_log):
            shutil.rmtree(config_log)
    except OSError:
        pass  # Ignore errors when removing log file

    assert result, msg
