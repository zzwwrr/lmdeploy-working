# 部署 LLM 类 openai 服务

本文主要介绍单个模型在单机多卡环境下，部署兼容 openai 接口服务的方式，以及服务接口的用法。为行文方便，我们把该服务名称为 `api_server`。对于多模型的并行服务，请阅读[请求分发服务器](./proxy_server.md)一文。

在这篇文章中， 我们首先介绍服务启动的两种方法，你可以根据应用场景，选择合适的。

其次，我们重点介绍服务的 RESTful API 定义，以及接口使用的方式，并展示如何通过 Swagger UI、LMDeploy CLI 工具体验服务功能

## 启动服务

以 huggingface hub 上的 [internlm2_5-7b-chat](https://huggingface.co/internlm/internlm2_5-7b-chat) 模型为例，你可以任选以下方式之一，启动推理服务。

### 方式一：使用 lmdeploy cli 工具

```shell
lmdeploy serve api_server internlm/internlm2_5-7b-chat --server-port 23333
```

api_server 启动时的参数可以通过命令行`lmdeploy serve api_server -h`查看。
比如，`--tp` 设置张量并行，`--session-len` 设置推理的最大上下文窗口长度，`--cache-max-entry-count` 调整 k/v cache 的内存使用比例等等。

### 方式二：使用 docker

使用 LMDeploy 官方[镜像](https://hub.docker.com/r/openmmlab/lmdeploy/tags)，可以运行兼容 OpenAI 的服务。下面是使用示例：

```shell
docker run --runtime nvidia --gpus all \
    -v ~/.cache/huggingface:/root/.cache/huggingface \
    --env "HUGGING_FACE_HUB_TOKEN=<secret>" \
    -p 23333:23333 \
    --ipc=host \
    openmmlab/lmdeploy:latest \
    lmdeploy serve api_server internlm/internlm2_5-7b-chat
```

在这个例子中，`lmdeploy server api_server` 的命令参数与方式一一致。

每个模型可能需要 Docker 映像中未包含的特定依赖项。如果遇到问题，您可能需要根据具体情况自行安装这些依赖项。如有疑问，请参阅特定模型的项目以获取文档。

例如，对于 Llava

```
FROM openmmlab/lmdeploy:latest

RUN apt-get update && apt-get install -y python3 python3-pip git

WORKDIR /app

RUN pip3 install --upgrade pip
RUN pip3 install timm
RUN pip3 install git+https://github.com/haotian-liu/LLaVA.git --no-deps

COPY . .

CMD ["lmdeploy", "serve", "api_server", "liuhaotian/llava-v1.6-34b"]
```

### 方式三：部署到Kubernetes集群

使用[kubectl](https://kubernetes.io/docs/reference/kubectl/)命令行工具，连接到一个运行中Kubernetes集群并部署internlm2_5-7b-chat模型服务。下面是使用示例（需要替换`<your token>`为你的huggingface hub token）：

```shell
sed 's/{{HUGGING_FACE_HUB_TOKEN}}/<your token>/' k8s/deployment.yaml | kubectl create -f - \
    && kubectl create -f k8s/service.yaml
```

示例中模型数据来源于node上的本地磁盘（hostPath），多副本部署时考虑替换为高可用共享存储，通过[PersistentVolume](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)方式挂载到容器中。

## RESTful API

LMDeploy 的 RESTful API 兼容了 OpenAI 以下 3 个接口：

- /v1/chat/completions
- /v1/models
- /v1/completions

对于 `/v1/chat/completions`，内容数组中的每个块必须是包含受支持 `type` 的对象。
未知或缺失的块类型、非对象内容块会在生成前返回 HTTP 400，`stream=true` 时也一样。
错误消息会指出具体位置，例如 `messages[0].content[1].type`，不会再静默删除不支持的内容块。

服务启动后，你可以在浏览器中打开网页 http://0.0.0.0:23333，通过 Swagger UI 查看接口的详细说明，并且也可以直接在网页上操作，体验每个接口的用法，如下图所示。

![swagger_ui](https://github.com/InternLM/lmdeploy/assets/4560679/b891dd90-3ffa-4333-92b2-fb29dffa1459)

若需要把服务集成到自己的项目或者产品中，我们推荐以下用法：

### 采样默认值

请求中显式指定的采样参数优先于模型或服务端默认值。如果两者均未提供温度，
LMDeploy 使用 `temperature=1.0`。要保留之前的兜底行为，请显式设置
`temperature=0.8`。贪心解码行为不变。

设置 `top_k=0` 或 `top_k=-1` 均可关闭 top-k 过滤，也可覆盖模型或服务端的正整数默认值。
两种写法都会在进入推理后端前统一为 `0`。小于 `-1` 的值会被拒绝。
该行为适用于 Chat Completions、Completions、Responses、Anthropic Messages、
`/generate` 和 Python `GenerationConfig`。使用 OpenAI Python 客户端时，传入
`extra_body={"top_k": -1}`。

### 查看渲染后的 chat prompt

向 `/v1/chat/completions` 传入 `return_prompt_text=true`，响应会包含实际渲染的 `prompt_text`。使用 Python OpenAI 客户端时传入 `extra_body={"return_prompt_text": True}`；原始 JSON 同时支持顶层字段和该嵌套对象，顶层值优先。流式响应在每个 choice 的首个 chunk 中返回 prompt。该值来自实际模板输出，推理强度标记取决于模型模板；原始 `input_ids` 请求没有渲染 prompt，返回 `null`。未请求时不返回此字段。

### 使用 PyTorch 返回更多 Chat logprobs

使用 `--backend pytorch --logprobs-mode raw_logprobs` 启动服务。Chat 请求允许
`0 <= top_logprobs <= vocab_size`，上限取自已加载模型的输出词表，多进程引擎同样适用。
对于 154880 词表的模型，在请求中添加
`"logprobs": true, "top_logprobs": 154880, "max_completion_tokens": 1` 即可验证。
越界请求返回 HTTP 400；TurboMind 的上限仍为 20。

原始 logprobs 在 temperature、惩罚及采样过滤前计算。分析分布时，若已选 token 不在
`top_logprobs` 中，应合并外层的分数。无 tokenizer 映射的 ID 使用 `token_id:<id>` 标识，
不提供 bytes。全词表响应较大，建议限制输出 token 数。
低精度分数存在舍入误差，分析时可对完整返回分布重新归一化。

支持 Chat 的流式和非流式请求。Responses 忽略 `top_logprobs`；
Messages 的 `return_logprob` 仅返回已生成 token 的分数。

### 使用 openai 接口

使用默认响应解析器时，`json_object`、`json_schema` 和 `regex_schema` 约束整个生成序列。这些模式通过聊天模板关闭思考，并将受约束的输出放入 `content`，流式响应同样如此；答案中的协议标签字符串按普通数据保留。强制工具调用使用独立的标签语法，仍可包含思考。

最后一条非空 assistant 消息会作为续写前缀。普通文本前缀的续写放入 `content`；若前缀停在显式的 `<think>` 块内，则继续输出到思考通道。

原始 JSON 请求也支持在 `extra_body` 中传入 `enable_thinking` 和 `media_io_kwargs`，顶层值优先。新接入建议使用 `chat_template_kwargs={"enable_thinking": false}`；顶层 `enable_thinking` 参数已弃用。

以下代码是通过 openai 包使用 `v1/chat/completions` 服务的例子。运行之前，请先安装 openai 包: `pip install openai`。

```python
from openai import OpenAI
client = OpenAI(
    api_key='YOUR_API_KEY',
    base_url="http://0.0.0.0:23333/v1"
)
model_name = client.models.list().data[0].id
response = client.chat.completions.create(
  model=model_name,
  messages=[
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": " provide three suggestions about time management"},
  ],
    temperature=0.8,
    top_p=0.8
)
print(response)
```

如果你想使用异步的接口，可以尝试下面的例子：

```python
import asyncio
from openai import AsyncOpenAI

async def main():
    client = AsyncOpenAI(api_key='YOUR_API_KEY',
                         base_url='http://0.0.0.0:23333/v1')
    model_cards = await client.models.list()._get_page()
    response = await client.chat.completions.create(
        model=model_cards.data[0].id,
        messages=[
            {
                'role': 'system',
                'content': 'You are a helpful assistant.'
            },
            {
                'role': 'user',
                'content': ' provide three suggestions about time management'
            },
        ],
        temperature=0.8,
        top_p=0.8)
    print(response)

asyncio.run(main())
```

关于其他 openai 接口的调用，也可以如法炮制。详情请参考 openai 官方[文档](https://platform.openai.com/docs/guides/text-generation)

### 工具调用

参考 [api_server_tools](./api_server_tools.md)。

### Anthropic 兼容接口

参考 [api_server_anthropic](./api_server_anthropic.md)。

### OpenAI Responses 兼容接口

参考 [api_server_responses](./api_server_responses.md)。

### 使用 `/generate` 计算输入 token 的 logprob

使用 `--backend pytorch --logprobs-mode raw_logprobs` 启动服务，然后在直接
`/generate` 请求中设置 `return_logprob` 和 `logprob_start_len`：

```bash
curl http://{server_ip}:{server_port}/generate \
  -H 'Content-Type: application/json' \
  -d '{
    "input_ids": [1234, 5678, 9012],
    "return_logprob": true,
    "logprob_start_len": 0,
    "max_tokens": 0
  }'
```

`meta_info.input_token_logprobs` 只发送一次。对于
`N=logprob_start_len`，返回行对应位置 `N` 之后的已处理源 token ids，每项为
`[value, token_id]`。如果直接传入 `input_ids`，即对应
`input_ids[N + 1:]`；如果传入 `prompt` 或图像输入，则在分词和 VLM 占位符扩展后
检查边界。边界后必须至少有一个 token，否则端点会拒绝该请求。流式和非流式都只返回一个终止
payload，流式随后发送 `[DONE]`。

此直接接口要求设置 `max_tokens=0` 并禁用推测解码。TurboMind、DistServe、代理
`/generate` 以及 OpenAI、Anthropic 和 Responses 协议暂不支持输入 logprob。

### 使用 Java/Golang/Rust

可以使用代码生成工具 [openapi-generator-cli](https://github.com/OpenAPITools/openapi-generator-cli) 将 `http://{server_ip}:{server_port}/openapi.json` 转成 java/rust/golang 客户端。
下面是一个使用示例：

```shell
$ docker run -it --rm -v ${PWD}:/local openapitools/openapi-generator-cli generate -i /local/openapi.json -g rust -o /local/rust

$ ls rust/*
rust/Cargo.toml  rust/git_push.sh  rust/README.md

rust/docs:
ChatCompletionRequest.md  EmbeddingsRequest.md  HttpValidationError.md  LocationInner.md  Prompt.md
DefaultApi.md             GenerateRequest.md    Input.md                Messages.md       ValidationError.md

rust/src:
apis  lib.rs  models
```

### 使用 cURL

cURL 也可以用于查看 API 的输出结果

- 查看模型列表 `v1/models`

```bash
curl http://{server_ip}:{server_port}/v1/models
```

- 对话 `v1/chat/completions`

```bash
curl http://{server_ip}:{server_port}/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "intern-s2-preview",
    "messages": [{"role": "user", "content": "Hello! How are you?"}]
  }'
```

- 文本补全 `v1/completions`

```shell
curl http://{server_ip}:{server_port}/v1/completions \
  -H 'Content-Type: application/json' \
  -d '{
  "model": "llama",
  "prompt": "two steps to build a house:"
}'
```

## 同时启动多个 api_server

两步直接启动多机多卡服务。先用下面的代码创建一个启动脚本。然后：

1. 启动代理服务 `lmdeploy serve proxy`。
2. torchrun 启动脚本 `torchrun --nproc_per_node 2 script.py InternLM/internlm2-chat-1_8b --proxy_url http://{proxy_node_name}:{proxy_node_port}`. **注意**： 多机多卡不要用默认 url `0.0.0.0:8000`，我们需要输入真实ip对应的地址，如：`11.25.34.55:8000`。多机情况下，因为不需要子节点间的通信，所以并不需要用户指定 torchrun 的 `--nnodes` 等参数，只要能保证每个节点执行一次单节点的 torchrun 就行。

```python
import os
import socket
from typing import List, Literal

import fire


def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip


def main(model_path: str,
         tp: int = 1,
         proxy_url: str = 'http://0.0.0.0:8000',
         port: int = 23333,
         backend: Literal['turbomind', 'pytorch'] = 'turbomind'):
    local_rank = int(os.environ.get('LOCAL_RANK', -1))
    world_size = int(os.environ.get('WORLD_SIZE', -1))
    local_ip = get_host_ip()
    if isinstance(port, List):
        assert len(port) == world_size
        port = port[local_rank]
    else:
        port += local_rank * 10
    if (world_size - local_rank) % tp == 0:
        rank_list = ','.join([str(local_rank + i) for i in range(tp)])
        command = f'CUDA_VISIBLE_DEVICES={rank_list} lmdeploy serve api_server {model_path} '\
                  f'--server-name {local_ip} --server-port {port} --tp {tp} '\
                  f'--proxy-url {proxy_url} --backend {backend}'
        print(f'running command: {command}')
        os.system(command)


if __name__ == '__main__':
    fire.Fire(main)
```

### 示例

为了进一步展示如何在集群环境中使用多机多卡服务。下面提供一个在火山云的用例：

```shell
#!/bin/bash
# 激活 conda 环境
source /path/to/your/home/miniconda3/bin/activate /path/to/your/home/miniconda3/envs/your_env
export HOME=/path/to/your/home
# 获取主节点IP地址（假设 MLP_WORKER_0_HOST 是主节点的IP）
MASTER_IP=${MLP_WORKER_0_HOST}
# 检查是否为主节点
if [ "${MLP_ROLE_INDEX}" -eq 0 ]; then
    # 启动 lmdeploy serve proxy 并放入后台
    echo "Starting lmdeploy serve proxy on master node..."
    PROXY_PORT=8000
    lmdeploy serve proxy --server-name ${MASTER_IP} --server-port ${PROXY_PORT} &
else
    # 这里我们默认调度平台同时启动了所有机器，否则要sleep一会，等待 proxy 启动成功
    echo "Not starting lmdeploy serve proxy on worker node ${MLP_ROLE_INDEX}."
fi
# 启动 torchrun 并放入后台
# 再次强调多机环境下并不需要传--nnodes 或者 --master-addr 等参数，相当于每个机器上执行一次单节点的 torchrun 即可。
torchrun \
--nproc_per_node=${MLP_WORKER_GPU} \
/path/to/script.py \
InternLM/internlm2-chat-1_8b 8 http://${MASTER_IP}:${PROXY_PORT}
# 打印主机的IP地址
echo "Host IP addresses:"
hostname -I
```

## FAQ

1. 当返回结果结束原因为 `"finish_reason":"length"`，这表示回话长度超过最大值。如需调整会话支持的最大长度，可以通过启动`api_server`时，设置`--session_len`参数大小。

2. 当服务端显存 OOM 时，可以适当减小启动服务时的 `backend_config` 的 `cache_max_entry_count` 大小

3. 关于停止符，我们只支持编码后为单个 index 的字符。此外，可能存在多种 index 都会解码出带有停止符的结果。对于这种情况，如果这些 index 数量太多，我们只会采用 tokenizer 编码出的 index。而如果你想要编码后为多个 index 的停止符，可以考虑在流式客户端做字符串匹配，匹配成功后跳出流式循环即可。

4. 自定义对话模板，请参考[chat_template.md](../advance/chat_template.md)
