# Production Metrics

LMDeploy exposes a set of metrics via Prometheus, and provides visualization via Grafana.

For the PyTorch backend, `lmdeploy:gpu_cache_usage_perc` reports logical GPU blocks referenced by live requests. Blocks
shared by multiple requests are counted once, while blocks held only by the prefix cache or stopped sessions are
excluded. This default is useful for comparing request load when routing across replicas. Set
`LMDEPLOY_ENABLE_REQUEST_CACHE_USAGE_METRIC=0` before starting the server to report total logical GPU-block occupancy
instead, including blocks retained for prefix reuse.

The PyTorch backend reports local prefix caching and Mooncake Store separately, using cumulative counts per engine:

- `Prefix cache hit rate` / `lmdeploy:prefix_cache_hit_rate` is the ratio of local hit tokens to locally queried tokens.
- With Mooncake Store enabled, logs also show `External prefix cache hit rate`, including when it is `0.0%`.
  External queries count the tokens remaining after the adopted local prefix; external hits count the additional
  tokens matched by the connector. For a 21-token input with 4 locally adopted tokens and a remote prefix ending at
  token 16, the local rate is `4/21 = 19.0%` and the external rate is `(16-4)/(21-4) = 70.6%`.
  A partial local block overwritten by a remote load is attributed to the external hit.

Hits and misses are counted at request admission. Pending asynchronous lookups
and rejected resource allocations do not count, and reuse after recompute eviction is excluded. These are lookup
statistics: subsequent transfer failures or cancellations do not undo admitted queries or hits. External statistics
remain available when local prefix caching is disabled. The local and external percentages cannot be added together.

The following Prometheus metrics carry `model_name` and `engine` labels:

| Metric                                         | Type    | Meaning                                                                |
| ---------------------------------------------- | ------- | ---------------------------------------------------------------------- |
| `lmdeploy:external_prefix_cache_hit_rate`      | Gauge   | Cumulative external hit rate for this engine, from 0 to 1              |
| `lmdeploy:external_prefix_cache_queries_total` | Counter | Cumulative externally queried tokens, excluding adopted local prefixes |
| `lmdeploy:external_prefix_cache_hits_total`    | Counter | Cumulative externally matched tokens                                   |

For example, this PromQL expression computes the external token hit rate over five minutes, combining DP engines per model:

```promql
sum by (model_name) (rate(lmdeploy:external_prefix_cache_hits_total[5m]))
/
sum by (model_name) (rate(lmdeploy:external_prefix_cache_queries_total[5m]))
```

For the Turbomind backend, `lmdeploy:gpu_cache_usage_perc` is the number of bytes held by live prefix-cache and
checkpoint objects divided by the configured cache-region size. Prefix-cache hit metrics count prompt tokens that
the engine actually skips when a request is first scheduled. Turbomind currently reports scheduler metrics for DP 1;
per-rank Turbomind metrics with DP greater than 1 are not yet supported.

## Setup Guide

This section describes how to set up the monitoring stack (Prometheus + Grafana) provided in the `lmdeploy/monitoring` directory.

## Prerequisites

- [Docker](https://docs.docker.com/engine/install/) and [Docker Compose](https://docs.docker.com/compose/install/) installed

- LMDeploy server running with metrics system enabled

## Usage (DP = 1)

1. **Start your LMDeploy server with metrics enabled**

```
lmdeploy serve api_server Qwen/Qwen2.5-7B-Instruct
```

Replace the model path according to your needs.
By default, the metrics endpoint will be available at `http://<lmdeploy_server_host>:23333/metrics`.

2. **Navigate to the monitoring directory**

```
cd lmdeploy/monitoring
```

3. **Start the monitoring stack**

```
docker compose up
```

This command will start Prometheus and Grafana in the background.

4. **Access the monitoring interfaces**

- Prometheus: Open your web browser and go to http://localhost:9090.

- Grafana: Open your web browser and go to http://localhost:3000.

5. **Log in to Grafana**

- Default Username: `admin`

- Default Password: `admin` You will be prompted to change the password upon your first login.

6. **View the Dashboard**

The LMDeploy dashboard is pre-configured and should be available automatically.

## Usage (DP > 1)

1. **Start your LMDeploy server with metrics enabled**

As an example, we use the model `Qwen/Qwen2.5-7B-Instruct` with `DP=2, TP=2`. Start the service as follows:

```bash
# Proxy server
lmdeploy serve proxy --server-port 8000 --routing-strategy 'min_expected_latency' --serving-strategy Hybrid --log-level INFO

# API server
LMDEPLOY_DP_MASTER_ADDR=127.0.0.1 \
LMDEPLOY_DP_MASTER_PORT=29555 \
lmdeploy serve api_server \
    Qwen/Qwen2.5-7B-Instruct \
    --backend pytorch \
    --tp 2 \
    --dp 2 \
    --proxy-url http://0.0.0.0:8000 \
    --nnodes 1 \
    --node-rank 0
```

You should be able to see multiple API servers added to the proxy server list. Details can be found in `lmdeploy/serve/proxy/proxy_config.json`.

For example, you may have the following API servers:

```
http://$host_ip:$api_server_port1

http://$host_ip:$api_server_port2
```

2. **Modify the Prometheus configuration**

When `DP > 1`, LMDeploy will launch one API server for each DP rank. If you want to monitor a specific API server, e.g. `http://$host_ip:$api_server_port1`, modify the configuration file `lmdeploy/monitoring/prometheus.yaml` as follows.

> Note that you should use the actual host machine IP instead of `127.0.0.1` here, since LMDeploy starts the API server using the actual host IP when `DP > 1`

```
global:
  scrape_interval: 5s
  evaluation_interval: 30s

scrape_configs:
  - job_name: lmdeploy
    static_configs:
      - targets:
          - '$host_ip:$api_server_port1' # <= Modify this
```

3. **Navigate to the monitoring folder and perform the same steps as described above**

## Troubleshooting

1. **Port conflicts**

Check if any services are occupying ports `23333` (LMDeploy server port), `9090` (Prometheus port), or `3000` (Grafana port). You can either stop the conflicting running ports or modify the config files as follows:

- Modify LMDeploy server port for Prometheus scrape

In `lmdeploy/monitoring/prometheus.yaml`

```
global:
  scrape_interval: 5s
  evaluation_interval: 30s

scrape_configs:
  - job_name: lmdeploy
    static_configs:
      - targets:
          - '127.0.0.1:23333' # <= Modify this LMDeploy server port 23333, need to match the running server port
```

- Modify Prometheus port

In `lmdeploy/monitoring/grafana/datasources/datasource.yaml`

```
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://localhost:9090 # <= Modify this Prometheus interface port 9090
    isDefault: true
    editable: false
```

- Modify Grafana port:

In `lmdeploy/monitoring/docker-compose.yaml`, for example, change the port to `3090`

Option 1: Add `GF_SERVER_HTTP_PORT` to the environment section.

```
  environment:
- GF_AUTH_ANONYMOUS_ENABLED=true
- GF_SERVER_HTTP_PORT=3090  # <= Add this line
```

Option 2: Use port mapping.

```
grafana:
  image: grafana/grafana:latest
  container_name: grafana
  ports:
  - "3090:3000"  # <= Host:Container port mapping
```

2. **No data on the dashboard**

- Create traffic

Try to send some requests to the LMDeploy server to create certain traffic

```
python3 benchmark/profile_restful_api.py --backend lmdeploy --num-prompts 5000 --dataset-path ShareGPT_V3_unfiltered_cleaned_split.json
```

After refreshing, you should be able to see data on the dashboard.
