# Copyright (c) OpenMMLab. All rights reserved.
from collections.abc import Callable, Hashable
from dataclasses import dataclass
from functools import lru_cache, partial
from typing import Any, ClassVar

import torch
import triton
import triton.language as tl

from lmdeploy.pytorch.compact_state import SSMPrefillMetadata, SSMStateMetadata
from lmdeploy.pytorch.model_inputs import get_step_ctx_manager
from lmdeploy.utils import get_logger

from ..gated_delta_rule import (
    GatedDeltaMeta,
    GatedDeltaMetaImpl,
    GatedDeltaRuleImpl,
)
from .step_metadata import CudaStepMetaUpdater, register_piecewise_graph_impl, register_step_metadata_impl
from .utils import has_tilelang

logger = get_logger('lmdeploy')


def prepare_chunked_gated_delta_rule(cu_seqlens_q: torch.Tensor) -> None:
    """Populate FLA's chunk-index cache for the current sequence lengths."""
    try:
        from fla.ops.utils import prepare_chunk_indices
    except ImportError:
        logger.warning(
            'Failed to import fla.ops.utils.prepare_chunk_indices for gated delta rule. '
            'Please make sure the version of fla is installed, up to date and compatible with lmdeploy.'
        )
        return

    # prepare_chunk_indices forces a stream synchronization. Retaining CPU
    # cumulative lengths is a separate follow-up optimization.
    try:
        chunk_size = 64
        try:
            prepare_chunk_indices(cu_seqlens_q, chunk_size, cu_seqlens_cpu=None)
        except TypeError:
            prepare_chunk_indices(cu_seqlens_q, chunk_size)
    except Exception as exc:
        logger.exception(
            'Unexpected error while preparing chunk indices for gated delta rule. '
            'Please make sure the version of fla is up to date and compatible with lmdeploy.'
        )
        raise RuntimeError('Failed to prepare chunk indices for gated delta rule; see logs for details.') from exc


@dataclass(frozen=True)
class GatedDeltaStepMetaUpdater(CudaStepMetaUpdater):
    """Prepare step-local state owned by the selected CUDA gated-delta op."""

    indexed_state: bool = False
    output_key: ClassVar[str] = 'gated_delta'
    priority: ClassVar[int] = 20

    @property
    def key(self) -> Hashable:
        return type(self), self.indexed_state

    def update(self, step_context, sequence_metadata) -> None:
        if self.indexed_state:
            if not step_context.is_decoding and step_context.ssm_prefill_meta is None:
                raise ValueError('Compact prefill requires prebuilt host-length metadata.')
            return
        if not step_context.is_decoding:
            prepare_chunked_gated_delta_rule(sequence_metadata.cu_seqlens_q)


class CudaCompactGatedDeltaMeta(GatedDeltaMeta):
    """CUDA indexed metadata: no legacy ring offsets or payload-gather indices."""

    def __init__(
        self,
        num_tokens: int,
        is_decoding: bool,
        ssm_state_meta: SSMStateMetadata,
        ssm_prefill_meta: SSMPrefillMetadata | None,
    ) -> None:
        self.is_decoding = is_decoding
        self.ssm_state_meta = ssm_state_meta
        self.ssm_prefill_meta = ssm_prefill_meta
        self.is_init_token = None
        batch, width = ssm_state_meta.output_state_ids.shape
        if is_decoding:
            if num_tokens != batch * width or ssm_prefill_meta is not None:
                raise ValueError('Compact decode requires one destination per input token and no prefill plan.')
        else:
            if (width != 1 or ssm_prefill_meta is None or ssm_prefill_meta.cu_seqlens.numel() != batch + 1
                    or ssm_prefill_meta.seq_idx.numel() != num_tokens
                    or ssm_prefill_meta.cu_seqlens.device != ssm_state_meta.input_state_ids.device):
                raise ValueError('Compact prefill requires matching packed metadata and one final destination.')
            self.is_init_token = ssm_prefill_meta.is_init_token


class CudaGatedDeltaMetaImpl(GatedDeltaMetaImpl):
    """Build explicit gated-delta metadata, eagerly during piecewise
    prefill."""

    def __init__(self, indexed_state: bool = False) -> None:
        self.indexed_state = indexed_state
        self._piecewise_forward: Callable[..., GatedDeltaMeta] | None = None
        register_piecewise_graph_impl(self)

    def _build(
        self,
        num_tokens: int,
        conv_kernel_size: int,
        state_ids: torch.Tensor,
        attn_metadata: Any,
    ) -> GatedDeltaMeta:
        if not self.indexed_state:
            return GatedDeltaMeta(num_tokens, conv_kernel_size, state_ids, attn_metadata)
        context = get_step_ctx_manager().current_context()
        return CudaCompactGatedDeltaMeta(num_tokens, attn_metadata.is_decoding,
                                         context.ssm_state_meta, context.ssm_prefill_meta)

    def forward(
        self,
        num_tokens: int,
        conv_kernel_size: int,
        state_ids: torch.Tensor,
        attn_metadata: Any,
    ) -> GatedDeltaMeta:
        if self._piecewise_forward is None:
            return self._build(num_tokens, conv_kernel_size, state_ids, attn_metadata)
        return self._piecewise_forward(num_tokens, conv_kernel_size, state_ids, attn_metadata)

    def supports_piecewise_cuda_graph(self) -> bool:
        """Return whether metadata can be produced outside graph pieces."""
        return True

    def enable_piecewise_cuda_graph(self) -> None:
        """Install an eager producer whose result stays outside graph
        pieces."""
        if self._piecewise_forward is not None:
            return

        from lmdeploy.pytorch.backends.cuda.graph_runner.piecewise import (
            eager_boundary,
            get_piecewise_graph_execution,
        )

        @eager_boundary(eager_only_output=True)
        def build_eager(
            conv_kernel_size: int,
            state_ids: torch.Tensor,
            attn_metadata: Any,
        ) -> GatedDeltaMeta:
            execution = get_piecewise_graph_execution()
            assert execution is not None
            return self._build(execution.raw_tokens, conv_kernel_size, state_ids, attn_metadata)

        def piecewise_forward(
            num_tokens: int,
            conv_kernel_size: int,
            state_ids: torch.Tensor,
            attn_metadata: Any,
        ) -> GatedDeltaMeta:
            if get_piecewise_graph_execution() is None:
                return self._build(num_tokens, conv_kernel_size, state_ids, attn_metadata)
            return build_eager(conv_kernel_size, state_ids, attn_metadata)

        self._piecewise_forward = piecewise_forward


@lru_cache
def has_fla():
    try:
        from fla.ops.gated_delta_rule import chunk_gated_delta_rule  # noqa: F401
        return True
    except Exception:
        return False


@triton.jit
def _state_select_kernel(
    state_ptr,
    out_ptr,
    state_indices_ptr,
    spec_offsets_ptr,
    stride_s0,
    stride_s1,
    stride_o0,
    INNER_SIZE: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    NUM_STATES: tl.constexpr,
    NUM_SLOTS: tl.constexpr,
):
    """Fused state select: out[b] = state[state_indices[b],
    spec_offsets[b]]."""
    batch_id = tl.program_id(0).to(tl.int64)
    block_id = tl.program_id(1)

    state_idx = tl.load(state_indices_ptr + batch_id)
    spec_off = tl.load(spec_offsets_ptr + batch_id)

    offs = block_id * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offs < INNER_SIZE

    src_ptr = state_ptr + state_idx * stride_s0 + spec_off * stride_s1 + offs
    dst_ptr = out_ptr + batch_id * stride_o0 + offs

    valid = (state_idx >= 0) & (state_idx < NUM_STATES) & (spec_off >= 0) & (spec_off < NUM_SLOTS)
    data = tl.load(src_ptr, mask=mask & valid, other=0)
    tl.store(dst_ptr, data, mask=mask)


@triton.jit
def _state_scatter_kernel(
    state_ptr,
    src_ptr,
    state_indices_ptr,
    spec_offsets_ptr,
    stride_s0,
    stride_s1,
    stride_i0,
    INNER_SIZE: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    NUM_STATES: tl.constexpr,
    NUM_SLOTS: tl.constexpr,
):
    """Fused state scatter: state[si[b], so[b]] = src[b]."""
    batch_id = tl.program_id(0).to(tl.int64)
    block_id = tl.program_id(1)

    state_idx = tl.load(state_indices_ptr + batch_id)
    spec_off = tl.load(spec_offsets_ptr + batch_id)

    offs = block_id * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = (offs < INNER_SIZE) & (state_idx >= 0) & (state_idx < NUM_STATES)
    mask = mask & (spec_off >= 0) & (spec_off < NUM_SLOTS)

    in_ptr = src_ptr + batch_id * stride_i0 + offs
    dst_ptr = state_ptr + state_idx * stride_s0 + spec_off * stride_s1 + offs

    data = tl.load(in_ptr, mask=mask)
    tl.store(dst_ptr, data, mask=mask)


def _state_select(state, state_indices, spec_offsets):
    """Fused state select: out = state[state_indices, spec_offsets].

    Requires inner dims [2:] to be contiguous. Invalid state/slot ids yield
    zeros, allowing callers to clear initial or padded requests in this load.
    """
    B = state_indices.shape[0]
    inner_shape = state.shape[2:]
    inner_size = 1
    for s in inner_shape:
        inner_size *= s

    out = state.new_empty((B, *inner_shape))

    BLOCK_SIZE = 1024
    num_blocks = triton.cdiv(inner_size, BLOCK_SIZE)
    grid = (B, num_blocks)

    _state_select_kernel[grid](
        state,
        out,
        state_indices,
        spec_offsets,
        state.stride(0),
        state.stride(1),
        out.stride(0),
        INNER_SIZE=inner_size,
        BLOCK_SIZE=BLOCK_SIZE,
        NUM_STATES=state.shape[0],
        NUM_SLOTS=state.shape[1],
    )
    return out


def _state_scatter(state, state_indices, spec_offsets, src):
    """Fused state scatter: state[state_indices, spec_offsets] =
    src.to(state.dtype).

    Requires inner dims [2:] to be contiguous. Invalid state/slot ids are
    ignored so padded requests cannot overwrite a live cache row.
    """
    if src.dtype != state.dtype:
        src = src.to(state.dtype)

    inner_size = 1
    for s in state.shape[2:]:
        inner_size *= s

    BLOCK_SIZE = 1024
    num_blocks = triton.cdiv(inner_size, BLOCK_SIZE)
    B = state_indices.shape[0]
    grid = (B, num_blocks)

    _state_scatter_kernel[grid](
        state,
        src,
        state_indices,
        spec_offsets,
        state.stride(0),
        state.stride(1),
        src.stride(0),
        INNER_SIZE=inner_size,
        BLOCK_SIZE=BLOCK_SIZE,
        NUM_STATES=state.shape[0],
        NUM_SLOTS=state.shape[1],
    )


class CudaGatedDeltaRuleImpl(GatedDeltaRuleImpl):

    def __init__(self, indexed_state: bool = False):
        self.indexed_state = indexed_state
        # intracard_cp implement would force sync cuda stream
        import os
        os.environ['FLA_INTRACARD_CP'] = '0'

        if not has_fla() or not has_tilelang():
            raise ImportError('fla and tilelang is required for CudaGatedDeltaRuleImpl')
        from fla.ops.gated_delta_rule import chunk_gated_delta_rule

        from lmdeploy.pytorch.kernels.cuda.gated_delta_rule import fused_recurrent_gated_delta_rule
        self.chunk_func = chunk_gated_delta_rule
        self.recurrent_func = fused_recurrent_gated_delta_rule
        self._piecewise_forward: Callable[..., torch.Tensor] | None = None

        register_step_metadata_impl(self)

    def get_step_metadata_provider(self):
        """Describe preparation required by this selected implementation."""
        return GatedDeltaStepMetaUpdater(indexed_state=self.indexed_state)

    def supports_piecewise_cuda_graph(self) -> bool:
        """Return whether this CUDA implementation can run in an eager
        island."""
        return True

    def enable_piecewise_cuda_graph(self) -> None:
        """Install the phase-dispatching gated-delta boundary used by PCG.

        Wraps ``forward`` (the decode/prefill dispatcher) so a replaying plan
        runs the phase-appropriate rule eagerly from live metadata. This keeps
        decode requests on the recurrent decode kernel for batch-invariant
        outputs while still letting DP hybrid decode ranks share the prefill
        plan. Mirrors the CUDA attention boundary.
        """
        if self._piecewise_forward is not None:
            return

        from lmdeploy.pytorch.backends.cuda.graph_runner.piecewise import (
            PaddedTensorOutputAdapter,
            eager_boundary,
            get_piecewise_graph_execution,
        )

        original_forward = self.forward

        @eager_boundary(
            adapter_factory=partial(PaddedTensorOutputAdapter, token_axis=1),
            reuse_bridge_after_next_step=True,
        )
        def run_eager(
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            b: torch.Tensor,
            a: torch.Tensor,
            dt_bias: torch.Tensor,
            a_log_exp: torch.Tensor,
            recurrent_state: torch.Tensor,
            gated_delta_meta: GatedDeltaMeta,
            kv_ratio: int,
            use_qk_l2norm_in_kernel: bool,
        ) -> torch.Tensor:
            execution = get_piecewise_graph_execution()
            assert execution is not None
            raw_tokens = execution.raw_tokens
            return original_forward(
                query[:, :raw_tokens],
                key[:, :raw_tokens],
                value[:, :raw_tokens],
                b[:, :raw_tokens],
                a[:, :raw_tokens],
                dt_bias,
                a_log_exp,
                recurrent_state,
                gated_delta_meta,
                kv_ratio,
                use_qk_l2norm_in_kernel,
            )

        def piecewise_forward(
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            b: torch.Tensor,
            a: torch.Tensor,
            dt_bias: torch.Tensor,
            a_log_exp: torch.Tensor,
            recurrent_state: torch.Tensor,
            gated_delta_meta: GatedDeltaMeta,
            kv_ratio: int,
            use_qk_l2norm_in_kernel: bool,
        ) -> torch.Tensor:
            if get_piecewise_graph_execution() is None:
                return original_forward(
                    query,
                    key,
                    value,
                    b,
                    a,
                    dt_bias,
                    a_log_exp,
                    recurrent_state,
                    gated_delta_meta,
                    kv_ratio,
                    use_qk_l2norm_in_kernel,
                )
            return run_eager(
                query,
                key,
                value,
                b,
                a,
                dt_bias,
                a_log_exp,
                recurrent_state,
                gated_delta_meta,
                kv_ratio,
                use_qk_l2norm_in_kernel,
            )

        self._piecewise_forward = piecewise_forward
        self.forward = piecewise_forward

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        b: torch.Tensor,
        a: torch.Tensor,
        dt_bias: torch.Tensor,
        a_log_exp: torch.Tensor,
        recurrent_state: torch.Tensor,
        gated_delta_meta: GatedDeltaMeta,
        kv_ratio: int,
        use_qk_l2norm_in_kernel: bool,
    ) -> torch.Tensor:
        if not self.indexed_state:
            return super().forward(
                query, key, value, b, a, dt_bias, a_log_exp, recurrent_state,
                gated_delta_meta, kv_ratio, use_qk_l2norm_in_kernel)
        meta = gated_delta_meta
        ids = meta.ssm_state_meta
        # Indexed requests without history read the immutable zero-state unit.
        # Keep their real gate: a -1e6 reset loses the smaller decays when FLA
        # forms FP32 cumulative sums in the first chunk.
        query, key, g, beta, normalized = self.prepare_inputs(
            query, key, b, a, dt_bias, a_log_exp, kv_ratio,
            use_qk_l2norm_in_kernel=use_qk_l2norm_in_kernel, is_decoding=meta.is_decoding,
            init_token_mask=None)
        if meta.is_decoding:
            batch, width = ids.output_state_ids.shape
            q, k, v, g, beta = [x[0].unflatten(0, (batch, width)).contiguous()
                                for x in (query, key, value, g, beta)]
            output, _ = self.recurrent_func(
                q, k, v, g=g, beta=beta, initial_state=recurrent_state, output_final_state=True,
                state_indices=ids.input_state_ids, output_state_indices=ids.output_state_ids,

                use_qk_l2norm_in_kernel=use_qk_l2norm_in_kernel and not normalized, transpose_state_layout=True)
            return output.flatten(0, 1).unsqueeze(0)
        from lmdeploy.pytorch.kernels.cuda.indexed_chunk_gated_delta import indexed_chunk_gated_delta_rule
        if use_qk_l2norm_in_kernel and not normalized:
            query = torch.nn.functional.normalize(query, p=2, dim=-1)
            key = torch.nn.functional.normalize(key, p=2, dim=-1)
        prefill = meta.ssm_prefill_meta
        return indexed_chunk_gated_delta_rule(
            query, key, value, g, beta, recurrent_state, ids.input_state_ids, ids.output_state_ids[:, 0],
            state_v_first=True, cu_seqlens=prefill.cu_seqlens, chunk_indices=prefill.chunk_indices,
            chunk_offsets=prefill.chunk_offsets, checkpoint_ids=prefill.checkpoint_ids,
            checkpoint_offsets=prefill.checkpoint_offsets)

    def prepare_inputs(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        b: torch.Tensor,
        a: torch.Tensor,
        dt_bias: torch.Tensor,
        a_log_exp: torch.Tensor,
        kv_ratio: int,
        use_qk_l2norm_in_kernel: bool = False,
        is_decoding: bool = False,
        init_token_mask: torch.Tensor | None = None,
    ):
        """Prepare q/k/g/beta for gated delta rule."""
        if use_qk_l2norm_in_kernel:
            from lmdeploy.pytorch.kernels.cuda.gated_delta_preprocess import gated_delta_preprocess
            init_token_mask = None if is_decoding else init_token_mask
            apply_qk_l2norm = not is_decoding
            q, k, beta, g = gated_delta_preprocess(
                q,
                k,
                b,
                a,
                dt_bias,
                a_log_exp,
                kv_ratio,
                init_token_mask=init_token_mask,
                apply_qk_l2norm=apply_qk_l2norm,
            )
            return q, k, g, beta, apply_qk_l2norm
        return super().prepare_inputs(
            q,
            k,
            b,
            a,
            dt_bias,
            a_log_exp,
            kv_ratio,
            use_qk_l2norm_in_kernel=use_qk_l2norm_in_kernel,
            is_decoding=is_decoding,
            init_token_mask=init_token_mask,
        )

    def chunk_gated_delta_rule(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        g: torch.Tensor | None = None,
        beta: torch.Tensor | None = None,
        initial_state: torch.Tensor | None = None,
        state_indices: torch.Tensor | None = None,
        scale: float | None = None,
        use_qk_l2norm_in_kernel: bool = False,
        cu_seqlens: torch.Tensor | None = None,
        output_final_state: bool = False,
        spec_state_offsets: torch.Tensor | None = None,
        transpose_state_layout: bool = False,
    ):

        assert initial_state is not None
        recurrent_state = initial_state

        if spec_state_offsets is not None:
            spec_read_offsets = spec_state_offsets[0]
            init_state = _state_select(recurrent_state, state_indices, spec_read_offsets)
        else:
            batch_state = recurrent_state.index_select(0, state_indices)
            init_state = batch_state

        if use_qk_l2norm_in_kernel:
            # l2norm in fla would recompile when seqlen changed.
            q = torch.nn.functional.normalize(q, p=2, dim=-1)
            k = torch.nn.functional.normalize(k, p=2, dim=-1)
        core_attn_out, last_state = self.chunk_func(
            q,
            k,
            v,
            g=g,
            beta=beta,
            scale=scale,
            initial_state=init_state,
            output_final_state=output_final_state,
            use_qk_l2norm_in_kernel=False,
            cu_seqlens=cu_seqlens,
            transpose_state_layout=transpose_state_layout,
        )
        if spec_state_offsets is not None:
            # write to next slots
            spec_write_offsets = spec_state_offsets[1]
            _state_scatter(recurrent_state, state_indices, spec_write_offsets, last_state)
        else:
            last_state = recurrent_state.index_copy_(0, state_indices, last_state.to(recurrent_state.dtype))
        if not output_final_state:
            last_state = None
        return core_attn_out, last_state

    def fused_recurrent_gated_delta_rule(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        g: torch.Tensor | None = None,
        beta: torch.Tensor | None = None,
        initial_state: torch.Tensor | None = None,
        state_indices: torch.Tensor | None = None,
        scale: float | None = None,
        use_qk_l2norm_in_kernel: bool = False,
        output_final_state: bool = False,
        cache_seqlens: torch.Tensor | None = None,
        transpose_state_layout: bool = False,
    ):
        return self.recurrent_func(
            q,
            k,
            v,
            g=g,
            beta=beta,
            scale=scale,
            initial_state=initial_state,
            state_indices=state_indices,
            use_qk_l2norm_in_kernel=use_qk_l2norm_in_kernel,
            output_final_state=output_final_state,
            cache_seqlens=cache_seqlens,
            transpose_state_layout=transpose_state_layout,
        )
