# Copyright (c) OpenMMLab. All rights reserved.

from collections.abc import Callable

import torch

import lmdeploy.pytorch.distributed as dist
from lmdeploy.pytorch.backends.deepep_state import get_deepep_state
from lmdeploy.pytorch.backends.moe import FusedMoEBuildSpec, FusedMoEImpl
from lmdeploy.pytorch.distributed import get_dist_manager
from lmdeploy.pytorch.kernels.cuda import fused_moe
from lmdeploy.pytorch.kernels.cuda.moe.fused_moe import _renormalize
from lmdeploy.pytorch.model_inputs import get_step_ctx_manager
from lmdeploy.utils import get_logger

from ..step_metadata import register_piecewise_graph_impl
from .ep_utils import gather_outputs_by_attn_tp, mask_invalid_tokens, split_inputs_by_attn_tp

logger = get_logger('lmdeploy')


class TritonFusedMoEImpl(FusedMoEImpl):
    """Triton fused moe implementation."""

    def __init__(self,
                 top_k: int,
                 num_experts: int,
                 renormalize: bool = False,
                 output_scale: float = 1.0,
                 fp32_acc: bool = False):
        self.num_experts = num_experts
        self.top_k = top_k
        self.renormalize = renormalize
        self.output_scale = output_scale
        self.fp32_acc = fp32_acc

    def update_weights(self, gate_up_weights: torch.Tensor, down_weights: torch.Tensor):
        gate_up_weights = gate_up_weights.transpose(1, 2).contiguous().transpose(1, 2)
        down_weights = down_weights.transpose(1, 2).contiguous().transpose(1, 2)
        return gate_up_weights, down_weights

    def ep_expert_list(self, world_size: int, rank: int):
        """Experts list of current rank."""
        num_experts = self.num_experts
        expert_per_rank = (num_experts + world_size - 1) // world_size
        first_expert = rank * expert_per_rank
        last_expert = min(first_expert + expert_per_rank, num_experts)
        return list(range(first_expert, last_expert))

    def forward(self,
                hidden_states: torch.Tensor,
                topk_weights: torch.Tensor,
                topk_ids: torch.LongTensor,
                gate_up_weights: torch.Tensor,
                down_weights: torch.Tensor,
                gate_up_bias: torch.Tensor = None,
                down_bias: torch.Tensor = None,
                expert_list: list[int] = None,
                act_func: Callable = None):
        """forward."""
        expert_offset = 0
        num_experts = None
        if expert_list is not None and len(expert_list) != self.num_experts:
            expert_offset = expert_list[0]
            num_experts = self.num_experts
        return fused_moe(hidden_states,
                         gate_up_weights,
                         down_weights,
                         topk_weights=topk_weights,
                         topk_ids=topk_ids,
                         topk=self.top_k,
                         w1_bias=gate_up_bias,
                         w2_bias=down_bias,
                         expert_offset=expert_offset,
                         num_experts=num_experts,
                         renormalize=self.renormalize,
                         act_func=act_func,
                         output_scale=self.output_scale,
                         fp32_acc=self.fp32_acc)


# modify from dlblas: https://github.com/DeepLink-org/DLBlas
class FusedMoENormal:

    def __init__(
        self,
        ep_size: int,
        ep_group: dist.ProcessGroup,
        num_experts: int,
        hidden_dim: int,
        layer_index: int = 0,
        top_k: int = 8,
        out_dtype: torch.dtype = torch.bfloat16,
        num_max_dispatch_tokens_per_rank: int = 128,
        fp32_acc: bool = False,
        output_scale: float = 1.0,
    ):
        from lmdeploy.pytorch.backends.cuda.token_dispatcher import DeepEPTokenDispatcherNormal
        self.layer_index = layer_index
        self.top_k = top_k
        self.num_experts = num_experts
        self.num_local_experts = num_experts // ep_size
        self.out_dtype = out_dtype
        self.fp32_acc = fp32_acc
        self.output_scale = output_scale
        self.token_dispatcher = DeepEPTokenDispatcherNormal(
            group=ep_group,
            num_experts=num_experts,
            num_local_experts=self.num_local_experts,
            hidden_size=hidden_dim,
            params_dtype=out_dtype,
            num_max_dispatch_tokens_per_rank=num_max_dispatch_tokens_per_rank,
        )

    def forward(
        self,
        hidden_states: torch.Tensor,
        topk_weights: torch.Tensor,
        topk_ids: torch.LongTensor,
        up_weights: torch.Tensor,
        down_weights: torch.Tensor,
        expert_list: list[int] = None,
        act_func: Callable = None,
    ):
        """forward."""
        from lmdeploy.pytorch.kernels.cuda.moe.ep import fused_moe_v3
        x, recv_topk_ids, recv_topk_weights, recv_tokens_per_expert = self.token_dispatcher.dispatch(
            hidden_states,
            topk_ids,
            topk_weights,
            expert_list,
        )
        topk_ids, topk_weights = None, None
        out_states = fused_moe_v3(x, recv_topk_ids, recv_topk_weights, up_weights, down_weights, recv_tokens_per_expert,
                                  act_func=act_func, fp32_acc=self.fp32_acc, output_scale=self.output_scale)
        out_states = self.token_dispatcher.combine(out_states)
        return out_states

    def capture(self):
        return self.token_dispatcher.buffer_normal.capture()

    def wait(self, event):
        self.token_dispatcher.release()
        event.current_stream_wait()

    def dispatch_async(self,
                       x: torch.Tensor,
                       topk_idx: torch.Tensor,
                       topk_weights: torch.Tensor,
                       num_experts: int | None = None,
                       previous_event=None,
                       async_finish=True):
        return self.token_dispatcher.dispatch_normal_async(x, topk_idx, topk_weights, num_experts, previous_event,
                                                           async_finish)

    def combine_async(self, x: torch.Tensor, handle: tuple, previous_event=None, async_finish=True):
        return self.token_dispatcher.combine_normal_async(x, handle, previous_event, async_finish)

    def release(self):
        return self.token_dispatcher.release()

    def fusedmoe_forward(self, state, up_weight, down_weight, act_func=None):
        from lmdeploy.pytorch.kernels.cuda.moe.ep import fused_moe_v3
        return fused_moe_v3(state['recv_hidden_states'], state['recv_topk_idx'], state['recv_topk_weights'], up_weight,
                            down_weight, state['recv_tokens_per_expert'], act_func=act_func,
                            fp32_acc=self.fp32_acc, output_scale=self.output_scale)


def _disposible_tensor(tensor):
    from lmdeploy.pytorch.backends.cuda.token_dispatcher import DisposibleTensor
    if isinstance(tensor, torch.Tensor):
        tensor = DisposibleTensor(tensor)
    else:
        tensor = [DisposibleTensor(x) for x in tensor]
    return tensor


def dispatch_ll(
    self,
    hidden_states: torch.Tensor,
    topk_idx: torch.Tensor,
    topk_weights: torch.Tensor,
    num_experts: int,
    use_fp8: bool = True,
):
    """Dispatch low latency."""
    if num_experts is not None and self.num_experts is not None:
        assert self.num_experts == num_experts
    topk_idx = topk_idx.to(torch.int64)
    mask_invalid_tokens(topk_idx)
    expected_m = (hidden_states.shape[0] * self.get_buffer().group_size * topk_idx.shape[1] +
                  num_experts) // num_experts

    (
        packed_recv_hidden,
        masked_m,
        self.handle,
        event,
        hook,
    ) = self.get_buffer().low_latency_dispatch(
        hidden_states,
        topk_idx,
        self.num_max_dispatch_tokens_per_rank,
        num_experts,
        use_fp8=use_fp8,
        async_finish=not self.return_recv_hook,
        return_recv_hook=self.return_recv_hook,
    )
    hook() if self.return_recv_hook else event.current_stream_wait()
    packed_recv_hidden = _disposible_tensor(packed_recv_hidden)
    return (
        packed_recv_hidden,
        topk_idx,
        topk_weights,
        masked_m,
        expected_m,
    )


def dispatch_async_ll(
    self,
    hidden_states: torch.Tensor,
    topk_idx: torch.Tensor,
    num_experts: int | None = None,
    use_fp8: bool = True,
    async_finish: bool = True,
):
    assert topk_idx.dtype == torch.int64
    mask_invalid_tokens(topk_idx)
    if num_experts is not None and self.num_experts is not None:
        assert self.num_experts == num_experts
    (
        recv_hidden_states,
        recv_expert_count,
        handle,
        event,
        hook,
    ) = self.get_buffer().low_latency_dispatch(
        hidden_states,
        topk_idx,
        self.num_max_dispatch_tokens_per_rank,
        num_experts=self.num_experts,
        use_fp8=use_fp8,
        async_finish=async_finish,
        return_recv_hook=not async_finish,
    )
    recv_hidden_states = _disposible_tensor(recv_hidden_states)
    return recv_hidden_states, recv_expert_count, handle, event, hook


class FusedMoELowLatency:

    def __init__(
        self,
        ep_size: int,
        ep_group: dist.ProcessGroup,
        num_experts: int,
        hidden_dim: int,
        layer_index: int,
        out_dtype: torch.dtype = torch.bfloat16,
        num_max_dispatch_tokens_per_rank: int = 128,
        output_scale: float = 1.0,
    ):
        from lmdeploy.pytorch.backends.cuda.token_dispatcher import DeepEPTokenDispatcherLowLatency
        self.num_experts = num_experts
        self.layer_index = layer_index
        self.out_dtype = out_dtype
        self.output_scale = output_scale
        self.token_dispatcher = DeepEPTokenDispatcherLowLatency(
            group=ep_group,
            num_experts=num_experts,
            num_local_experts=num_experts // ep_size,
            hidden_size=hidden_dim,
            params_dtype=out_dtype,
            num_max_dispatch_tokens_per_rank=num_max_dispatch_tokens_per_rank,
        )

    def experts(
        self,
        hidden_states: torch.Tensor,
        gate_up_weight: torch.Tensor,
        gate_down_weight: torch.Tensor,
        masked_m: torch.Tensor,
        expected_m: int,
        act_func: Callable = None,
    ):
        from lmdeploy.pytorch.backends.cuda.token_dispatcher import DisposibleTensor
        from lmdeploy.pytorch.kernels.cuda.activation import silu_and_mul_moe_ep
        from lmdeploy.pytorch.third_party.deep_gemm import m_grouped_bf16_gemm_nt_masked
        num_groups, m, _ = hidden_states.shape
        n = gate_up_weight.size(1)
        expected_m = min(expected_m, m)
        gateup_output = gate_up_weight.new_empty((num_groups, m, n))
        m_grouped_bf16_gemm_nt_masked(DisposibleTensor.maybe_unwrap(hidden_states), gate_up_weight, gateup_output,
                                      masked_m, expected_m)
        DisposibleTensor.maybe_dispose(hidden_states)
        if act_func is None:
            down_input = silu_and_mul_moe_ep(gateup_output, masked_m)
        else:
            # Only masked_m valid rows are consumed by the next GEMM.
            down_input = act_func(gateup_output.flatten(0, 1)).view(num_groups, m, n // 2)
        del gateup_output
        n = gate_down_weight.size(1)
        down_output = down_input.new_empty((num_groups, m, n))
        m_grouped_bf16_gemm_nt_masked(down_input, gate_down_weight, down_output, masked_m, expected_m)
        return down_output

    def forward(self,
                hidden_states: torch.Tensor,
                topk_weights: torch.Tensor,
                topk_ids: torch.LongTensor,
                up_weights: torch.Tensor,
                down_weights: torch.Tensor,
                expert_list: list[int] = None,
                act_func: Callable = None):
        """forward."""
        recv_hidden_states, topk_idx, topk_weights, masked_m, expected_m = dispatch_ll(
            self.token_dispatcher,
            hidden_states,
            topk_ids,
            topk_weights,
            self.num_experts,
            use_fp8=False,
        )
        hidden_states = None
        out_states = self.experts(recv_hidden_states, up_weights, down_weights, masked_m, expected_m,
                                  act_func=act_func)
        # DeepEP LL accumulates in FP32 and stores BF16. Scale the FP32
        # combine weights, not the already-rounded BF16 result.
        if self.output_scale != 1.0:
            topk_weights = topk_weights.float() * self.output_scale
        out_states = self.token_dispatcher.combine(out_states, topk_idx, topk_weights)
        return out_states

    def wait(self, event):
        event.current_stream_wait()

    def dispatch_async(
        self,
        hidden_states: torch.Tensor,
        topk_idx: torch.Tensor,
        num_experts: int | None = None,
        use_fp8: bool = False,
        async_finish: bool = True,
    ):
        return dispatch_async_ll(self.token_dispatcher, hidden_states, topk_idx, num_experts, use_fp8, async_finish)

    def combine_async(
        self,
        hidden_states: torch.Tensor,
        topk_idx: torch.Tensor,
        topk_weights: torch.Tensor,
        handle: tuple,
        async_finish: bool,
    ):
        if self.output_scale != 1.0:
            topk_weights = topk_weights.float() * self.output_scale
        return self.token_dispatcher.combine_async(hidden_states, topk_idx, topk_weights, handle, async_finish)

    def fusedmoe_forward(self, state, up_weight, down_weight, act_func=None):
        recv_hidden_states = state['recv_hidden_states']
        masked_m = state['recv_expert_count']
        hidden_shape = state['raw_hidden_shape']
        topk_idx = state['topk_idx']
        expected_m = (hidden_shape[0] * self.token_dispatcher.buffer_low_latency.group_size * topk_idx.shape[1] +
                      self.token_dispatcher.num_experts) // self.token_dispatcher.num_experts
        return self.experts(recv_hidden_states, up_weight, down_weight, masked_m, expected_m, act_func=act_func)


def _build_deepep_moe(
    low_latency_mode: bool,
    ep_size: int,
    ep_group: dist.ProcessGroup,
    num_experts: int,
    hidden_dim: int,
    top_k: int,
    layer_idx: int = 0,
    out_dtype: torch.dtype = torch.bfloat16,
    num_max_dispatch_tokens_per_rank: int = 128,
    fp32_acc: bool = False,
    output_scale: float = 1.0,
):
    if low_latency_mode:
        return FusedMoELowLatency(ep_size=ep_size,
                                  ep_group=ep_group,
                                  num_experts=num_experts,
                                  hidden_dim=hidden_dim,
                                  layer_index=layer_idx,
                                  out_dtype=out_dtype,
                                  num_max_dispatch_tokens_per_rank=num_max_dispatch_tokens_per_rank,
                                  output_scale=output_scale)
    else:
        return FusedMoENormal(ep_size=ep_size,
                              ep_group=ep_group,
                              num_experts=num_experts,
                              hidden_dim=hidden_dim,
                              layer_index=layer_idx,
                              top_k=top_k,
                              out_dtype=out_dtype,
                              num_max_dispatch_tokens_per_rank=num_max_dispatch_tokens_per_rank,
                              fp32_acc=fp32_acc,
                              output_scale=output_scale)


class FusedMoEEPImpl(TritonFusedMoEImpl):
    """Fused moe implementation."""

    def __init__(
        self,
        ep_size: int,
        ep_group: dist.ProcessGroup,
        top_k: int,
        num_experts: int,
        hidden_dim: int,
        renormalize: bool = False,
        output_scale: float = 1.0,
        layer_idx: int = 0,
        out_dtype: torch.dtype = torch.bfloat16,
        num_max_dispatch_tokens_per_rank: int = 128,
        fp32_acc: bool = False,
    ):
        super().__init__(top_k, num_experts, renormalize, output_scale, fp32_acc)
        self.num_experts = num_experts
        self.ep_size = ep_size
        self.ep_group = ep_group
        self.hidden_dim = hidden_dim
        self.layer_idx = layer_idx
        self.out_dtype = out_dtype
        self.num_max_dispatch_tokens_per_rank = num_max_dispatch_tokens_per_rank

        try:
            import deep_gemm  # noqa: F401
        except ImportError:
            logger.exception('DeepGEMM is required for DeepEP MoE implementation.')
            raise

        from lmdeploy.pytorch.backends.cuda.token_dispatcher import DeepEPBuffer, use_deepep
        if not use_deepep:
            raise ImportError('DeepEP is required for DeepEP MoE implementation. Please install '
                              'https://github.com/deepseek-ai/DeepEP.')
        get_deepep_state().enable()
        if hasattr(DeepEPBuffer, 'set_explicitly_destroy'):
            DeepEPBuffer.set_explicitly_destroy()

        # pre-allocate buffer
        self.fusedmoe_build(True)

        self._piecewise_forward: Callable[..., torch.Tensor] | None = None
        register_piecewise_graph_impl(self)

    def update_weights(self, gate_up_weights: torch.Tensor, down_weights: torch.Tensor):
        return gate_up_weights, down_weights

    def _forward_moe(self,
                     hidden_states: torch.Tensor,
                     topk_weights: torch.Tensor,
                     topk_ids: torch.LongTensor,
                     gate_up_weights: torch.Tensor,
                     down_weights: torch.Tensor,
                     gate_up_bias: torch.Tensor = None,
                     down_bias: torch.Tensor = None,
                     expert_list: list[int] = None,
                     act_func: Callable = None):
        """forward."""
        step_ctx = get_step_ctx_manager().current_context()
        low_latency_mode = step_ctx.global_is_decoding()
        hidden_states, topk_weights, topk_ids, split_size = split_inputs_by_attn_tp(
            hidden_states, topk_weights, topk_ids, mask_padding=low_latency_mode)

        topk_weights = self.do_renormalize(topk_weights)
        moe = self.fusedmoe_build(low_latency_mode)
        out_states = moe.forward(hidden_states, topk_weights, topk_ids, gate_up_weights, down_weights, expert_list,
                                 act_func=act_func)

        out_states = gather_outputs_by_attn_tp(out_states, split_size)
        return out_states

    def forward(self,
                hidden_states: torch.Tensor,
                topk_weights: torch.Tensor,
                topk_ids: torch.LongTensor,
                gate_up_weights: torch.Tensor,
                down_weights: torch.Tensor,
                gate_up_bias: torch.Tensor = None,
                down_bias: torch.Tensor = None,
                expert_list: list[int] = None,
                act_func: Callable = None):
        """forward."""
        if self._piecewise_forward is not None:
            return self._piecewise_forward(hidden_states, topk_weights, topk_ids, gate_up_weights, down_weights,
                                           gate_up_bias, down_bias, expert_list, act_func)
        return self._forward_moe(hidden_states, topk_weights, topk_ids, gate_up_weights, down_weights, gate_up_bias,
                                 down_bias, expert_list, act_func)

    def supports_piecewise_cuda_graph(self) -> bool:
        """Return whether this DeepEP MoE implementation supports PCG."""
        return True

    def enable_piecewise_cuda_graph(self) -> None:
        """Install the DeepEP MoE eager boundary owned by this CUDA op."""
        if self._piecewise_forward is not None:
            return

        from lmdeploy.pytorch.backends.cuda.graph_runner.piecewise import (
            ViewTolerantPaddedAdapter,
            eager_boundary,
            get_piecewise_graph_execution,
        )

        @eager_boundary(
            adapter_factory=ViewTolerantPaddedAdapter,
            reuse_bridge_after_next_step=True,
        )
        def run_eager_moe(
            hidden_states: torch.Tensor,
            topk_weights: torch.Tensor,
            topk_ids: torch.LongTensor,
            gate_up_weights: torch.Tensor,
            down_weights: torch.Tensor,
            gate_up_bias: torch.Tensor = None,
            down_bias: torch.Tensor = None,
            expert_list: list[int] = None,
            act_func: Callable = None,
        ):
            execution = get_piecewise_graph_execution()
            assert execution is not None
            raw_tokens = execution.raw_tokens
            return self._forward_moe(hidden_states[:raw_tokens], topk_weights[:raw_tokens], topk_ids[:raw_tokens],
                                     gate_up_weights, down_weights, gate_up_bias, down_bias, expert_list, act_func)

        def piecewise_forward(
            hidden_states: torch.Tensor,
            topk_weights: torch.Tensor,
            topk_ids: torch.LongTensor,
            gate_up_weights: torch.Tensor,
            down_weights: torch.Tensor,
            gate_up_bias: torch.Tensor = None,
            down_bias: torch.Tensor = None,
            expert_list: list[int] = None,
            act_func: Callable = None,
        ):
            if get_piecewise_graph_execution() is None:
                return self._forward_moe(hidden_states, topk_weights, topk_ids, gate_up_weights, down_weights,
                                         gate_up_bias, down_bias, expert_list, act_func)
            return run_eager_moe(hidden_states, topk_weights, topk_ids, gate_up_weights, down_weights, gate_up_bias,
                                 down_bias, expert_list, act_func)

        self._piecewise_forward = piecewise_forward

    def ep_expert_list(self, world_size: int, rank: int):
        """Experts list of current rank."""
        if get_dist_manager().current_context().dist_config.enable_eplb:
            raise NotImplementedError('float16/bfloat16 enable_eplb is not Implemented.')
        else:
            return super().ep_expert_list(world_size=world_size, rank=rank)

    def do_renormalize(self, topk_weights):
        return _renormalize(topk_weights, self.renormalize)

    def fusedmoe_build(self, low_latency_mode: bool = False):
        deepep_moe = _build_deepep_moe(low_latency_mode,
                                       self.ep_size,
                                       self.ep_group,
                                       self.num_experts,
                                       self.hidden_dim,
                                       self.top_k,
                                       layer_idx=self.layer_idx,
                                       out_dtype=self.out_dtype,
                                       num_max_dispatch_tokens_per_rank=self.num_max_dispatch_tokens_per_rank,
                                       fp32_acc=self.fp32_acc,
                                       output_scale=self.output_scale)
        return deepep_moe


def _build_fused_moe(spec: FusedMoEBuildSpec) -> FusedMoEImpl:
    """Build a CUDA fused MoE implementation."""
    if spec.ep_size > 1:
        return FusedMoEEPImpl(
            ep_size=spec.ep_size,
            ep_group=spec.ep_group,
            top_k=spec.top_k,
            num_experts=spec.num_experts,
            hidden_dim=spec.hidden_dim,
            renormalize=spec.renormalize,
            output_scale=spec.output_scale,
            fp32_acc=spec.fp32_acc,
            layer_idx=spec.layer_idx,
            out_dtype=spec.output_dtype,
            num_max_dispatch_tokens_per_rank=spec.num_max_dispatch_tokens_per_rank,
        )
    return TritonFusedMoEImpl(
        top_k=spec.top_k,
        num_experts=spec.num_experts,
        renormalize=spec.renormalize,
        output_scale=spec.output_scale,
        fp32_acc=spec.fp32_acc,
    )
