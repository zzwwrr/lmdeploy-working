# Copyright (c) OpenMMLab. All rights reserved.
from collections.abc import Callable, Hashable
from dataclasses import dataclass
from typing import Any

import torch

from lmdeploy.messages import QuantPolicy
from lmdeploy.pytorch.backends.attention import AttentionImpl, AttentionMetadata
from lmdeploy.pytorch.backends.cp_utils import DCPPrefixChunk, update_dcp_metadata
from lmdeploy.utils import get_logger

from ..step_metadata import CudaAttentionMetaBuilder, CudaSequenceMetadata, register_step_metadata_impl

logger = get_logger('lmdeploy')


@dataclass
class TritonAttentionMetadata(AttentionMetadata):
    """Triton attention metadata.

    This dataclass contains all metadata needed for attention computation
    across different stages (prefill/decoding) and implementations.

    Attributes:
        is_decoding: True for decoding stage, False for prefill.
        block_offsets: Block indices for paged KV cache [batch_size, max_blocks].
        q_start_loc: Start location of each query sequence [batch_size].
        q_seqlens: Length of each query sequence [batch_size].
        kv_start_loc: Start location of each KV sequence [batch_size].
        kv_seqlens: Length of each KV sequence [batch_size].
        quant_policy: Quantization policy (0=none, 4=int4, 8=int8, 16/17=per-tensor fp8).
        kv_flatten_size: Total size of flattened KV cache.
        tile_scheduler_metadata: Scheduler metadata for Flash MLA.
        num_splits: Number of splits for Flash MLA.
        cu_seqlens_q: Cumulative query sequence lengths [batch_size + 1].
        cu_seqlens_k: Cumulative KV sequence lengths [batch_size + 1].
        scheduler_metadata: Scheduler metadata for FA3.
        max_kv_seqlen: Maximum KV sequence length in the batch.
        max_q_seqlen: Maximum query sequence length in the batch.
        dcp_local_kv_seqlens: Rank-local KV sequence lengths under DCP.
        dcp_prefill_request_ids: Request index per query row for mapping top-k indices into packed prefill KV.
    """
    is_decoding: bool
    block_offsets: torch.Tensor
    q_start_loc: torch.Tensor = None
    q_seqlens: torch.Tensor = None
    kv_start_loc: torch.Tensor = None
    kv_seqlens: torch.Tensor = None
    quant_policy: QuantPolicy = QuantPolicy.NONE
    kv_flatten_size: int = None
    # flash mla
    tile_scheduler_metadata: torch.Tensor = None
    num_splits: torch.Tensor = None
    cu_seqlens_q: torch.Tensor = None
    cu_seqlens_k: torch.Tensor = None
    # flash attn
    scheduler_metadata: torch.Tensor = None
    max_kv_seqlen: int = None
    max_q_seqlen: int = None
    dcp_local_kv_seqlens: torch.Tensor = None
    dcp_prefix_chunks: tuple[DCPPrefixChunk, ...] = ()
    dcp_prefill_request_ids: torch.Tensor = None
    kernel_metadata: tuple[Any, ...] = ()


def build_triton_attention_metadata(attn_meta_cls, step_context,
                                    sequence_metadata: CudaSequenceMetadata) -> TritonAttentionMetadata:
    """Project CUDA sequence layout into compatible attention metadata."""
    attn_metadata = attn_meta_cls(
        is_decoding=step_context.is_decoding,
        block_offsets=sequence_metadata.block_offsets,
        q_start_loc=sequence_metadata.q_start_loc,
        q_seqlens=sequence_metadata.q_seqlens,
        kv_start_loc=sequence_metadata.kv_start_loc,
        kv_seqlens=sequence_metadata.kv_seqlens,
        kv_flatten_size=sequence_metadata.kv_flatten_size,
        quant_policy=step_context.kv_quant_policy,
        cu_seqlens_q=sequence_metadata.cu_seqlens_q,
        cu_seqlens_k=sequence_metadata.cu_seqlens_k,
        max_kv_seqlen=sequence_metadata.max_kv_seqlen,
        max_q_seqlen=step_context.max_q_seqlen,
    )
    update_dcp_metadata(attn_metadata, step_context)
    return attn_metadata


def _cdiv(a, b):
    """Perform ceiling division (division rounded up).

    Args:
        a: Dividend.
        b: Divisor.

    Returns:
        Ceiling of a / b.
    """
    return (a + b - 1) // b


@dataclass(frozen=True)
class TritonAttentionMetaBuilder(CudaAttentionMetaBuilder[None, None]):
    """Describe the default attention implementation's common-only metadata."""

    @property
    def key(self) -> Hashable:
        return type(self)

    def build(self, step_context, sequence_metadata) -> None:
        return None

    def apply_legacy_metadata(self, attn_metadata, metadata: None) -> None:
        pass

    def make_cudagraph_buffer(self, graph_meta, input_buffers, step_context) -> None:
        return None

    def fill_cudagraph_buffer(self, graph_meta, input_buffers, step_context,
                              buffer: None) -> None:
        return None


class TritonAttentionImpl(AttentionImpl[TritonAttentionMetadata]):
    """Triton attention implementation."""

    def __init__(
        self,
        num_heads: int,
        head_size: int,
        scale: float = None,
        num_kv_heads: int = None,
        v_head_size: int = None,
        alibi: bool = False,
        sliding_window: tuple[int, int] | None = None,
        logit_softcapping: float = 0.0,
        causal: bool = True,
        block_sparse_size: int = 1,
        **kwargs,
    ):
        super().__init__(
            num_heads=num_heads,
            head_size=head_size,
            scale=scale,
            num_kv_heads=num_kv_heads,
            v_head_size=v_head_size,
            alibi=alibi,
            sliding_window=sliding_window,
            logit_softcapping=logit_softcapping,
            causal=causal,
            **kwargs,
        )
        self.logit_softcapping = -1 if self.logit_softcapping <= 0.0 else self.logit_softcapping
        assert not (alibi and not causal)

        from lmdeploy.pytorch.kernels.cuda import (
            fill_kv_cache,
            flash_attn_varlen_func,
            flash_attn_with_kvcache,
            flatten_kv_cache,
        )

        self.fill_kv_cache = fill_kv_cache
        self.paged_attention_fwd = flash_attn_with_kvcache
        self.flatten_kv_cache = flatten_kv_cache
        self.flash_attention_fwd = flash_attn_varlen_func

        self.block_sparse_size = block_sparse_size
        self._step_meta_group: int | None = None
        from lmdeploy.pytorch.distributed import get_dcp_world_rank
        self.dcp_world_size, self.dcp_rank = get_dcp_world_rank()
        self._piecewise_forward: Callable[..., torch.Tensor] | None = None

        register_step_metadata_impl(self)

    def enable_piecewise_cuda_graph(self) -> None:
        """Run this CUDA attention implementation as a PCG eager boundary."""
        if self._piecewise_forward is not None:
            return

        from lmdeploy.pytorch.backends.cuda.graph_runner.piecewise import (
            PaddedTensorOutputAdapter,
            eager_boundary,
            get_piecewise_graph_execution,
        )

        original_forward = self.forward

        @eager_boundary(
            adapter_factory=PaddedTensorOutputAdapter,
            reuse_bridge_after_next_step=True,
        )
        def run_eager_attention(query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, k_cache: torch.Tensor,
                                v_cache: torch.Tensor, attn_metadata: TritonAttentionMetadata,
                                **kwargs) -> torch.Tensor:
            execution = get_piecewise_graph_execution()
            assert execution is not None
            raw_tokens = execution.raw_tokens
            query = query[:raw_tokens]
            key = key[:raw_tokens]
            value = value[:raw_tokens]

            output = original_forward(query, key, value, k_cache, v_cache, attn_metadata, **kwargs)
            # Speculative decode returns [batch, query_len, heads, dim], while
            # prefill and the following captured projection use flat tokens.
            if output.ndim == 4:
                output = output.flatten(0, 1)
            return output

        def piecewise_forward(query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, k_cache: torch.Tensor,
                              v_cache: torch.Tensor, attn_metadata: TritonAttentionMetadata,
                              **kwargs) -> torch.Tensor:
            if get_piecewise_graph_execution() is None:
                return original_forward(query, key, value, k_cache, v_cache, attn_metadata, **kwargs)

            return run_eager_attention(query, key, value, k_cache, v_cache, attn_metadata, **kwargs)

        self._piecewise_forward = piecewise_forward
        self.forward = piecewise_forward

    def supports_piecewise_cuda_graph(self) -> bool:
        """Return whether this selected implementation supports PCG."""
        return type(self) is TritonAttentionImpl

    def get_step_metadata_provider(self):
        """Describe metadata required by this selected implementation."""
        # Unknown subclasses keep the legacy model-config-driven path unless
        # they explicitly provide their own metadata contract.
        if type(self) is not TritonAttentionImpl:
            return None

        return TritonAttentionMetaBuilder()

    def bind_step_meta_group(self, group_id: int) -> None:
        """Bind this implementation to its deduplicated metadata group."""
        self._step_meta_group = group_id

    def get_step_kernel_metadata(self, attn_metadata: TritonAttentionMetadata) -> Any | None:
        """Return group-specific metadata when a model uses multiple groups."""
        kernel_metadata = attn_metadata.kernel_metadata
        group_id = self._step_meta_group
        if len(kernel_metadata) <= 1 or group_id is None:
            return None
        return kernel_metadata[group_id]

    def _get_max_q_seqlen(
        self,
        query: torch.Tensor,
        attn_metadata: TritonAttentionMetadata,
    ) -> int:
        """Get max q seqlen."""
        if attn_metadata.is_decoding:
            max_q_seqlen = self.block_sparse_size
        else:
            if attn_metadata.max_q_seqlen is not None:
                max_q_seqlen = attn_metadata.max_q_seqlen
            else:
                max_q_seqlen = query.numel() // (query.size(-1) * query.size(-2))
        return max_q_seqlen

    def _get_fill_meta(
        self,
        key: torch.Tensor,
        attn_metadata: TritonAttentionMetadata,
        max_q_seqlen: int,
    ):
        """Get fill meta."""
        fill_seqlens = attn_metadata.q_seqlens
        fill_max_q_seqlen = max_q_seqlen
        fill_q_start_loc = attn_metadata.q_start_loc
        return fill_seqlens, fill_max_q_seqlen, fill_q_start_loc

    def _fill_kv_cache_impl(
        self,
        key: torch.Tensor,
        value: torch.Tensor,
        k_cache: torch.Tensor,
        v_cache: torch.Tensor,
        attn_metadata: TritonAttentionMetadata,
        max_q_seqlen: int,
        k_scales_zeros: torch.Tensor = None,
        v_scales_zeros: torch.Tensor = None,
    ):
        """Fill kv cache."""
        kv_seqlens = attn_metadata.kv_seqlens
        block_offsets = attn_metadata.block_offsets
        quant_policy = attn_metadata.quant_policy

        # fill seqlen args
        fill_seqlens, fill_max_q_seqlen, fill_q_start_loc = self._get_fill_meta(
            key,
            attn_metadata,
            max_q_seqlen,
        )

        # fill kv cache
        self.fill_kv_cache(
            key,
            value,
            k_cache,
            v_cache,
            fill_q_start_loc,
            fill_seqlens,
            kv_seq_length=kv_seqlens,
            max_q_seq_length=fill_max_q_seqlen,
            block_offsets=block_offsets,
            k_scales_zeros=k_scales_zeros,
            v_scales_zeros=v_scales_zeros,
            quant_policy=quant_policy,
            dcp_size=self.dcp_world_size,
            dcp_rank=self.dcp_rank,
        )

    def _forward_decoding(
        self,
        query: torch.Tensor,
        k_cache: torch.Tensor,
        v_cache: torch.Tensor,
        attn_metadata: TritonAttentionMetadata,
        max_q_seqlen: int,
        k_scales_zeros: torch.Tensor = None,
        v_scales_zeros: torch.Tensor = None,
        learnable_sink: torch.Tensor = None,
    ) -> torch.Tensor:
        """Forward pass for decoding stage.

        Args:
            query: Query tensor.
            k_cache: Key cache tensor.
            v_cache: Value cache tensor.
            attn_metadata: Attention metadata.
            max_q_seqlen: Maximum query sequence length.
            k_scales_zeros: Key quantization scales/zeros.
            v_scales_zeros: Value quantization scales/zeros.
            learnable_sink: Learnable sink tokens.

        Returns:
            Attention output tensor.
        """
        block_offsets = attn_metadata.block_offsets
        quant_policy = attn_metadata.quant_policy

        attn_output = self.paged_attention_fwd(
            query,
            k_cache,
            v_cache,
            cache_seqlens=attn_metadata.kv_seqlens,
            page_table=block_offsets,
            cu_seqlens_q=attn_metadata.cu_seqlens_q,
            max_seqlen_q=max_q_seqlen,
            softmax_scale=self.scale,
            softcap=self.logit_softcapping,
            window_size=self.sliding_window,
            # custom args
            sinks=learnable_sink,
            alibi_slopes=self.alibi_slopes,
            quant_policy=quant_policy,
            k_scales_zeros=k_scales_zeros,
            v_scales_zeros=v_scales_zeros,
        )
        return attn_output

    def _forward_prefill(
        self,
        query: torch.Tensor,
        k_cache: torch.Tensor,
        v_cache: torch.Tensor,
        attn_metadata: TritonAttentionMetadata,
        max_q_seqlen: int,
        k_scales_zeros: torch.Tensor = None,
        v_scales_zeros: torch.Tensor = None,
        learnable_sink: torch.Tensor = None,
    ) -> torch.Tensor:
        """Forward pass for prefill stage.

        Args:
            query: Query tensor.
            k_cache: Key cache tensor.
            v_cache: Value cache tensor.
            attn_metadata: Attention metadata.
            max_q_seqlen: Maximum query sequence length.
            k_scales_zeros: Key quantization scales/zeros.
            v_scales_zeros: Value quantization scales/zeros.
            learnable_sink: Learnable sink tokens.

        Returns:
            Attention output tensor.
        """
        block_offsets = attn_metadata.block_offsets
        kv_start_loc = attn_metadata.kv_start_loc
        kv_seqlens = attn_metadata.kv_seqlens
        kv_flatten_size = attn_metadata.kv_flatten_size
        quant_policy = attn_metadata.quant_policy

        # Prepare flattened KV cache
        BLOCK_BS = k_cache.size(1)
        # pad one more block to avoid invalid kv visit
        out_size = (_cdiv(kv_flatten_size, BLOCK_BS) * BLOCK_BS + BLOCK_BS)
        kv_layout = 'hsd'  # custom triton kernel requires 'hsd' while fa3 requires 'shd'

        flatten_k, flatten_v = self.flatten_kv_cache(
            k_cache,
            v_cache,
            kv_seqlens,
            block_offsets,
            start_loc=kv_start_loc,
            out_size=out_size,
            out_dtype=query.dtype,
            k_scales_zeros=k_scales_zeros,
            v_scales_zeros=v_scales_zeros,
            quant_policy=quant_policy,
            flatten_kv_layout=kv_layout,
        )

        # For quant_policy==QuantPolicy.TURBO_QUANT, flattened K/V are in rotated domain.
        # Rotate Q to match, and inverse-rotate output afterwards.
        if quant_policy == QuantPolicy.TURBO_QUANT:
            from lmdeploy.pytorch.kernels.cuda.turbo_quant import (
                hadamard_rotate,
                hadamard_rotate_inv,
            )
            query = hadamard_rotate(query)

        attn_output = self.flash_attention_fwd(
            query,
            flatten_k,
            flatten_v,
            cu_seqlens_q=attn_metadata.cu_seqlens_q,
            cu_seqlens_k=attn_metadata.cu_seqlens_k,
            max_seqlen_q=max_q_seqlen,
            max_seqlen_k=attn_metadata.max_kv_seqlen,
            window_size=self.sliding_window,
            softmax_scale=self.scale,
            softcap=self.logit_softcapping,
            causal=self.causal,
            # custom args
            sinks=learnable_sink,
            alibi_slopes=self.alibi_slopes,
            block_sparse_size=self.block_sparse_size,
            kv_layout=kv_layout,
        )

        # Inverse-rotate output back to original domain
        if quant_policy == QuantPolicy.TURBO_QUANT:
            attn_output = hadamard_rotate_inv(attn_output)

        return attn_output

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        k_cache: torch.Tensor,
        v_cache: torch.Tensor,
        attn_metadata: TritonAttentionMetadata,
        k_scales_zeros: torch.Tensor = None,
        v_scales_zeros: torch.Tensor = None,
        learnable_sink: torch.Tensor = None,
        inplace: bool = True,
        **kwargs,
    ) -> torch.Tensor:
        """Forward pass for attention computation.

        This method handles both prefill and decoding stages by:
        1. Computing max query sequence length
        2. Filling KV cache if new key/value are provided
        3. Dispatching to appropriate stage-specific method

        Args:
            query: Query tensor.
            key: Key tensor (None for decoding-only).
            value: Value tensor (None for decoding-only).
            k_cache: Key cache tensor.
            v_cache: Value cache tensor.
            attn_metadata: Attention metadata containing stage info and indices.
            k_scales_zeros: Key quantization scales/zeros.
            v_scales_zeros: Value quantization scales/zeros.
            learnable_sink: Learnable sink tokens.
            inplace: Whether to modify query inplace (unused, kept for compatibility).

        Returns:
            Attention output tensor.
        """
        # Shared preparation
        max_q_seqlen = self._get_max_q_seqlen(query, attn_metadata)

        # Fill KV cache with new key/value if provided
        if key is not None and value is not None:
            self._fill_kv_cache_impl(
                key,
                value,
                k_cache=k_cache,
                v_cache=v_cache,
                attn_metadata=attn_metadata,
                max_q_seqlen=max_q_seqlen,
                k_scales_zeros=k_scales_zeros,
                v_scales_zeros=v_scales_zeros,
            )

        # Validate alibi configuration
        if self.alibi:
            assert self.alibi_slopes is not None, 'alibi_slopes is not set.'

        # Dispatch to stage-specific forward method
        if attn_metadata.is_decoding:
            return self._forward_decoding(
                query,
                k_cache,
                v_cache,
                attn_metadata,
                max_q_seqlen,
                k_scales_zeros=k_scales_zeros,
                v_scales_zeros=v_scales_zeros,
                learnable_sink=learnable_sink,
            )
        else:
            return self._forward_prefill(
                query,
                k_cache,
                v_cache,
                attn_metadata,
                max_q_seqlen,
                k_scales_zeros=k_scales_zeros,
                v_scales_zeros=v_scales_zeros,
                learnable_sink=learnable_sink,
            )
