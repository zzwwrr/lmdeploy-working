# Copyright (c) OpenMMLab. All rights reserved.
from abc import ABC, abstractmethod
from dataclasses import dataclass

import torch
import torch.distributed as dist

from .base import BuildSpec


class LinearImpl(ABC):
    """Linear implementation api."""

    supports_batched = False

    def forward_batched(self, x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
        """Apply independent local projections with weights [batch, out,
        in]."""
        raise NotImplementedError

    def update_weights(self, weight: torch.Tensor, bias: torch.Tensor | None = None):
        """Update weights."""
        return weight, bias

    def get_unquantized_weight(self, weight: torch.Tensor):
        """Return weight in ``[out_features, in_features]`` layout."""
        return weight

    @abstractmethod
    def forward(self,
                x,
                weight: torch.Tensor,
                bias: torch.Tensor | None = None,
                all_reduce: bool = False,
                group: dist.ProcessGroup = None,
                rank: int = 0,
                scatter_size: list[int] = None):
        """forward."""
        raise NotImplementedError


@dataclass(frozen=True)
class LinearBuildSpec(BuildSpec[LinearImpl]):
    """Immutable requirements for constructing an unquantized linear op."""

    in_features: int
    out_features: int
    bias: bool
    dtype: torch.dtype | None
