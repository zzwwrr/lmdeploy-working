# Copyright (c) OpenMMLab. All rights reserved.
import os

import torch
import torch.distributed as dist

from lmdeploy.pytorch.kernels.dlinfer import linear

from ..linear import LinearImpl


class DlinferLinearImpl(LinearImpl):
    """Dlinfer linear implementation api."""

    def update_weights(self, weight: torch.Tensor, bias: torch.Tensor | None = None):
        """Update weights."""
        if os.getenv('DLINFER_LINEAR_USE_NN_LAYOUT', '0') == '1':
            weight = weight.data.t().contiguous()
        return weight, bias

    def get_unquantized_weight(self, weight: torch.Tensor):
        """Return weight in ``[out_features, in_features]`` layout."""
        if os.getenv('DLINFER_LINEAR_USE_NN_LAYOUT', '0') == '1':
            weight = weight.t()
        return weight

    def forward(self,
                x,
                weight: torch.Tensor,
                bias: torch.Tensor | None = None,
                all_reduce: bool = False,
                group: dist.ProcessGroup = None,
                rank: int = 0,
                scatter_size: list[int] = None):
        """forward."""
        out = linear(x, weight, bias, False)
        if all_reduce:
            dist.all_reduce(out, group=group)
        return out
