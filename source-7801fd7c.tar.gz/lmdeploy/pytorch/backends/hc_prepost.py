# Copyright (c) OpenMMLab. All rights reserved.
from abc import ABC, abstractmethod
from dataclasses import dataclass

import torch

from .base import BuildSpec


class HCPrePostImpl(ABC):
    """Backend interface for DeepSeek-V4 hyper-connection reductions."""

    def prepare_projection_weight(self, weight: torch.Tensor) -> torch.Tensor | None:
        """Prepare an optional projection layout after loading model
        weights."""
        return None

    def try_project_mixes(self, x_fp32: torch.Tensor, weight: torch.Tensor) -> torch.Tensor | None:
        """Project with a prepared backend layout, or use the ordinary
        linear."""
        return None

    def try_scale_mixes(self, mixes: torch.Tensor, x_fp32: torch.Tensor, eps: float) -> torch.Tensor | None:
        """Optionally fuse projection scaling; return None for the existing RMS
        path."""
        return None

    @abstractmethod
    def pre(
        self,
        x: torch.Tensor,
        mixes: torch.Tensor,
        hc_scale: torch.Tensor,
        hc_base: torch.Tensor,
        out_dtype: torch.dtype,
        norm_weight: torch.Tensor | None = None,
        norm_eps: float = 1e-6,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Run sinkhorn and reduce HC states from ``[..., hc, dim]`` to ``[...,
        dim]``, optionally followed by RMSNorm after the output-dtype cast."""
        raise NotImplementedError

    @abstractmethod
    def pre_reduce(self, x: torch.Tensor, pre: torch.Tensor, out_dtype: torch.dtype) -> torch.Tensor:
        """Reduce HC hidden states from ``[..., hc, dim]`` to ``[...,
        dim]``."""
        raise NotImplementedError

    @abstractmethod
    def post_expand(self, x: torch.Tensor, residual: torch.Tensor, post: torch.Tensor,
                    comb: torch.Tensor) -> torch.Tensor:
        """Expand one hidden state back to ``[..., hc, dim]``."""
        raise NotImplementedError

    def post_expand_with_fp32(self, x: torch.Tensor, residual: torch.Tensor, post: torch.Tensor,
                              comb: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Also prepare the rounded output for the next FP32 HC projection."""
        out = self.post_expand(x, residual, post, comb)
        return out, out.float()


@dataclass(frozen=True)
class HCPrePostBuildSpec(BuildSpec[HCPrePostImpl]):
    """Immutable requirements for DeepSeek-V4 hyper-connection kernels."""

    hc_mult: int
    sinkhorn_iters: int
    eps: float
