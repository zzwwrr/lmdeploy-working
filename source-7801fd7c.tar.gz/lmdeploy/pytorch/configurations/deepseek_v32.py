# Copyright (c) OpenMMLab. All rights reserved.

from lmdeploy.pytorch import envs as _envs

from .deepseek_v2 import DeepseekV2ModelConfigBuilder


def _check_env_v32(device: str = 'cuda'):
    """Environment check."""
    if device != 'cuda':
        return

    if _envs.disable_dsa_indexer_fusion:
        try:
            import fast_hadamard_transform  # noqa: F401
        except ImportError:
            raise ImportError('Deepseek V3.2 requires <fast_hadamard_transform> when indexer fusion is disabled.')

    try:
        import flash_mla  # noqa: F401
    except ImportError:
        raise ImportError('Deepseek V3.2 requires <flash_mla>.')

    if not hasattr(flash_mla, 'flash_mla_sparse_fwd'):
        raise RuntimeError('Latest flash_mla is required: https://github.com/deepseek-ai/FlashMLA.')


class DeepseekV32ModelConfigBuilder(DeepseekV2ModelConfigBuilder):

    @classmethod
    def condition(cls, hf_config):
        """config."""
        return hf_config.model_type == 'deepseek_v32'

    @classmethod
    def build(cls, hf_config, model_path: str | None = None, **kwargs):
        """build."""
        is_draft_model = kwargs.get('is_draft_model', False)
        config = DeepseekV2ModelConfigBuilder.build(hf_config, model_path=model_path, **kwargs)

        assert hf_config.use_flash_mla, 'DeepSeek-V3.2 requires flash_mla to be available.'
        config.mla_kv_cache_dtype = 'bfloat16'
        config.mla_index_topk = hf_config.index_topk
        config.check_env_func = _check_env_v32
        if is_draft_model:
            hf_config.architectures[0] = 'DeepseekV32MTPModel'
        return config
