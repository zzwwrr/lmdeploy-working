# Copyright (c) OpenMMLab. All rights reserved.
from typing import Literal

from .messages import PytorchEngineConfig, TurbomindEngineConfig
from .utils import get_logger

logger = get_logger('lmdeploy')


def autoget_backend(model_path: str, trust_remote_code: bool = False):
    """Get backend type in auto backend mode.

    Args:
         model_path (str): the path of a model.
            It could be one of the following options:
                - i) A local directory path of a turbomind model which is
                    converted by `lmdeploy convert` command or download from
                    ii) and iii).
                - ii) The model_id of a lmdeploy-quantized model hosted
                    inside a model repo on huggingface.co, such as
                    "lmdeploy/llama2-chat-70b-4bit", etc.
                - iii) The model_id of a model hosted inside a model repo
                    on huggingface.co, such as "internlm/internlm2-chat-7b",
                    "Qwen/Qwen2.5-7B-Instruct"
                    and so on.

    Returns:
        str: the backend type.
    """

    from lmdeploy import turbomind

    turbomind_has = False
    if turbomind.is_available():
        from lmdeploy.turbomind.supported_models import is_supported as is_supported_turbomind
        turbomind_has = is_supported_turbomind(model_path, trust_remote_code=trust_remote_code)
        if not turbomind_has:
            logger.warning(f'Fallback to pytorch engine because {model_path!r} not supported by turbomind engine.')
    else:
        logger.warning('Fallback to pytorch engine because turbomind is not built.')

    return 'turbomind' if turbomind_has else 'pytorch'


def autoget_backend_config(
    model_path: str,
    backend_config: PytorchEngineConfig | TurbomindEngineConfig | None = None,
    trust_remote_code: bool = False
) -> tuple[Literal['turbomind', 'pytorch'], PytorchEngineConfig | TurbomindEngineConfig]:
    """Get backend config automatically.

    Args:
        model_path (str): The input model path.
        backend_config (TurbomindEngineConfig | PytorchEngineConfig): The
            input backend config. Default to None.

    Returns:
        (PytorchEngineConfig | TurbomindEngineConfig): The auto-determined
            backend engine config.
    """
    from dataclasses import asdict

    if isinstance(backend_config, PytorchEngineConfig):
        return 'pytorch', backend_config

    backend = autoget_backend(model_path, trust_remote_code=trust_remote_code)
    config = PytorchEngineConfig() if backend == 'pytorch' else TurbomindEngineConfig()
    if backend_config is not None:
        if type(backend_config) is type(config):
            config = backend_config
        else:
            data = asdict(backend_config)
            for k, v in data.items():
                if v and hasattr(config, k):
                    setattr(config, k, v)
            # map attributes with different names
            if type(backend_config) is TurbomindEngineConfig:
                config.block_size = backend_config.cache_block_seq_len
            else:
                config.cache_block_seq_len = backend_config.block_size
    return backend, config


def check_vl_llm(backend: str, config: dict) -> bool:
    """Check if the model is a vl model from model config."""
    if 'language_config' in config and 'vision_config' in config and config['language_config'].get(
            'architectures', [None])[0] == 'DeepseekV2ForCausalLM':
        return True

    arch = config['architectures'][0]
    supported_archs = set([
        'LlavaLlamaForCausalLM', 'LlavaMistralForCausalLM', 'CogVLMForCausalLM', 'InternVLChatModel', 'MiniCPMV',
        'LlavaForConditionalGeneration', 'LlavaNextForConditionalGeneration', 'Phi3VForCausalLM',
        'Qwen2VLForConditionalGeneration', 'Qwen2_5_VLForConditionalGeneration', 'Qwen3VLForConditionalGeneration',
        'Qwen3VLMoeForConditionalGeneration', 'Qwen3_5ForConditionalGeneration',
        'Qwen3_5MoeForConditionalGeneration', 'Qwen3OmniMoeForConditionalGeneration', 'MolmoForCausalLM',
        'Gemma3ForConditionalGeneration', 'Llama4ForConditionalGeneration', 'InternVLForConditionalGeneration',
        'InternS1ForConditionalGeneration', 'InternS1ProForConditionalGeneration',
        'InternS1_1_ForConditionalGeneration', 'Glm4vForConditionalGeneration',
        'Glm5NextForConditionalGeneration',
        'InternS2MobiusForConditionalGeneration', 'InternS2MobiusForCausalLM',
        'InternS2PreviewForConditionalGeneration', 'InternS2PreviewForCausalLM',
        'KimiK25ForConditionalGeneration', 'Kimi_K25ForConditionalGeneration',
    ])
    turbomind_unsupported_archs = []
    if arch == 'MultiModalityCausalLM' and 'language_config' in config:
        return True
    elif arch in ['ChatGLMModel', 'ChatGLMForConditionalGeneration'] and 'vision_config' in config:
        return True
    elif arch in turbomind_unsupported_archs and backend == 'turbomind':
        return False
    elif arch in supported_archs:
        return True
    return False


def get_task(backend: str,
             model_path: str,
             trust_remote_code: bool = False,
             backend_config: PytorchEngineConfig | TurbomindEngineConfig | None = None):
    """Get pipeline type and pipeline class from model config."""
    from lmdeploy.serve.core import AsyncEngine

    if backend_config and backend_config.language_model_only:
        return 'llm', AsyncEngine
    _, config = get_model_arch(model_path, trust_remote_code=trust_remote_code)
    if check_vl_llm(backend, config.to_dict()):
        from lmdeploy.serve.core import VLAsyncEngine
        return 'vlm', VLAsyncEngine

    # default task, pipeline_class
    return 'llm', AsyncEngine


def get_model_arch(model_path: str, trust_remote_code: bool = False):
    """Get a model's architecture and configuration.

    Args:
        model_path(str): the model path
    """
    from lmdeploy.hf_configs import config_from_pretrained

    cfg = config_from_pretrained(model_path, trust_remote_code=trust_remote_code)

    _cfg = cfg.to_dict()
    if _cfg.get('architectures', None):
        arch = _cfg['architectures'][0]
    elif _cfg.get('auto_map', None) and 'AutoModelForCausalLM' in _cfg['auto_map']:
        arch = _cfg['auto_map']['AutoModelForCausalLM'].split('.')[-1]
    elif _cfg.get('language_config', None) and _cfg['language_config'].get(
            'auto_map', None) and 'AutoModelForCausalLM' in _cfg['language_config']['auto_map']:
        arch = _cfg['language_config']['auto_map']['AutoModelForCausalLM'].split('.')[-1]
    else:
        raise RuntimeError(f'Could not find model architecture from config: {_cfg}')
    return arch, cfg


def search_nested_config(config, key):
    """Recursively searches for the value associated with the given key in a
    nested configuration of a model."""
    if isinstance(config, dict):
        for k, v in config.items():
            if k == key:
                return v
            if isinstance(v, (dict, list)):
                result = search_nested_config(v, key)
                if result is not None:
                    return result
    elif isinstance(config, list):
        for item in config:
            result = search_nested_config(item, key)
            if result is not None:
                return result
    return None
