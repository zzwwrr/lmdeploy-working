"""Validate raw HTTP responses and independently inspect Poisson delivery."""
import collections
import hashlib
import json
import math
from pathlib import Path
import random

import numpy as np

ROOT = Path(__file__).resolve().parent


def write(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def distribution(values):
    if not values:
        return dict(n=0, mean=None, p50=None, p95=None, p99=None, minimum=None, maximum=None)
    return dict(n=len(values), mean=float(np.mean(values)), p50=float(np.percentile(values, 50)),
                p95=float(np.percentile(values, 95)), p99=float(np.percentile(values, 99)),
                minimum=min(values), maximum=max(values))


def validate(row, body):
    assert body['model'] == 'Intern-Decision-4B'
    questions = row['payloads']['openai']['questions']
    answers = body['answers']
    assert [a['name'] for a in answers] == [q['name'] for q in questions]
    for question, answer in zip(questions, answers, strict=True):
        assert question['type'] == answer['type']
        if answer['type'] == 'predicate':
            values = [answer['probability'], 1 - answer['probability']]
        else:
            values = [p['probability'] for p in answer['probabilities']]
            candidates = [v['value'] for v in question['choices']]
            assert [p['value'] for p in answer['probabilities']] == candidates
            assert answer['choice'] in candidates
            assert abs(answer['confidence'] - max(values)) < 1e-5
            assert answer['probabilities'][candidates.index(answer['choice'])]['probability'] >= max(values) - 1e-7
        assert all(math.isfinite(v) and 0 <= v <= 1 for v in values)
        assert abs(sum(values) - 1) < 1e-5
    usage = body['usage']
    assert usage['input_tokens'] in (row['full_input_tokens'], row['full_input_tokens'] - 2)
    assert usage['output_tokens'] > 0
    assert usage['total_tokens'] == usage['input_tokens'] + usage['output_tokens']
    assert usage['output_tokens_details']['reasoning_tokens'] == 0
    cached = usage['input_tokens_details']['cached_tokens']
    assert 0 <= cached <= usage['input_tokens']
    return usage


def analyze(path, meta):
    rows = {r['id']: r for r in map(json.loads, (ROOT / 'data/records.jsonl').open())}
    phase = next(p for p in json.loads((path / 'phase_manifest.json').read_text())['phases']
                 if p['phase_kind'] == 'profiling')
    start = phase['start_ns']
    duration = (phase['end_ns'] - start) / 1e9
    bin_seconds = 1 if meta['seconds'] < 30 else 5
    bin_ns = bin_seconds * 1_000_000_000
    counters = [json.loads(p.read_text()) for p in (path / 'scheduler').glob('phase-*.json')]
    counter = next(c for c in counters if c['phase'] == 'profiling')
    state = counter['rng_state_before']
    rng = random.Random()
    rng.setstate((state[0], tuple(state[1]), state[2]))
    plans, elapsed = [], 0.
    while True:
        elapsed += rng.expovariate(meta['rate'])
        if elapsed > meta['seconds']:
            break
        plans.append(counter['phase_start_ns'] + int(elapsed * 1e9))
    records, latency, credits, dispatch, arrival, errors = [], [], [], [], [], collections.Counter()
    bins = collections.defaultdict(lambda: dict(sent=0, ended=0, valid=0, latency=[]))
    input_tokens = cached_tokens = fields = good_1s = completed_window = 0
    with (path / 'profile_export_raw.jsonl').open() as stream:
        for line in stream:
            item = json.loads(line)
            md = item['metadata']
            if md.get('phase_kind', md.get('benchmark_phase')) != 'profiling':
                continue
            row = rows[md['conversation_id']]
            assert item['payload'] == row['payloads']['openai']
            begin = md['request_start_ns']
            end = md.get('request_end_ns', begin)
            credits.append(md['credit_issued_ns'])
            dispatch.append((begin - md['credit_issued_ns']) / 1e6)
            arrival.append((begin - start) / 1e9)
            bins[int((begin - start) // bin_ns)]['sent'] += 1
            finish_bin = bins[int((end - start) // bin_ns)]
            finish_bin['ended'] += 1
            record = dict(id=row['id'], fields=row['m'], start_ns=begin, end_ns=end, status=item.get('status'))
            try:
                assert item.get('status') == 200, f"HTTP {item.get('status')}: {str(item.get('error'))[:120]}"
                body = json.loads(item['responses'][-1]['text'])
                usage = validate(row, body)
                value = (item['responses'][-1]['perf_ns'] - item['start_perf_ns']) / 1e6
                latency.append(value)
                record.update(valid=True, latency_ms=value)
                input_tokens += usage['input_tokens']
                cached_tokens += usage['input_tokens_details']['cached_tokens']
                fields += row['m']
                good_1s += value <= 1000
                finish_bin['valid'] += 1
                finish_bin['latency'].append(value)
                if end <= start + meta['seconds'] * 1e9:
                    completed_window += 1
            except Exception as exc:
                record.update(valid=False, error=f'{type(exc).__name__}: {exc}')
                errors[record['error']] += 1
            records.append(record)
    assert len(records) == phase['total_request_count']
    timeline, inflight = [], 0
    for i in range(max(bins) + 1):
        b = bins[i]
        inflight += b['sent'] - b['ended']
        timeline.append(dict(second=bin_seconds * i, inflight=inflight, sent=b['sent'], ended=b['ended'],
                             valid=b['valid'], latency_ms=distribution(b['latency'])))
    tail = [b for b in timeline if meta['seconds'] / 3 <= b['second'] < meta['seconds']]
    slope = float(np.polyfit([b['second'] for b in tail], [b['inflight'] for b in tail], 1)[0])
    skipped = sum(e['result'] == 'skipped' for e in counter['events'])
    issued = sum(e['result'] == 'issued' for e in counter['events'])
    # Export metadata uses epoch nanoseconds; scheduler observations use perf_counter_ns.
    # Compare the planned schedule with observations from the same monotonic clock.
    issued_times = [e['before_ns'] for e in counter['events'] if e['result'] == 'issued']
    plan_lag = [(actual - ideal) / 1e6 for actual, ideal in zip(issued_times, plans)]
    delivery_reasons = []
    if skipped or issued != len(records) or abs(len(records) - len(plans)) > max(3, len(plans) * .01):
        delivery_reasons.append('arrival_count_mismatch_or_skipped')
    if not dispatch or np.percentile(dispatch, 99) > 25:
        delivery_reasons.append('http_dispatch_p99_over_25ms')
    if not plan_lag or np.percentile(plan_lag, 99) > 25:
        delivery_reasons.append('poisson_schedule_p99_over_25ms')
    if plan_lag and min(plan_lag) < -25:
        delivery_reasons.append('poisson_schedule_early_over_25ms')
    stable_reasons = []
    if errors:
        stable_reasons.append('invalid_or_failed_responses')
    if slope > max(.1, meta['rate'] * .002):
        stable_reasons.append('growing_backlog')
    if completed_window / max(1, len(records)) < .97:
        stable_reasons.append('completion_rate_below_arrival_rate')
    active = peak = 0
    events = [(r['start_ns'], 1) for r in records] + [(r['end_ns'], -1) for r in records]
    for _, delta in sorted(events):
        active += delta
        peak = max(peak, active)
    summary = dict(**meta, requests=len(records), valid=len(latency), invalid=len(records) - len(latency),
                   actual_send_rps=len(records) / meta['seconds'], completed_in_window_rps=completed_window / meta['seconds'],
                   successful_rps_with_drain=len(latency) / duration, phase_seconds_with_drain=duration,
                   latency_ms=distribution(latency), errors=dict(errors), fields=fields,
                   cached_input_tokens=cached_tokens, input_tokens=input_tokens,
                   cache_token_fraction=cached_tokens / max(1, input_tokens),
                   goodput_1s_with_drain_rps=good_1s / duration,
                   slo_1s_attainment=good_1s / max(1, len(records)),
                   historical_latency_slo_observed=bool(bool(latency) and np.percentile(latency, 50) <= 500
                   and np.percentile(latency, 95) <= 1000 and not errors),
                   backlog_slope_per_second=slope, peak_inflight=peak,
                   poisson_planned_arrivals=len(plans), skipped_arrivals=skipped,
                   dispatch_lag_ms=distribution(dispatch), poisson_schedule_lag_ms=distribution(plan_lag),
                   delivery_valid=not delivery_reasons, delivery_reasons=delivery_reasons,
                   stable=not stable_reasons, stable_reasons=stable_reasons, timeline=timeline,
                   unique_inputs=len(set(r['id'] for r in records)),
                   raw_sha256=hashlib.sha256((path / 'profile_export_raw.jsonl').read_bytes()).hexdigest())
    write(path / 'verified-summary.json', summary)
    with (path / 'verified-requests.jsonl').open('w') as out:
        for record in records:
            out.write(json.dumps(record) + '\n')
    return summary
