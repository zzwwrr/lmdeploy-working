"""Export a compact local review bundle; keep full AIPerf raw files remotely."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
state = json.loads((ROOT / 'results/status.json').read_text())
assert state['complete'] and state['service_stopped'] and state['confirmed_interval_rps']
assert (ROOT / 'run.exit_code').read_text().strip() == '0'
assert (ROOT / 'refine.exit_code').read_text().strip() == '0'
assert state['quality']['requests'] == 10751 and state['quality']['fields'] == 12351
assert all(point['delivery_valid'] and point['invalid'] == 0 for point in state['points'])
manifest = json.loads((ROOT / 'source-manifest.json').read_text())
for line in manifest['production_git_tree']:
    metadata, name = line.split('\t', 1)
    data = (ROOT / 'source' / name).read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == metadata.split()[2]

stage = ROOT / 'review-bundle'
stage.mkdir(exist_ok=False)
compressed = []


def copy(path, target=None):
    relative = target or path.relative_to(ROOT)
    destination = stage / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, destination)


def zip_copy(path):
    relative = path.relative_to(ROOT)
    destination = stage / (str(relative) + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with path.open('rb') as source, destination.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as out:
            shutil.copyfileobj(source, out)
    original = hashlib.sha256(path.read_bytes()).hexdigest()
    with gzip.open(destination, 'rb') as stream:
        assert hashlib.sha256(stream.read()).hexdigest() == original
    compressed.append(dict(original=str(relative), exported=str(destination.relative_to(stage)), decoded_sha256=original))


for path in [*ROOT.glob('*.py'), *ROOT.glob('*.sh'), *ROOT.glob('config/*.py'), ROOT / 'source-manifest.json', ROOT / 'source-4446d416.tar.gz']:
    copy(path)
for path in (ROOT / 'data').glob('*'):
    if path.is_file():
        zip_copy(path)
for path in (ROOT / 'results').glob('*.json'):
    copy(path)
for path in (ROOT / 'results/analysis-before-jitter-guard').glob('*.json'):
    copy(path)
copy(ROOT / 'results/official-seven/summary.json')
zip_copy(ROOT / 'results/official-seven/responses.jsonl')
for path in (ROOT / 'results/official-seven/scored').glob('*.jsonl'):
    zip_copy(path)
raw_index = []
for point in state['points']:
    directory = ROOT / 'results' / point['name']
    for name in ('verified-summary.json', 'run-config.json', 'command.json', 'phase_manifest.json',
                 'profile_export_aiperf.json', 'metrics-before.json', 'metrics-after.json'):
        copy(directory / name)
    zip_copy(directory / 'verified-requests.jsonl')
    for path in (directory / 'scheduler').glob('*.json'):
        zip_copy(path)
    raw = directory / 'profile_export_raw.jsonl'
    assert hashlib.sha256(raw.read_bytes()).hexdigest() == point['raw_sha256']
    raw_index.append(dict(path=str(raw), bytes=raw.stat().st_size, sha256=point['raw_sha256']))

quality = state['quality']
summary = dict(source_commit=state['source_commit'], hardware='one H200, GPU 2',
               performance_api='/v1/decisions', quality_api='/v1/systemone',
               nominal_poisson_rate_bracket_rps=state['confirmed_interval_rps'],
               bracket_note='Configured Poisson means; actual finite-window arrival rates are reported separately.',
               points=[p for p in state['points'] if p['kind'] != 'client-preflight'], quality=quality,
               answer_agreement=json.loads((ROOT / 'results/historical-answer-comparison.json').read_text()),
               full_aiperf_raw_retained_remotely=raw_index,
               package_scope='Summaries, all verified request timings, full quality outputs, frozen inputs and source; full AIPerf payload/transport exports remain at the indexed remote paths.',
               method_adjustments=['Use the same monotonic clock for schedule comparisons.',
                                   'Use native bool for JSON export of NumPy SLO predicates.',
                                   'Allow symmetric 25ms scheduling tolerance; all observed p99 late dispatches are reported.',
                                   'Recheck isolated 60s backlog slopes at 120s before choosing a bracket.',
                                   'A failed 65 RPS long confirmation triggered two additional 120s bisection points.'],
               compressed_originals=compressed)
(stage / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
columns = ['target_rps', 'seconds', 'actual_send_rps', 'completed_in_window_rps', 'p50_ms', 'p95_ms',
           'errors', 'stable', 'backlog_slope_per_second', 'goodput_1s_rps', 'seed', 'name']
with (stage / 'capacity.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=columns)
    writer.writeheader()
    for p in summary['points']:
        writer.writerow(dict(target_rps=p['rate'], seconds=p['seconds'], actual_send_rps=p['actual_send_rps'],
                             completed_in_window_rps=p['completed_in_window_rps'], p50_ms=p['latency_ms']['p50'],
                             p95_ms=p['latency_ms']['p95'], errors=p['invalid'], stable=p['stable'],
                             backlog_slope_per_second=p['backlog_slope_per_second'],
                             goodput_1s_rps=p['goodput_1s_with_drain_rps'], seed=p['seed'], name=p['name']))
files = {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in stage.rglob('*') if p.is_file()}
(stage / 'manifest.json').write_text(json.dumps(files, indent=2) + '\n')
archive = ROOT / 'pr5075-h200-current-4446d416-summary.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(stage, arcname='pr5075-h200-current-4446d416')
with tarfile.open(archive) as tar:
    for name, digest in files.items():
        assert hashlib.sha256(tar.extractfile('pr5075-h200-current-4446d416/' + name).read()).hexdigest() == digest
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix(archive.suffix + '.sha256').write_text(digest + '  ' + archive.name + '\n')
(ROOT / 'results/final-gpu.txt').write_text(subprocess.check_output(['nvidia-smi'], text=True))
print(json.dumps(dict(archive=str(archive), bytes=archive.stat().st_size, sha256=digest,
                     files=len(files), nominal_interval=state['confirmed_interval_rps'])), flush=True)
