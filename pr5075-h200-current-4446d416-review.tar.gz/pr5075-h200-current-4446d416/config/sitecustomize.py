"""Observe AIPerf scheduling; remove the transport connection-pool ceiling."""
import os

if os.environ.get('DECISION_AIPERF_COUNTER_DIR'):
    import json
    from pathlib import Path
    import resource
    import time

    from aiperf.transports.http_defaults import AioHttpDefaults
    from aiperf.timing.strategies.request_rate import RequestRateStrategy

    target = Path(os.environ['DECISION_AIPERF_COUNTER_DIR'])
    target.mkdir(parents=True, exist_ok=True)
    original_limit = AioHttpDefaults.LIMIT
    AioHttpDefaults.LIMIT = 0
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    limit = 65535 if hard == resource.RLIM_INFINITY else min(65535, hard)
    resource.setrlimit(resource.RLIMIT_NOFILE, (limit, hard))
    (target / f'network-{os.getpid()}.json').write_text(json.dumps(dict(
        connection_limit_before=original_limit, connection_limit=0,
        limit_per_host=AioHttpDefaults.LIMIT_PER_HOST,
        nofile=resource.getrlimit(resource.RLIMIT_NOFILE))) + '\n')
    original_execute = RequestRateStrategy.execute_phase

    async def observed_execute(self):
        cfg = self._config
        record = dict(pid=os.getpid(), phase=cfg.phase_name, rate=cfg.request_rate,
                      phase_start_ns=self._lifecycle.started_at_perf_ns,
                      entered_ns=time.perf_counter_ns(), events=[])
        record['rng_state_before'] = self._rate_generator._rng._python_rng.getstate()
        original_issue = self._credit_issuer.try_issue_credit

        async def observed_issue(*args, **kwargs):
            before = time.perf_counter_ns()
            result = await original_issue(*args, **kwargs)
            record['events'].append(dict(before_ns=before, after_ns=time.perf_counter_ns(),
                                         result='issued' if result is True else 'stop' if result is False else 'skipped'))
            return result

        self._credit_issuer.try_issue_credit = observed_issue
        try:
            return await original_execute(self)
        finally:
            self._credit_issuer.try_issue_credit = original_issue
            (target / f'phase-{os.getpid()}-{cfg.phase_name}.json').write_text(
                json.dumps(record, indent=2) + '\n')

    RequestRateStrategy.execute_phase = observed_execute
