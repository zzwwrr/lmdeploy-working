"""Small H200 Poisson capacity search followed by one official quality pass."""
import asyncio
import base64
import collections
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import sys
import time
import traceback
import zlib

import httpx
import psutil

from analyze import analyze, validate, write

ROOT = Path(__file__).resolve().parent
CLIENT = Path('/home/zhuwenrui/decision-aiperf/env/bin')
SERVER_PYTHON = '/home/zhuwenrui/decision-h200-gdr/envs/bench/bin/python'
MODEL = '/home/zhuwenrui/decision-h200/models/Intern-Decision-4B'
BASE = 'http://127.0.0.1:18483'
STATE = dict(stage='starting', complete=False, points=[], source_commit='4446d416789988d0429443ff88e3faf038a9965b',
             gpu_uuid='GPU-32f80b8a-b48a-3cea-0baa-8ecb909fb3aa', api='/v1/decisions', controller_pid=os.getpid())


def save():
    write(ROOT / 'results/status.json', STATE)


def snapshot():
    try:
        with httpx.Client(timeout=3, trust_env=False) as client:
            r = client.get(BASE + '/metrics')
            return dict(time_ns=time.time_ns(), status=r.status_code, text=r.text)
    except Exception as exc:
        return dict(time_ns=time.time_ns(), error=repr(exc))


def drain():
    idle_samples = 0
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        data = snapshot()
        values = [float(line.split()[-1]) for line in data.get('text', '').splitlines()
                  if line.startswith(('lmdeploy:num_requests_running{', 'lmdeploy:num_requests_waiting{',
                                      'lmdeploy:num_api_requests_waiting{'))]
        idle_samples = idle_samples + 1 if len(values) >= 2 and not any(values) else 0
        if idle_samples >= 2:
            return
        time.sleep(2)
    write(ROOT / 'results/drain-failure.json', data)
    raise TimeoutError('Production queues did not drain; do not mix subsequent phases')


def invoke(args, name, timeout, env=None, monitor=False):
    with (ROOT / 'logs' / f'{name}.log').open('x') as log:
        process = subprocess.Popen(list(map(str, args)), cwd=ROOT, env=env, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        STATE['child_pid'] = process.pid
        save()
        deadline = time.monotonic() + timeout
        monitor_path = ROOT / 'results' / f'{name}-monitor.jsonl'
        try:
            while process.poll() is None:
                if monitor:
                    with monitor_path.open('a') as stream:
                        stream.write(json.dumps(snapshot()) + '\n')
                if time.monotonic() > deadline:
                    raise TimeoutError(f'{name} exceeded deadline')
                time.sleep(2)
            assert process.returncode == 0, f'{name} exited {process.returncode}; see {log.name}'
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            STATE.pop('child_pid', None)
            save()


def point(rate, seconds=60, kind='explore', seed=20261106):
    drain()
    index = len(STATE['points']) + 1
    name = f'{index:02}-{kind}-r{rate:g}-s{seconds}'
    path = ROOT / 'results' / name
    path.mkdir(exist_ok=False)
    meta = dict(name=name, rate=rate, seconds=seconds, kind=kind, seed=seed)
    args = [CLIENT / 'aiperf', 'profile', '--model', 'Intern-Decision-4B',
            '--url', BASE + '/v1/decisions', '--endpoint-type', 'raw',
            '--custom-dataset-type', 'inputs_json', '--input-file', ROOT / 'data/openai-mixed-inputs.json',
            '--tokenizer', MODEL, '--extra-inputs', 'response_field:to_string(answers)',
            '--request-rate', rate, '--arrival-pattern', 'poisson', '--request-timeout-seconds', 15,
            '--benchmark-duration', seconds, '--benchmark-grace-period', 30,
            '--dataset-sampling-strategy', 'shuffle', '--random-seed', seed,
            '--export-level', 'raw', '--no-gpu-telemetry', '--no-server-metrics', '--ui', 'none',
            '--workers-max', 4, '--goodput', 'request_latency:1000', '--output-artifact-dir', path,
            '--warmup-request-count', 32, '--warmup-request-rate', 10]
    assert '--concurrency' not in args and '--prefill-concurrency' not in args
    write(path / 'command.json', list(map(str, args)))
    write(path / 'run-config.json', meta)
    write(path / 'metrics-before.json', snapshot())
    env = os.environ.copy()
    env.update(PYTHONPATH=str(ROOT / 'config'), DECISION_AIPERF_COUNTER_DIR=str(path / 'scheduler'))
    STATE['stage'] = name
    save()
    print('START', name, flush=True)
    invoke(args, name, seconds + 180, env=env, monitor=True)
    write(path / 'metrics-after.json', snapshot())
    result = analyze(path, meta)
    STATE['points'].append(result)
    save()
    print('DONE', json.dumps({k: result[k] for k in ('name', 'actual_send_rps', 'completed_in_window_rps',
          'latency_ms', 'delivery_valid', 'stable', 'stable_reasons', 'cache_token_fraction')}), flush=True)
    assert result['delivery_valid'], f'Invalid client delivery: {result["delivery_reasons"]}'
    return result


def png_data_url(red, green, blue):
    def chunk(kind, data):
        return struct.pack('!I', len(data)) + kind + data + struct.pack('!I', zlib.crc32(kind + data))
    image = b'\x89PNG\r\n\x1a\n'
    image += chunk(b'IHDR', struct.pack('!2I5B', 64, 64, 8, 2, 0, 0, 0))
    image += chunk(b'IDAT', zlib.compress((b'\0' + bytes([red, green, blue]) * 64) * 64))
    image += chunk(b'IEND', b'')
    return 'data:image/png;base64,' + base64.b64encode(image).decode()


async def smoke_and_prime():
    rows = list(map(json.loads, (ROOT / 'data/records.jsonl').open()))
    assert len(rows) == 2000 and sum(r['m'] for r in rows) == 10600
    assert hashlib.sha256((ROOT / 'data/records.jsonl').read_bytes()).hexdigest() == \
        '98e1db9288a5e42f5076a98c801ff0a9f4a4a336a2c36d50a7f8e5a44fc1a0c2'
    assert dict(collections.Counter(r['m'] for r in rows)) == {1: 600, 4: 600, 8: 600, 12: 100, 16: 100}
    selected = [next(r for r in rows if r['m'] == m) for m in (1, 4, 8, 12, 16)]
    results = []
    async with httpx.AsyncClient(timeout=120, trust_env=False,
                                 limits=httpx.Limits(max_connections=8, max_keepalive_connections=8)) as client:
        for row in selected:
            response = await client.post(BASE + '/v1/decisions', json=row['payloads']['openai'])
            response.raise_for_status()
            validate(row, response.json())
            results.append(dict(id=row['id'], response=response.json()))
        for images in ([png_data_url(255, 0, 0)], [png_data_url(255, 0, 0), png_data_url(0, 0, 255)]):
            body = dict(model='Intern-Decision-4B', input=[dict(role='user', content=[
                dict(type='input_text', text='Inspect the supplied images.'),
                *[dict(type='input_image', image_url=image) for image in images]])],
                questions=[dict(type='predicate', name='red', instructions='Is red present in the FIRST image?')])
            response = await client.post(BASE + '/v1/decisions', json=body)
            response.raise_for_status()
            answer = response.json()['answers'][0]
            assert answer['type'] == 'predicate' and 0 <= answer['probability'] <= 1
            results.append(dict(images=len(images), response=response.json()))
        smoke_path = ROOT / 'results' / ('smoke.json' if not (ROOT / 'results/smoke.json').exists()
                                       else f'smoke-resume-{os.getpid()}.json')
        write(smoke_path, results)
        print('SMOKE_PASS', len(results), flush=True)
        iterator = iter(rows)
        prime_path = ROOT / 'results' / ('prime.jsonl' if not (ROOT / 'results/prime.jsonl').exists()
                                       else f'prime-resume-{os.getpid()}.jsonl')
        with prime_path.open('x') as stream:
            async def worker():
                for row in iterator:
                    response = await client.post(BASE + '/v1/decisions', json=row['payloads']['openai'])
                    response.raise_for_status()
                    validate(row, response.json())
                    stream.write(json.dumps(dict(id=row['id'], response=response.json()), ensure_ascii=False) + '\n')
            await asyncio.gather(*(worker() for _ in range(8)))
        print('PRIME_PASS', len(rows), flush=True)


def stop_service():
    pid = int((ROOT / 'service.pid').read_text())
    try:
        parent = psutil.Process(pid)
        assert Path(parent.cwd()) == ROOT and 'service.sh' in ' '.join(parent.cmdline())
        owned = parent.children(recursive=True)
        for process in reversed(owned):
            try:
                process.terminate()
            except psutil.NoSuchProcess:
                pass
        parent.terminate()
        _, alive = psutil.wait_procs([parent, *owned], timeout=30)
        for process in alive:
            process.kill()
        psutil.wait_procs(alive, timeout=10)
    except psutil.NoSuchProcess:
        pass


def main():
    prior_path = ROOT / 'results/status.json'
    if prior_path.exists():
        prior = json.loads(prior_path.read_text())
        assert not prior['complete'], 'This completed run must not be overwritten'
        STATE['prior_controller_error'] = prior.get('error')
        STATE['resumed_from'] = prior['stage']
        for path in sorted((ROOT / 'results').glob('*/run-config.json')):
            if (path.parent / 'phase_manifest.json').exists() and (path.parent / 'profile_export_raw.jsonl').exists():
                result = analyze(path.parent, json.loads(path.read_text()))
                assert result['delivery_valid'], result['delivery_reasons']
                STATE['points'].append(result)
    save()
    try:
        env = os.environ.copy()
        for key in ('http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'all_proxy'):
            env.pop(key, None)
        os.environ.update(env)
        deadline = time.monotonic() + 600
        while True:
            try:
                with httpx.Client(timeout=3, trust_env=False) as client:
                    r = client.get(BASE + '/v1/models')
                    r.raise_for_status()
                    break
            except httpx.HTTPError:
                if time.monotonic() > deadline:
                    raise TimeoutError('Service did not become ready')
                time.sleep(2)
        assert (ROOT / 'results/server-effective.json').is_file()
        STATE['stage'] = 'smoke-and-prime'
        save()
        asyncio.run(smoke_and_prime())
        probe = next((r for r in STATE['points'] if r['kind'] == 'client-preflight'), None)
        if probe is None:
            probe = point(5, seconds=5, kind='client-preflight')
        assert probe['invalid'] == 0
        low_result = next((r for r in STATE['points'] if r['kind'] == 'explore' and r['rate'] == 50), None)
        high_result = next((r for r in STATE['points'] if r['kind'] == 'explore' and r['rate'] == 70), None)
        if low_result is None:
            low_result = point(50)
        if high_result is None:
            high_result = point(70)
        # An isolated slope in a short window needs a longer observation before
        # using it as a capacity boundary. Keep the original point unchanged.
        if low_result['stable_reasons'] == ['growing_backlog']:
            low_result = point(50, seconds=120, kind='trend-recheck', seed=20264133)
        low = 50 if low_result['stable'] else None
        high = 70 if not high_result['stable'] else None
        if not low_result['stable']:
            high = 50
            for candidate in (40, 30, 20, 10):
                result = point(candidate)
                if result['stable']:
                    low = candidate
                    break
                high = candidate
        elif high_result['stable']:
            low = 70
            for candidate in (80, 90, 100, 110, 120):
                result = point(candidate)
                if not result['stable']:
                    high = candidate
                    break
                low = candidate
        assert low is not None and high is not None, 'No stable/saturated bracket within exploration budget'
        while high - low > 2:
            middle = round((low + high) / 2, 3)
            result = point(middle)
            if result['stable']:
                low = middle
            else:
                high = middle
        STATE['exploratory_interval_rps'] = [low, high]
        lower = point(low, seconds=120, kind='confirm-low', seed=20262115)
        upper = point(high, seconds=120, kind='confirm-high', seed=20263124)
        STATE['confirmed_interval_rps'] = [low, high] if lower['stable'] and not upper['stable'] else None
        STATE['boundary_results'] = dict(lower_stable=lower['stable'], upper_stable=upper['stable'])
        save()
        drain()
        STATE['stage'] = 'official-seven-c8'
        save()
        invoke([SERVER_PYTHON, ROOT / 'evaluate_http.py'], 'official-seven', timeout=1800, monitor=True)
        STATE['quality'] = json.loads((ROOT / 'results/official-seven/summary.json').read_text())
        STATE.update(stage='complete', complete=True)
    except BaseException:
        STATE['error'] = traceback.format_exc()
        STATE['stage'] = 'failed'
        raise
    finally:
        save()
        stop_service()
        STATE['service_stopped'] = True
        save()


if __name__ == '__main__':
    main()
