"""Run the seven official suites once over the production Systemone endpoint."""
import asyncio
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

import httpx

ROOT = Path(__file__).resolve().parent
REFERENCE = Path('/home/zhuwenrui/decision-precision-20261104/reference')
sys.path.insert(0, str(REFERENCE))
from src.eval import jev


async def evaluate():
    output = ROOT / 'results/official-seven'
    output.mkdir(exist_ok=False)
    rows = list(map(json.loads, (ROOT / 'data/accuracy-records.jsonl').open()))
    assert len(rows) == 10751 and sum(len(r['targets']) for r in rows) == 12351
    expected = []
    for name, data, count in jev.suite_datasets():
        originals = list(jev.read_rows(data))
        assert len(originals) == count
        suite = [r for r in rows if r['suite'] == name]
        assert len(suite) == count
        for saved, raw in zip(suite, originals, strict=True):
            assert saved['original_id'] == raw['id']
            canonical = jev._canonical_public(raw)
            assert saved['payload'] == {k: canonical[k] for k in ('state', 'questions')}
        expected.append(dict(suite=name, rows=count, sha256=hashlib.sha256(data.read_bytes()).hexdigest()))
    iterator = iter(enumerate(rows))
    records = []
    started = time.perf_counter()
    with (output / 'responses.jsonl').open('x') as stream:
        async with httpx.AsyncClient(timeout=120, trust_env=False,
                                     limits=httpx.Limits(max_connections=8, max_keepalive_connections=8)) as client:
            async def worker():
                for index, row in iterator:
                    record = dict(index=index, id=row['original_id'], key=row['id'], suite=row['suite'],
                                  source_line=row['source_line'])
                    begin = time.perf_counter()
                    try:
                        response = await client.post('http://127.0.0.1:18483/v1/systemone', json=row['payload'])
                        record['status'] = response.status_code
                        response.raise_for_status()
                        record['response'] = response.json()
                        assert set(record['response']['answers']) == set(row['targets'])
                    except Exception as exc:
                        record['error'] = repr(exc)
                    record['latency_ms'] = (time.perf_counter() - begin) * 1000
                    records.append(record)
                    stream.write(json.dumps(record, ensure_ascii=False) + '\n')
                    if len(records) % 250 == 0:
                        stream.flush()
                        print(json.dumps(dict(completed=len(records), total=len(rows),
                                              errors=sum('error' in r for r in records))), flush=True)
            await asyncio.gather(*(worker() for _ in range(8)))
    assert len(records) == 10751
    assert not any('error' in r for r in records), 'HTTP inference failures retained in responses.jsonl'
    records.sort(key=lambda r: r['index'])
    suites = {}
    for name, data, count in jev.suite_datasets():
        selected = [r for r in records if r['suite'] == name]

        class Replay:
            checkpoint = '/home/zhuwenrui/decision-h200/models/Intern-Decision-4B'
            backend_name = 'lmdeploy-pytorch-http'
            temperature = 1.99241824

            def __init__(self):
                self.iterator = iter(selected)

            def predict(self, row):
                record = next(self.iterator)
                assert record['id'] == row['id']
                body = json.loads(json.dumps(record['response']))
                for answer in body['answers'].values():
                    if answer['type'] == 'noul':
                        answer['probabilities'] = {'yes': answer['noul'], 'no': 1 - answer['noul']}
                return body

        suites[name] = jev.evaluate(Replay(), data, output / 'scored' / f'{name}.jsonl')
    jev.verify_suite_counts(suites)
    fields = sum(s['total'] for s in suites.values())
    correct = sum(s['correct'] for s in suites.values())
    summary = dict(complete=True, source_commit='4446d416789988d0429443ff88e3faf038a9965b',
                   http_endpoint='/v1/systemone', concurrency=8, requests=len(records), fields=fields,
                   correct=correct, macro7_accuracy=statistics.mean(s['accuracy'] for s in suites.values()),
                   weighted_accuracy=correct / fields, hard_brier=suites['jevbench-hard']['brier'],
                   hard_ece=suites['jevbench-hard']['ece']['ece'], suites=suites, datasets=expected,
                   elapsed_seconds=time.perf_counter() - started, temperature=1.99241824,
                   scorer_file=str(jev.__file__), scorer_sha256=hashlib.sha256(Path(jev.__file__).read_bytes()).hexdigest(),
                   source_dataset_sha256=hashlib.sha256((ROOT / 'data/accuracy-records.jsonl').read_bytes()).hexdigest())
    (output / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('suites', 'datasets')}), flush=True)


if __name__ == '__main__':
    asyncio.run(evaluate())
