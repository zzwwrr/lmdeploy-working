"""Start the frozen production CLI and save configuration once at startup."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import resource
import sys
from dataclasses import asdict

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
sys.meta_path = [finder for finder in sys.meta_path if 'editable' not in repr(finder).lower()]
sys.path.insert(0, str(SOURCE))
soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
resource.setrlimit(resource.RLIMIT_NOFILE, (min(65535, hard), hard))

import lmdeploy
from lmdeploy.serve.parsers import decision_parser

assert Path(lmdeploy.__file__).resolve() == SOURCE / 'lmdeploy/__init__.py'
original_context = decision_parser.create_decision_context


def observed_context(engine, model_path, **kwargs):
    context = original_context(engine, model_path, **kwargs)
    from lmdeploy.pytorch.backends.cuda.attention import use_fa3

    model = Path(model_path)
    record = dict(
        source_commit='4446d416789988d0429443ff88e3faf038a9965b',
        source=str(SOURCE), module_file=lmdeploy.__file__, argv=sys.argv,
        python=sys.executable, config=asdict(engine.backend_config),
        temperature=context.temperature, use_fa3=bool(use_fa3),
        visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        model=str(model), model_resolved=str(model.resolve()),
        model_metadata={name: hashlib.sha256((model / name).read_bytes()).hexdigest()
                        for name in ('config.json', 'inference.py', 'tokenizer_config.json')},
        versions={name: importlib.metadata.version(name) for name in
                  ('torch', 'transformers', 'flash-linear-attention', 'fla-core', 'tilelang', 'triton')},
        production_sha256={str(path.relative_to(SOURCE)): hashlib.sha256(path.read_bytes()).hexdigest()
                           for path in (SOURCE / 'lmdeploy').rglob('*.py')},
        scope='Unmodified production HTTP routes and kernels; startup metadata hook only.',
    )
    (ROOT / 'results/server-effective.json').write_text(json.dumps(record, indent=2, default=str) + '\n')
    return context


decision_parser.create_decision_context = observed_context

from lmdeploy.cli import run

if __name__ == '__main__':
    run()
