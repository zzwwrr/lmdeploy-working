"""Refine a boundary that failed its longer confirmation; reuse all prior runs."""
import asyncio
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

import httpx

ROOT = Path(__file__).resolve().parent
deadline = time.monotonic() + 1200
while True:
    state_path = ROOT / 'results/status.json'
    previous = json.loads(state_path.read_text())
    exit_path = ROOT / 'run.exit_code'
    if previous.get('complete') and previous.get('service_stopped') and exit_path.exists():
        assert exit_path.read_text().strip() == '0'
        break
    if previous.get('stage') == 'failed':
        raise RuntimeError(previous.get('error'))
    if time.monotonic() > deadline:
        raise TimeoutError('Waiting for the original run and its GPU cleanup')
    time.sleep(5)

if previous.get('confirmed_interval_rps'):
    print('Existing boundary was confirmed; no extra inference needed.', flush=True)
    raise SystemExit(0)

import run as runner

runner.STATE.clear()
runner.STATE.update(previous)
runner.STATE.update(stage='long-boundary-refinement', complete=False, service_stopped=False,
                    controller_pid=os.getpid())
runner.STATE.pop('error', None)
(ROOT / 'results/status-before-long-refinement.json').write_bytes(state_path.read_bytes())
service = None
try:
    value = subprocess.check_output(['nvidia-smi', '-i', '2', '--query-gpu=memory.used',
                                     '--format=csv,noheader,nounits'], text=True)
    assert int(value) < 100, f'GPU 2 became occupied: {value}'
    for name in ('service.pid', 'service.exit_code'):
        path = ROOT / name
        if path.exists():
            path.rename(ROOT / (name + '.before-long-refinement'))
    log = (ROOT / 'logs/service-long-refinement.log').open('x')
    service = subprocess.Popen(['bash', 'service.sh'], cwd=ROOT, stdout=log,
                               stderr=subprocess.STDOUT, start_new_session=True)
    (ROOT / 'service.pid').write_text(str(service.pid) + '\n')
    runner.save()
    started = time.monotonic()
    while True:
        assert service.poll() is None, 'Service startup failed'
        try:
            with httpx.Client(timeout=3, trust_env=False) as client:
                response = client.get(runner.BASE + '/v1/models')
                response.raise_for_status()
                break
        except httpx.HTTPError:
            assert time.monotonic() - started < 600
            time.sleep(2)
    asyncio.run(runner.smoke_and_prime())
    points = [p for p in runner.STATE['points'] if p['seconds'] >= 120 and p['delivery_valid']]
    low = max(p['rate'] for p in points if p['stable'])
    high = min(p['rate'] for p in points if not p['stable'] and p['rate'] > low)
    while high - low > 2:
        middle = round((low + high) / 2, 3)
        result = runner.point(middle, seconds=120, kind='refine-long', seed=20267169 + round(middle * 100))
        if result['stable']:
            low = middle
        else:
            high = middle
    runner.STATE.update(confirmed_interval_rps=[low, high], stage='complete', complete=True,
                        refinement_scope='All final bracket endpoints observed for 120 seconds; original quality pass reused.')
    print('CONFIRMED', low, high, flush=True)
except BaseException:
    runner.STATE.update(stage='failed', error=traceback.format_exc())
    raise
finally:
    runner.save()
    if service is not None:
        runner.stop_service()
    runner.STATE['service_stopped'] = True
    runner.save()
